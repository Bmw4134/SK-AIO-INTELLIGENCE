import plotly.graph_objects as go
import plotly.express as px
import json

# Data from the provided JSON
data = [
    {"metric": "Win Rate (%)", "automated": 68, "manual": 38},
    {"metric": "Avg Return (%)", "automated": 4.1, "manual": -2.3},
    {"metric": "Max Drawdown (%)", "automated": 18, "manual": 45},
    {"metric": "Sharpe Ratio", "automated": 1.8, "manual": 0.3},
    {"metric": "Profit 1Y (%)", "automated": 78, "manual": 15}
]

# Extract metrics and values
metrics = [item["metric"] for item in data]
automated_values = [item["automated"] for item in data]
manual_values = [item["manual"] for item in data]

# Create grouped bar chart
fig = go.Figure()

# Add bars for automated trading (using brand color blue)
fig.add_trace(go.Bar(
    name='Automated',
    x=metrics,
    y=automated_values,
    marker_color='blue',
    cliponaxis=False
))

# Add bars for manual trading (using brand color red)
fig.add_trace(go.Bar(
    name='Manual',
    x=metrics,
    y=manual_values,
    marker_color='red',
    cliponaxis=False
))

# Update layout
fig.update_layout(
    title='Auto vs Manual Trading Performance',
    xaxis_title='Metrics',
    yaxis_title='Value',
    barmode='group',
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.05,
        xanchor='center',
        x=0.5
    )
)

# Save the chart
fig.write_image('trading_comparison.png')
fig.show()