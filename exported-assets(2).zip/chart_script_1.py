import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np

# Define the node data
nodes_data = [
    {"id": "tradingview", "label": "TradingView Scripts", "category": "data_source", "x": 100, "y": 100},
    {"id": "web_scraping", "label": "Web Scraping", "category": "data_source", "x": 100, "y": 200},
    {"id": "market_data", "label": "Market Data APIs", "category": "data_source", "x": 100, "y": 300},
    {"id": "script_analysis", "label": "Script Analysis", "category": "ai_processing", "x": 300, "y": 100},
    {"id": "strategy_learning", "label": "Strategy Learning", "category": "ai_processing", "x": 300, "y": 200},
    {"id": "realtime_adaptation", "label": "Real-time Adaptation", "category": "ai_processing", "x": 300, "y": 300},
    {"id": "coinbase_api", "label": "Coinbase API", "category": "execution", "x": 500, "y": 100},
    {"id": "alpaca_api", "label": "Alpaca API", "category": "execution", "x": 500, "y": 200},
    {"id": "robinhood_browser", "label": "Robinhood Headless", "category": "execution", "x": 500, "y": 300},
    {"id": "stop_loss", "label": "Stop Loss (-10%)", "category": "risk_management", "x": 700, "y": 150},
    {"id": "position_sizing", "label": "Position Sizing", "category": "risk_management", "x": 700, "y": 250},
    {"id": "dashboard", "label": "Dashboard Views", "category": "user_interface", "x": 900, "y": 100},
    {"id": "console_logs", "label": "Console Logs", "category": "user_interface", "x": 900, "y": 200},
    {"id": "performance_metrics", "label": "Performance Metrics", "category": "user_interface", "x": 900, "y": 300}
]

# Define color mapping
color_map = {
    "data_source": "#1FB8CD",  # Blue
    "ai_processing": "#ECEBD5",  # Green
    "execution": "#B4413C",  # Red
    "risk_management": "#FFC185",  # Orange
    "user_interface": "#944454"  # Purple
}

# Define connections (edges) showing data flow
connections = [
    # Data sources to AI processing
    ("tradingview", "script_analysis"),
    ("web_scraping", "strategy_learning"),
    ("market_data", "realtime_adaptation"),
    # AI processing to execution
    ("script_analysis", "coinbase_api"),
    ("strategy_learning", "alpaca_api"),
    ("realtime_adaptation", "robinhood_browser"),
    # Execution to risk management
    ("coinbase_api", "stop_loss"),
    ("alpaca_api", "position_sizing"),
    ("robinhood_browser", "stop_loss"),
    # Risk management to UI
    ("stop_loss", "dashboard"),
    ("position_sizing", "console_logs"),
    ("stop_loss", "performance_metrics"),
    ("position_sizing", "performance_metrics"),
    # Additional logical connections
    ("strategy_learning", "realtime_adaptation"),
    ("realtime_adaptation", "stop_loss"),
    ("performance_metrics", "strategy_learning")  # feedback loop
]

# Create node lookup dictionary
node_lookup = {node["id"]: node for node in nodes_data}

# Create figure
fig = go.Figure()

# Add edges (connections)
for source, target in connections:
    source_node = node_lookup[source]
    target_node = node_lookup[target]
    
    fig.add_trace(go.Scatter(
        x=[source_node["x"], target_node["x"]],
        y=[source_node["y"], target_node["y"]],
        mode='lines',
        line=dict(color='lightgray', width=2),
        showlegend=False,
        hoverinfo='none',
        cliponaxis=False
    ))

# Add nodes by category
for category, color in color_map.items():
    category_nodes = [node for node in nodes_data if node["category"] == category]
    
    if category_nodes:
        fig.add_trace(go.Scatter(
            x=[node["x"] for node in category_nodes],
            y=[node["y"] for node in category_nodes],
            mode='markers+text',
            marker=dict(size=40, color=color, line=dict(width=2, color='white')),
            text=[node["label"] for node in category_nodes],
            textposition="middle center",
            textfont=dict(size=10, color='black'),
            name=category.replace('_', ' ').title(),
            showlegend=True,
            hoverinfo='text',
            hovertext=[node["label"] for node in category_nodes],
            cliponaxis=False
        ))

# Update layout
fig.update_layout(
    title="Automated Trading Bot Architecture",
    xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
    yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
    showlegend=True,
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    plot_bgcolor='white'
)

# Remove axis lines
fig.update_xaxes(showline=False)
fig.update_yaxes(showline=False)

# Save the chart
fig.write_image("trading_bot_architecture.png")