import plotly.graph_objects as go
import json

# Data provided
data = [
  {
    "strategy": "DCA Grid",
    "1_month": 72,
    "3_months": 68,
    "6_months": 65,
    "12_months": 62
  },
  {
    "strategy": "Momentum Breakout",
    "1_month": 65,
    "3_months": 70,
    "6_months": 68,
    "12_months": 66
  },
  {
    "strategy": "Range Trading",
    "1_month": 58,
    "3_months": 61,
    "6_months": 64,
    "12_months": 67
  },
  {
    "strategy": "Arbitrage",
    "1_month": 78,
    "3_months": 76,
    "6_months": 74,
    "12_months": 72
  },
  {
    "strategy": "AI Sentiment",
    "1_month": 82,
    "3_months": 79,
    "6_months": 76,
    "12_months": 73
  }
]

# Time periods (abbreviated to fit 15 char limit)
time_periods = ['1m', '3m', '6m', '12m']

# Colors to use (first 5 from the brand colors)
colors = ['#1FB8CD', '#FFC185', '#ECEBD5', '#5D878F', '#D2BA4C']

# Create the figure
fig = go.Figure()

# Add a line for each strategy
for i, strategy_data in enumerate(data):
    success_rates = [
        strategy_data['1_month'],
        strategy_data['3_months'],
        strategy_data['6_months'],
        strategy_data['12_months']
    ]
    
    fig.add_trace(go.Scatter(
        x=time_periods,
        y=success_rates,
        mode='lines+markers',
        name=strategy_data['strategy'],
        line=dict(color=colors[i], width=3),
        marker=dict(size=8),
        cliponaxis=False
    ))

# Update layout
fig.update_layout(
    title='Trading Bot Success Rates Over Time',
    xaxis_title='Time Period',
    yaxis_title='Success Rate %',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Save the chart
fig.write_image('trading_bot_success_rates.png')