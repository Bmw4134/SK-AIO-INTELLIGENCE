import plotly.graph_objects as go
import json

# Define the data
data = [
    {
        "strategy": "DCA Grid",
        "profitability": 7,
        "risk_management": 9,
        "consistency": 8,
        "volatility_handling": 6,
        "ease_of_implementation": 9
    },
    {
        "strategy": "Momentum Breakout",
        "profitability": 8,
        "risk_management": 6,
        "consistency": 5,
        "volatility_handling": 9,
        "ease_of_implementation": 7
    },
    {
        "strategy": "AI Sentiment Analysis",
        "profitability": 9,
        "risk_management": 7,
        "consistency": 6,
        "volatility_handling": 8,
        "ease_of_implementation": 4
    },
    {
        "strategy": "Arbitrage",
        "profitability": 8,
        "risk_management": 9,
        "consistency": 9,
        "volatility_handling": 7,
        "ease_of_implementation": 5
    },
    {
        "strategy": "Range Trading",
        "profitability": 6,
        "risk_management": 8,
        "consistency": 9,
        "volatility_handling": 5,
        "ease_of_implementation": 8
    }
]

# Define the categories (abbreviated to fit character limit)
categories = ['Profitability', 'Risk Mgmt', 'Consistency', 'Volatility', 'Ease of Impl']

# Define colors in order
colors = ['#1FB8CD', '#FFC185', '#ECEBD5', '#5D878F', '#D2BA4C']

# Create figure
fig = go.Figure()

# Add each strategy as a trace
for i, strategy_data in enumerate(data):
    # Get strategy name (abbreviated if needed)
    strategy_name = strategy_data['strategy']
    if strategy_name == 'Momentum Breakout':
        strategy_name = 'Momentum'
    elif strategy_name == 'AI Sentiment Analysis':
        strategy_name = 'AI Sentiment'
    
    # Get values for each category
    values = [
        strategy_data['profitability'],
        strategy_data['risk_management'],
        strategy_data['consistency'],
        strategy_data['volatility_handling'],
        strategy_data['ease_of_implementation']
    ]
    
    # Add the first value at the end to close the radar chart
    values.append(values[0])
    categories_closed = categories + [categories[0]]
    
    fig.add_trace(go.Scatterpolar(
        r=values,
        theta=categories_closed,
        fill='toself',
        name=strategy_name,
        line_color=colors[i],
        fillcolor=colors[i],
        opacity=0.6,
        cliponaxis=False
    ))

# Update layout
fig.update_layout(
    title="Trading Strategy Performance Radar",
    polar=dict(
        radialaxis=dict(
            visible=True,
            range=[0, 10],
            tickmode='linear',
            tick0=0,
            dtick=2
        )
    ),
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.05,
        xanchor='center',
        x=0.5
    )
)

# Save the chart
fig.write_image("trading_strategy_radar.png")