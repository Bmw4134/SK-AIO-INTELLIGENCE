// Trading Dashboard Application
class TradingDashboard {
    constructor() {
        this.data = {
            bot_status: {
                active: true,
                mode: "LIVE_TRADING",
                uptime: "2h 35m",
                last_trade: "5 minutes ago",
                active_orders: 3,
                total_signals: 12
            },
            portfolio: {
                total_value: 125000.0,
                available_balance: 50000.0,
                positions: {
                    BTC: 0.5,
                    ETH: 2.0,
                    BNB: 100.0,
                    USDT: 50000.0
                },
                allocation: {
                    BTC: 35.0,
                    ETH: 25.0,
                    BNB: 15.0,
                    USDT: 25.0
                }
            },
            performance: {
                total_trades: 10,
                winning_trades: 7,
                losing_trades: 3,
                total_pnl: 2621.82,
                avg_trade_pnl: 262.18,
                win_rate: 70.0,
                max_drawdown: 12.5,
                sharpe_ratio: 1.85,
                total_fees: 42.50,
                portfolio_value: 125000.0,
                daily_return: 2.3,
                monthly_return: 15.8
            },
            trading_history: [
                {
                    id: "TRADE_001",
                    timestamp: "2025-07-18T10:25:46.654Z",
                    symbol: "BTC/USDT",
                    side: "buy",
                    quantity: 0.245,
                    price: 44250.50,
                    fee: 2.65,
                    pnl: 850.25,
                    status: "FILLED"
                },
                {
                    id: "TRADE_002",
                    timestamp: "2025-07-18T08:15:32.421Z",
                    symbol: "ETH/USDT",
                    side: "sell",
                    quantity: 1.8,
                    price: 3125.75,
                    fee: 1.85,
                    pnl: -125.50,
                    status: "FILLED"
                },
                {
                    id: "TRADE_003",
                    timestamp: "2025-07-18T06:42:18.332Z",
                    symbol: "BNB/USDT",
                    side: "buy",
                    quantity: 50.0,
                    price: 285.90,
                    fee: 3.25,
                    pnl: 425.75,
                    status: "FILLED"
                }
            ],
            price_data: {
                "BTC/USDT": {
                    current_price: 44850.25,
                    change_24h: 2.35,
                    volume_24h: 1250000000
                },
                "ETH/USDT": {
                    current_price: 3145.80,
                    change_24h: -1.25,
                    volume_24h: 680000000
                },
                "BNB/USDT": {
                    current_price: 290.45,
                    change_24h: 1.85,
                    volume_24h: 95000000
                }
            },
            risk_metrics: {
                current_risk_score: 0.35,
                risk_level: "MEDIUM",
                var_1d: 2500.0,
                var_1w: 8500.0,
                beta: 1.2,
                correlation_btc: 0.85
            },
            market_signals: [
                {
                    symbol: "BTC/USDT",
                    type: "BUY",
                    reason: "RSI Oversold",
                    strength: 0.8,
                    timestamp: "2025-07-18T12:20:15.654Z"
                },
                {
                    symbol: "ETH/USDT",
                    type: "SELL",
                    reason: "MACD Bearish",
                    strength: 0.6,
                    timestamp: "2025-07-18T12:15:32.421Z"
                },
                {
                    symbol: "BNB/USDT",
                    type: "HOLD",
                    reason: "Neutral Momentum",
                    strength: 0.4,
                    timestamp: "2025-07-18T12:10:18.332Z"
                }
            ],
            alerts: [
                {
                    type: "INFO",
                    message: "BTC broke above $45,000 resistance",
                    timestamp: "2025-07-18T12:25:46.654Z"
                },
                {
                    type: "WARNING",
                    message: "High volatility detected in ETH/USDT",
                    timestamp: "2025-07-18T12:10:46.654Z"
                },
                {
                    type: "SUCCESS",
                    message: "Order BTC_001 filled successfully",
                    timestamp: "2025-07-18T12:20:46.654Z"
                }
            ]
        };
        
        this.activeOrders = [
            { symbol: "BTC/USDT", side: "buy", type: "limit", quantity: 0.1, price: 44000 },
            { symbol: "ETH/USDT", side: "sell", type: "limit", quantity: 0.5, price: 3200 },
            { symbol: "BNB/USDT", side: "buy", type: "stop", quantity: 25, price: 285 }
        ];
        
        this.charts = {};
        this.updateIntervals = [];
        
        this.init();
    }
    
    init() {
        this.setupNavigation();
        this.setupBotToggle();
        this.setupTradeForm();
        this.setupEventListeners();
        this.renderDashboard();
        this.startRealTimeUpdates();
    }
    
    setupNavigation() {
        const navLinks = document.querySelectorAll('.nav-link');
        const sections = document.querySelectorAll('.section');
        
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const sectionId = link.dataset.section;
                
                // Update active nav link
                navLinks.forEach(nl => nl.classList.remove('active'));
                link.classList.add('active');
                
                // Show active section
                sections.forEach(section => section.classList.remove('active'));
                document.getElementById(sectionId).classList.add('active');
            });
        });
    }
    
    setupBotToggle() {
        const toggleBtn = document.getElementById('toggleBot');
        const statusIndicator = document.getElementById('botStatus');
        
        toggleBtn.addEventListener('click', () => {
            this.data.bot_status.active = !this.data.bot_status.active;
            
            if (this.data.bot_status.active) {
                statusIndicator.textContent = 'Active';
                statusIndicator.classList.remove('inactive');
                this.showNotification('Bot activated successfully', 'success');
            } else {
                statusIndicator.textContent = 'Inactive';
                statusIndicator.classList.add('inactive');
                this.showNotification('Bot deactivated', 'warning');
            }
        });
    }
    
    setupTradeForm() {
        const tradeForm = document.getElementById('tradeForm');
        const symbolSelect = document.getElementById('tradeSymbol');
        const quantityInput = document.getElementById('tradeQuantity');
        const priceInput = document.getElementById('tradePrice');
        
        // Update price when symbol changes
        symbolSelect.addEventListener('change', () => {
            const symbol = symbolSelect.value;
            if (this.data.price_data[symbol]) {
                priceInput.value = this.data.price_data[symbol].current_price;
                this.updateRiskAssessment();
            }
        });
        
        // Update risk assessment on quantity change
        quantityInput.addEventListener('input', () => {
            this.updateRiskAssessment();
        });
        
        // Handle form submission
        tradeForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.executeTrade();
        });
        
        // Set initial price
        priceInput.value = this.data.price_data['BTC/USDT'].current_price;
        this.updateRiskAssessment();
    }
    
    updateRiskAssessment() {
        const symbol = document.getElementById('tradeSymbol').value;
        const quantity = parseFloat(document.getElementById('tradeQuantity').value) || 0;
        const price = parseFloat(document.getElementById('tradePrice').value) || 0;
        
        const totalValue = quantity * price;
        const portfolioValue = this.data.portfolio.total_value;
        const positionSizePercent = (totalValue / portfolioValue) * 100;
        
        let riskLevel = 'Low';
        if (positionSizePercent > 10) riskLevel = 'High';
        else if (positionSizePercent > 5) riskLevel = 'Medium';
        
        document.getElementById('estimatedRisk').textContent = riskLevel;
        document.getElementById('positionSize').textContent = `${positionSizePercent.toFixed(1)}%`;
    }
    
    executeTrade() {
        const symbol = document.getElementById('tradeSymbol').value;
        const side = document.getElementById('tradeSide').value;
        const orderType = document.getElementById('orderType').value;
        const quantity = parseFloat(document.getElementById('tradeQuantity').value);
        const price = parseFloat(document.getElementById('tradePrice').value);
        
        if (!quantity || !price) {
            this.showNotification('Please fill in all required fields', 'error');
            return;
        }
        
        // Simulate trade execution
        const trade = {
            id: `TRADE_${Date.now()}`,
            timestamp: new Date().toISOString(),
            symbol: symbol,
            side: side,
            quantity: quantity,
            price: price,
            fee: (quantity * price * 0.001).toFixed(2),
            pnl: 0,
            status: 'FILLED'
        };
        
        this.data.trading_history.unshift(trade);
        this.showNotification(`${side.toUpperCase()} order executed successfully`, 'success');
        this.renderTradeHistory();
        
        // Reset form
        document.getElementById('tradeForm').reset();
        document.getElementById('tradePrice').value = this.data.price_data[symbol].current_price;
        this.updateRiskAssessment();
    }
    
    setupEventListeners() {
        // Export history button
        document.getElementById('exportHistory').addEventListener('click', () => {
            this.exportTradeHistory();
        });
        
        // Risk settings update
        document.getElementById('updateRiskSettings').addEventListener('click', () => {
            this.updateRiskSettings();
        });
        
        // History filters
        document.getElementById('symbolFilter').addEventListener('change', () => {
            this.renderTradeHistory();
        });
        
        document.getElementById('sideFilter').addEventListener('change', () => {
            this.renderTradeHistory();
        });
        
        document.getElementById('dateFilter').addEventListener('change', () => {
            this.renderTradeHistory();
        });
    }
    
    renderDashboard() {
        this.renderMetrics();
        this.renderAlerts();
        this.renderActiveOrders();
        this.renderPositions();
        this.renderTradeHistory();
        this.renderRiskMetrics();
        this.renderMarketData();
        this.renderSignals();
        
        // Render charts after a short delay to ensure DOM is ready
        setTimeout(() => {
            this.renderCharts();
        }, 100);
    }
    
    renderMetrics() {
        document.getElementById('portfolioValue').textContent = 
            `$${this.data.portfolio.total_value.toLocaleString()}`;
        document.getElementById('totalPnL').textContent = 
            `$${this.data.performance.total_pnl.toLocaleString()}`;
        document.getElementById('winRate').textContent = 
            `${this.data.performance.win_rate}%`;
        document.getElementById('maxDrawdown').textContent = 
            `${this.data.performance.max_drawdown}%`;
    }
    
    renderAlerts() {
        const alertsContainer = document.getElementById('alertsContainer');
        alertsContainer.innerHTML = '';
        
        this.data.alerts.forEach(alert => {
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert ${alert.type.toLowerCase()}`;
            alertDiv.innerHTML = `
                <div class="alert-content">${alert.message}</div>
                <div class="alert-time">${this.formatTime(alert.timestamp)}</div>
            `;
            alertsContainer.appendChild(alertDiv);
        });
    }
    
    renderCharts() {
        this.renderAllocationChart();
        this.renderPriceChart();
    }
    
    renderAllocationChart() {
        const canvas = document.getElementById('allocationChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        if (this.charts.allocation) {
            this.charts.allocation.destroy();
        }
        
        // Prepare data for the chart
        const labels = Object.keys(this.data.portfolio.allocation);
        const data = Object.values(this.data.portfolio.allocation);
        const colors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5'];
        
        this.charts.allocation = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Portfolio Allocation',
                    data: data,
                    backgroundColor: colors,
                    borderColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            font: {
                                size: 12
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                return `${label}: ${value}%`;
                            }
                        }
                    }
                }
            }
        });
    }
    
    renderPriceChart() {
        const canvas = document.getElementById('priceChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        if (this.charts.price) {
            this.charts.price.destroy();
        }
        
        // Generate sample price data
        const labels = [];
        const btcData = [];
        const ethData = [];
        const bnbData = [];
        
        for (let i = 23; i >= 0; i--) {
            labels.push(`${i}:00`);
            btcData.push(44850 + Math.random() * 200 - 100);
            ethData.push(3145 + Math.random() * 50 - 25);
            bnbData.push(290 + Math.random() * 10 - 5);
        }
        
        this.charts.price = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'BTC/USDT',
                        data: btcData,
                        borderColor: '#1FB8CD',
                        backgroundColor: 'rgba(31, 184, 205, 0.1)',
                        fill: false,
                        tension: 0.1
                    },
                    {
                        label: 'ETH/USDT',
                        data: ethData,
                        borderColor: '#FFC185',
                        backgroundColor: 'rgba(255, 193, 133, 0.1)',
                        fill: false,
                        tension: 0.1
                    },
                    {
                        label: 'BNB/USDT',
                        data: bnbData,
                        borderColor: '#B4413C',
                        backgroundColor: 'rgba(180, 65, 60, 0.1)',
                        fill: false,
                        tension: 0.1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                scales: {
                    x: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Time'
                        }
                    },
                    y: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Price (USD)'
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            font: {
                                size: 12
                            }
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: function(context) {
                                const label = context.dataset.label || '';
                                const value = context.parsed.y || 0;
                                return `${label}: $${value.toLocaleString()}`;
                            }
                        }
                    }
                }
            }
        });
    }
    
    renderActiveOrders() {
        const tbody = document.getElementById('activeOrdersTable');
        tbody.innerHTML = '';
        
        this.activeOrders.forEach((order, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${order.symbol}</td>
                <td><span class="status status--${order.side === 'buy' ? 'success' : 'error'}">${order.side.toUpperCase()}</span></td>
                <td>${order.type.toUpperCase()}</td>
                <td>${order.quantity}</td>
                <td>$${order.price.toLocaleString()}</td>
                <td><button class="btn btn--sm btn--outline table-action-btn" onclick="dashboard.cancelOrder(${index})">Cancel</button></td>
            `;
            tbody.appendChild(row);
        });
    }
    
    renderPositions() {
        const tbody = document.getElementById('positionsTable');
        tbody.innerHTML = '';
        
        Object.entries(this.data.portfolio.positions).forEach(([asset, quantity]) => {
            if (quantity > 0) {
                const currentPrice = this.data.price_data[`${asset}/USDT`]?.current_price || 1;
                const avgPrice = currentPrice * 0.95; // Simulate average price
                const value = quantity * currentPrice;
                const pnl = quantity * (currentPrice - avgPrice);
                const allocation = this.data.portfolio.allocation[asset] || 0;
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${asset}</td>
                    <td>${quantity}</td>
                    <td>$${avgPrice.toLocaleString()}</td>
                    <td>$${currentPrice.toLocaleString()}</td>
                    <td>$${value.toLocaleString()}</td>
                    <td class="${pnl >= 0 ? 'positive' : 'negative'}">$${pnl.toLocaleString()}</td>
                    <td>${allocation}%</td>
                `;
                tbody.appendChild(row);
            }
        });
        
        // Update balance overview
        document.getElementById('totalValue').textContent = 
            `$${this.data.portfolio.total_value.toLocaleString()}`;
        document.getElementById('availableBalance').textContent = 
            `$${this.data.portfolio.available_balance.toLocaleString()}`;
        document.getElementById('inPositions').textContent = 
            `$${(this.data.portfolio.total_value - this.data.portfolio.available_balance).toLocaleString()}`;
    }
    
    renderTradeHistory() {
        const tbody = document.getElementById('historyTable');
        tbody.innerHTML = '';
        
        let filteredHistory = [...this.data.trading_history];
        
        // Apply filters
        const symbolFilter = document.getElementById('symbolFilter').value;
        const sideFilter = document.getElementById('sideFilter').value;
        const dateFilter = document.getElementById('dateFilter').value;
        
        if (symbolFilter) {
            filteredHistory = filteredHistory.filter(trade => trade.symbol === symbolFilter);
        }
        
        if (sideFilter) {
            filteredHistory = filteredHistory.filter(trade => trade.side === sideFilter);
        }
        
        if (dateFilter) {
            filteredHistory = filteredHistory.filter(trade => 
                trade.timestamp.startsWith(dateFilter)
            );
        }
        
        filteredHistory.forEach(trade => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${this.formatDateTime(trade.timestamp)}</td>
                <td>${trade.symbol}</td>
                <td><span class="status status--${trade.side === 'buy' ? 'success' : 'error'}">${trade.side.toUpperCase()}</span></td>
                <td>${trade.quantity}</td>
                <td>$${trade.price.toLocaleString()}</td>
                <td>$${trade.fee}</td>
                <td class="${trade.pnl >= 0 ? 'positive' : 'negative'}">$${trade.pnl.toLocaleString()}</td>
                <td><span class="status status--success">${trade.status}</span></td>
            `;
            tbody.appendChild(row);
        });
    }
    
    renderRiskMetrics() {
        document.getElementById('riskLevel').textContent = this.data.risk_metrics.risk_level;
        document.getElementById('riskValue').textContent = this.data.risk_metrics.current_risk_score;
        
        // Update risk gauge
        const riskGauge = document.getElementById('riskGauge');
        const riskPercentage = this.data.risk_metrics.current_risk_score * 100;
        riskGauge.style.background = `conic-gradient(
            var(--color-success) 0deg ${riskPercentage * 3.6}deg,
            var(--color-secondary) ${riskPercentage * 3.6}deg 360deg
        )`;
    }
    
    renderMarketData() {
        document.getElementById('btcPrice').textContent = 
            `$${this.data.price_data['BTC/USDT'].current_price.toLocaleString()}`;
        document.getElementById('ethPrice').textContent = 
            `$${this.data.price_data['ETH/USDT'].current_price.toLocaleString()}`;
        document.getElementById('bnbPrice').textContent = 
            `$${this.data.price_data['BNB/USDT'].current_price.toLocaleString()}`;
        
        document.getElementById('btcChange').textContent = 
            `${this.data.price_data['BTC/USDT'].change_24h > 0 ? '+' : ''}${this.data.price_data['BTC/USDT'].change_24h}%`;
        document.getElementById('ethChange').textContent = 
            `${this.data.price_data['ETH/USDT'].change_24h > 0 ? '+' : ''}${this.data.price_data['ETH/USDT'].change_24h}%`;
        document.getElementById('bnbChange').textContent = 
            `${this.data.price_data['BNB/USDT'].change_24h > 0 ? '+' : ''}${this.data.price_data['BNB/USDT'].change_24h}%`;
    }
    
    renderSignals() {
        const signalsContainer = document.getElementById('signalsContainer');
        signalsContainer.innerHTML = '';
        
        this.data.market_signals.forEach(signal => {
            const signalDiv = document.createElement('div');
            signalDiv.className = 'signal-item';
            signalDiv.innerHTML = `
                <div class="signal-info">
                    <div class="signal-symbol">${signal.symbol}</div>
                    <div class="signal-reason">${signal.reason}</div>
                </div>
                <div class="signal-details">
                    <div class="signal-type ${signal.type.toLowerCase()}">${signal.type}</div>
                    <div class="signal-strength">Strength: ${(signal.strength * 100).toFixed(0)}%</div>
                </div>
            `;
            signalsContainer.appendChild(signalDiv);
        });
    }
    
    cancelOrder(index) {
        this.activeOrders.splice(index, 1);
        this.renderActiveOrders();
        this.showNotification('Order cancelled successfully', 'success');
    }
    
    updateRiskSettings() {
        const maxPositionSize = document.getElementById('maxPositionSize').value;
        const stopLoss = document.getElementById('stopLoss').value;
        const takeProfit = document.getElementById('takeProfit').value;
        
        // Simulate updating risk settings
        this.showNotification('Risk settings updated successfully', 'success');
    }
    
    exportTradeHistory() {
        const csvContent = this.generateCSV();
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'trading_history.csv';
        a.click();
        window.URL.revokeObjectURL(url);
        this.showNotification('Trading history exported successfully', 'success');
    }
    
    generateCSV() {
        const headers = ['Date', 'Symbol', 'Side', 'Quantity', 'Price', 'Fee', 'P&L', 'Status'];
        const rows = this.data.trading_history.map(trade => [
            this.formatDateTime(trade.timestamp),
            trade.symbol,
            trade.side,
            trade.quantity,
            trade.price,
            trade.fee,
            trade.pnl,
            trade.status
        ]);
        
        return [headers, ...rows].map(row => row.join(',')).join('\n');
    }
    
    startRealTimeUpdates() {
        // Update prices every 5 seconds
        const priceUpdateInterval = setInterval(() => {
            this.updatePrices();
        }, 5000);
        
        // Update portfolio value every 10 seconds
        const portfolioUpdateInterval = setInterval(() => {
            this.updatePortfolioValue();
        }, 10000);
        
        this.updateIntervals.push(priceUpdateInterval, portfolioUpdateInterval);
    }
    
    updatePrices() {
        Object.keys(this.data.price_data).forEach(symbol => {
            const price = this.data.price_data[symbol];
            const change = (Math.random() - 0.5) * 0.1; // Random price change
            price.current_price += price.current_price * change;
            price.change_24h += change;
        });
        
        this.renderMarketData();
        this.renderPositions();
        
        // Update trade form price if BTC is selected
        const tradeSymbol = document.getElementById('tradeSymbol').value;
        const priceInput = document.getElementById('tradePrice');
        if (this.data.price_data[tradeSymbol]) {
            priceInput.value = this.data.price_data[tradeSymbol].current_price.toFixed(2);
        }
    }
    
    updatePortfolioValue() {
        // Simulate portfolio value change
        const change = (Math.random() - 0.5) * 0.02; // Random 2% change
        this.data.portfolio.total_value += this.data.portfolio.total_value * change;
        this.data.performance.total_pnl += this.data.portfolio.total_value * change;
        
        this.renderMetrics();
        this.renderPositions();
    }
    
    showNotification(message, type = 'info') {
        const notificationContainer = document.getElementById('notifications');
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-title">${type.charAt(0).toUpperCase() + type.slice(1)}</div>
            <div class="notification-message">${message}</div>
        `;
        
        notificationContainer.appendChild(notification);
        
        // Show notification
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        // Remove notification after 5 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notificationContainer.removeChild(notification);
            }, 300);
        }, 5000);
    }
    
    formatDateTime(timestamp) {
        return new Date(timestamp).toLocaleString();
    }
    
    formatTime(timestamp) {
        return new Date(timestamp).toLocaleTimeString();
    }
    
    destroy() {
        this.updateIntervals.forEach(interval => clearInterval(interval));
        Object.values(this.charts).forEach(chart => chart.destroy());
    }
}

// Initialize the dashboard when the page loads
let dashboard;
document.addEventListener('DOMContentLoaded', () => {
    dashboard = new TradingDashboard();
});

// Clean up on page unload
window.addEventListener('beforeunload', () => {
    if (dashboard) {
        dashboard.destroy();
    }
});

// Make dashboard globally accessible for onclick handlers
window.dashboard = dashboard;