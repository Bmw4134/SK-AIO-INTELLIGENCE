import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime

# Data from the provided JSON
data = {
    "dates": ["2025-06-18", "2025-06-19", "2025-06-20", "2025-06-21", "2025-06-22", "2025-06-23", "2025-06-24", "2025-06-25", "2025-06-26", "2025-06-27", "2025-06-28", "2025-06-29", "2025-06-30", "2025-07-01", "2025-07-02", "2025-07-03", "2025-07-04", "2025-07-05", "2025-07-06", "2025-07-07", "2025-07-08", "2025-07-09", "2025-07-10", "2025-07-11", "2025-07-12", "2025-07-13", "2025-07-14", "2025-07-15", "2025-07-16", "2025-07-17", "2025-07-18"],
    "portfolio_value": [100000, 101250, 99800, 102100, 103450, 101900, 104200, 105600, 103800, 106200, 107500, 105100, 108200, 109800, 107500, 110200, 111800, 109200, 112500, 114100, 112800, 115200, 117000, 115500, 118200, 119800, 117900, 120500, 122100, 123800, 125000]
}

# Create DataFrame
df = pd.DataFrame(data)
df['dates'] = pd.to_datetime(df['dates'])

# Calculate daily returns to determine gains/losses
df['daily_return'] = df['portfolio_value'].pct_change()

# Calculate moving averages
df['ma_7'] = df['portfolio_value'].rolling(window=7).mean()
df['ma_14'] = df['portfolio_value'].rolling(window=14).mean()

# Create the figure
fig = go.Figure()

# Add portfolio value line with color based on performance
# Split data into segments for color coding
for i in range(1, len(df)):
    color = '#00CC96' if df.iloc[i]['daily_return'] >= 0 else '#FF6692'  # Green for gains, red for losses
    
    fig.add_trace(go.Scatter(
        x=df['dates'].iloc[i-1:i+1],
        y=df['portfolio_value'].iloc[i-1:i+1],
        mode='lines',
        line=dict(color=color, width=3),
        showlegend=False,
        hovertemplate='<b>Portfolio</b><br>Date: %{x}<br>Value: $%{y:,.0f}<extra></extra>'
    ))

# Add main portfolio line for legend
fig.add_trace(go.Scatter(
    x=[df['dates'].iloc[0]],
    y=[df['portfolio_value'].iloc[0]],
    mode='markers',
    marker=dict(color='#1FB8CD', size=8),
    name='Portfolio',
    hovertemplate='<b>Portfolio</b><br>Date: %{x}<br>Value: $%{y:,.0f}<extra></extra>'
))

# Add 7-day moving average
fig.add_trace(go.Scatter(
    x=df['dates'],
    y=df['ma_7'],
    mode='lines',
    name='7-Day MA',
    line=dict(color='#FFC185', width=2, dash='dash'),
    hovertemplate='<b>7-Day MA</b><br>Date: %{x}<br>Value: $%{y:,.0f}<extra></extra>'
))

# Add 14-day moving average
fig.add_trace(go.Scatter(
    x=df['dates'],
    y=df['ma_14'],
    mode='lines',
    name='14-Day MA',
    line=dict(color='#ECEBD5', width=2, dash='dot'),
    hovertemplate='<b>14-Day MA</b><br>Date: %{x}<br>Value: $%{y:,.0f}<extra></extra>'
))

# Add trend line
z = np.polyfit(range(len(df)), df['portfolio_value'], 1)
p = np.poly1d(z)
fig.add_trace(go.Scatter(
    x=df['dates'],
    y=p(range(len(df))),
    mode='lines',
    name='Trend',
    line=dict(color='#5D878F', width=2),
    hovertemplate='<b>Trend</b><br>Date: %{x}<br>Value: $%{y:,.0f}<extra></extra>'
))

# Update layout
fig.update_layout(
    title='Portfolio Performance',
    xaxis_title='Date',
    yaxis_title='Value ($)',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    hovermode='x unified'
)

# Update axes
fig.update_yaxes(tickformat='$,.0f')

# Save the chart
fig.write_image("portfolio_performance.png")