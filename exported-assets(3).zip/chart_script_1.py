import plotly.graph_objects as go
import pandas as pd

# Data from the provided JSON
risk_categories = ["Position Size", "Concentration", "Volatility", "Liquidity"]
risk_scores = [0.25, 0.35, 0.45, 0.15]

# Define colors based on risk levels
risk_colors = []
for score in risk_scores:
    if score <= 0.3:
        risk_colors.append("#00C853")  # Green for low risk
    elif score <= 0.7:
        risk_colors.append("#FFC107")  # Yellow for medium risk
    else:
        risk_colors.append("#F44336")  # Red for high risk

# Create horizontal bar chart
fig = go.Figure()

fig.add_trace(go.Bar(
    y=risk_categories,
    x=risk_scores,
    orientation='h',
    marker_color=risk_colors,
    text=[f"{score:.2f}" for score in risk_scores],
    textposition='auto',
    hovertemplate='<b>%{y}</b><br>Risk Score: %{x:.2f}<extra></extra>',
    cliponaxis=False
))

# Update layout
fig.update_layout(
    title="Risk Assessment by Category",
    xaxis_title="Risk Score",
    yaxis_title="Category",
    showlegend=False
)

# Update axes
fig.update_xaxes(range=[0, 1], tickformat='.1f')
fig.update_yaxes(tickmode='linear')

# Save the chart
fig.write_image("risk_assessment_chart.png")