# Let me examine the current Labs environment to understand what we're working with
import json
import os

# Check what's available in the environment
print("Current working directory:", os.getcwd())
print("\nAvailable files:")
for file in os.listdir('.'):
    print(f"  {file}")

# Let's examine the singularity bundle to understand the current state
try:
    with open('singularity-bundle.json', 'r') as f:
        bundle = json.load(f)
    
    print("\n=== CURRENT LABS ENVIRONMENT ===")
    print(f"Version: {bundle['version']}")
    print(f"Timestamp: {bundle['timestamp']}")
    
    print("\n=== SPECIALIST AGENTS ===")
    for agent_name, agent_info in bundle['kernelState']['specialistAgents'].items():
        print(f"  {agent_name}: {agent_info['status']} ({agent_info['icon']})")
    
    print("\n=== API CONNECTIONS ===")
    for provider, info in bundle['kernelState']['apiProviderStatus'].items():
        print(f"  {provider}: {info['status']} ({info['tier']})")
    
    print("\n=== TRADING DATA AVAILABLE ===")
    if 'tradingData' in bundle['kernelState']['cachedData']:
        trading_data = bundle['kernelState']['cachedData']['tradingData']
        print(f"  Time periods: {len(trading_data['labels'])}")
        print(f"  Datasets: {len(trading_data['datasets'])}")
        for dataset in trading_data['datasets']:
            print(f"    - {dataset['label']}: {len(dataset['data'])} data points")
    
except Exception as e:
    print(f"Error reading singularity bundle: {e}")