# Install necessary libraries for trading
import subprocess
import sys

def install_package(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Install key trading libraries
try:
    print("Installing trading libraries...")
    
    # Core trading libraries
    install_package("ccxt")          # Cryptocurrency exchange library
    install_package("yfinance")      # Stock market data
    install_package("pandas")        # Data manipulation
    install_package("numpy")         # Numerical computing
    install_package("requests")      # HTTP requests
    install_package("websocket-client")  # WebSocket for real-time data
    install_package("ta")            # Technical analysis
    install_package("plotly")        # Interactive charts
    
    # Dashboard libraries
    install_package("streamlit")     # Web dashboard
    install_package("dash")          # Alternative dashboard
    
    print("✅ All libraries installed successfully!")
    
except Exception as e:
    print(f"❌ Error installing libraries: {e}")
    
# Test imports
try:
    import ccxt
    import yfinance as yf
    import pandas as pd
    import numpy as np
    import requests
    import ta
    import plotly.graph_objects as go
    import plotly.express as px
    
    print("\n✅ All imports successful!")
    print(f"CCXT version: {ccxt.__version__}")
    print(f"Available exchanges: {len(ccxt.exchanges)}")
    
except Exception as e:
    print(f"❌ Import error: {e}")