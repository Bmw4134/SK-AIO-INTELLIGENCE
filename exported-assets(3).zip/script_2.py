# Create the core trading suite architecture
import ccxt
import pandas as pd
import numpy as np
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import json
import warnings
warnings.filterwarnings('ignore')

# ========== TRADING SUITE CORE CLASSES ==========

class TradingBot:
    """Main trading bot class that orchestrates all components"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.is_active = False
        self.portfolio = {}
        self.trades = []
        self.signals = []
        self.risk_manager = RiskManager(config.get('risk', {}))
        self.market_analyzer = MarketAnalyzer(config.get('analysis', {}))
        self.order_executor = OrderExecutor(config.get('execution', {}))
        self.dashboard_data = {}
        
        # Initialize exchange connections
        self.exchanges = {}
        for exchange_name in config.get('exchanges', ['binance']):
            try:
                exchange_class = getattr(ccxt, exchange_name)
                self.exchanges[exchange_name] = exchange_class({
                    'apiKey': config.get('api_keys', {}).get(exchange_name, {}).get('key'),
                    'secret': config.get('api_keys', {}).get(exchange_name, {}).get('secret'),
                    'sandbox': config.get('sandbox', True),  # Use sandbox for safety
                    'enableRateLimit': True,
                })
            except Exception as e:
                print(f"⚠️  Could not initialize {exchange_name}: {e}")
    
    def start(self):
        """Start the trading bot"""
        self.is_active = True
        print("🚀 Trading Bot ACTIVATED")
        
    def stop(self):
        """Stop the trading bot"""
        self.is_active = False
        print("🛑 Trading Bot DEACTIVATED")
    
    def get_status(self) -> Dict:
        """Get current bot status"""
        return {
            'active': self.is_active,
            'portfolio_value': sum(self.portfolio.values()),
            'total_trades': len(self.trades),
            'active_signals': len([s for s in self.signals if s['active']]),
            'risk_score': self.risk_manager.calculate_portfolio_risk(self.portfolio),
            'last_update': datetime.now().isoformat()
        }

class MarketAnalyzer:
    """Advanced market analysis with multiple indicators"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.indicators = {}
        
    def analyze_market(self, symbol: str, timeframe: str = '1h', limit: int = 100) -> Dict:
        """Comprehensive market analysis"""
        try:
            # Get market data (simulated for demo)
            data = self._get_market_data(symbol, timeframe, limit)
            
            # Calculate technical indicators
            indicators = self._calculate_indicators(data)
            
            # Generate trading signals
            signals = self._generate_signals(indicators)
            
            # Market sentiment analysis
            sentiment = self._analyze_sentiment(symbol)
            
            return {
                'symbol': symbol,
                'timeframe': timeframe,
                'price': data['close'].iloc[-1],
                'change_24h': ((data['close'].iloc[-1] - data['close'].iloc[-25]) / data['close'].iloc[-25]) * 100,
                'volume': data['volume'].iloc[-1],
                'indicators': indicators,
                'signals': signals,
                'sentiment': sentiment,
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            return {'error': str(e)}
    
    def _get_market_data(self, symbol: str, timeframe: str, limit: int) -> pd.DataFrame:
        """Get historical market data (simulated)"""
        # Simulate realistic price data
        np.random.seed(42)  # For reproducible results
        
        base_price = 45000 if 'BTC' in symbol else 3000 if 'ETH' in symbol else 1
        dates = pd.date_range(end=datetime.now(), periods=limit, freq='1H')
        
        # Generate realistic OHLCV data
        price_changes = np.random.normal(0, 0.02, limit)
        prices = [base_price]
        
        for change in price_changes[1:]:
            new_price = prices[-1] * (1 + change)
            prices.append(max(new_price, 0.01))  # Ensure positive prices
        
        data = pd.DataFrame({
            'timestamp': dates,
            'open': prices,
            'high': [p * (1 + abs(np.random.normal(0, 0.01))) for p in prices],
            'low': [p * (1 - abs(np.random.normal(0, 0.01))) for p in prices],
            'close': prices,
            'volume': np.random.uniform(1000, 10000, limit)
        })
        
        return data
    
    def _calculate_indicators(self, data: pd.DataFrame) -> Dict:
        """Calculate technical indicators"""
        close = data['close']
        
        # Moving averages
        sma_20 = close.rolling(window=20).mean()
        sma_50 = close.rolling(window=50).mean()
        ema_12 = close.ewm(span=12).mean()
        ema_26 = close.ewm(span=26).mean()
        
        # RSI
        delta = close.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        # MACD
        macd = ema_12 - ema_26
        signal = macd.ewm(span=9).mean()
        histogram = macd - signal
        
        # Bollinger Bands
        bb_middle = close.rolling(window=20).mean()
        bb_std = close.rolling(window=20).std()
        bb_upper = bb_middle + (bb_std * 2)
        bb_lower = bb_middle - (bb_std * 2)
        
        return {
            'sma_20': sma_20.iloc[-1],
            'sma_50': sma_50.iloc[-1],
            'ema_12': ema_12.iloc[-1],
            'ema_26': ema_26.iloc[-1],
            'rsi': rsi.iloc[-1],
            'macd': macd.iloc[-1],
            'macd_signal': signal.iloc[-1],
            'macd_histogram': histogram.iloc[-1],
            'bb_upper': bb_upper.iloc[-1],
            'bb_lower': bb_lower.iloc[-1],
            'bb_middle': bb_middle.iloc[-1],
            'current_price': close.iloc[-1]
        }
    
    def _generate_signals(self, indicators: Dict) -> List[Dict]:
        """Generate trading signals based on indicators"""
        signals = []
        
        # RSI signals
        if indicators['rsi'] < 30:
            signals.append({
                'type': 'BUY',
                'reason': 'RSI Oversold',
                'strength': 0.8,
                'indicator': 'RSI',
                'value': indicators['rsi']
            })
        elif indicators['rsi'] > 70:
            signals.append({
                'type': 'SELL',
                'reason': 'RSI Overbought',
                'strength': 0.8,
                'indicator': 'RSI',
                'value': indicators['rsi']
            })
        
        # MACD signals
        if indicators['macd'] > indicators['macd_signal']:
            signals.append({
                'type': 'BUY',
                'reason': 'MACD Bullish',
                'strength': 0.6,
                'indicator': 'MACD',
                'value': indicators['macd']
            })
        else:
            signals.append({
                'type': 'SELL',
                'reason': 'MACD Bearish',
                'strength': 0.6,
                'indicator': 'MACD',
                'value': indicators['macd']
            })
        
        # Moving average crossover
        if indicators['sma_20'] > indicators['sma_50']:
            signals.append({
                'type': 'BUY',
                'reason': 'MA Golden Cross',
                'strength': 0.7,
                'indicator': 'MA',
                'value': indicators['sma_20']
            })
        
        # Bollinger Bands
        if indicators['current_price'] <= indicators['bb_lower']:
            signals.append({
                'type': 'BUY',
                'reason': 'BB Lower Band Bounce',
                'strength': 0.5,
                'indicator': 'BB',
                'value': indicators['current_price']
            })
        elif indicators['current_price'] >= indicators['bb_upper']:
            signals.append({
                'type': 'SELL',
                'reason': 'BB Upper Band Resistance',
                'strength': 0.5,
                'indicator': 'BB',
                'value': indicators['current_price']
            })
        
        return signals
    
    def _analyze_sentiment(self, symbol: str) -> Dict:
        """Analyze market sentiment (simulated)"""
        # In a real implementation, this would use news APIs, social media, etc.
        sentiment_score = np.random.uniform(-1, 1)
        
        if sentiment_score > 0.3:
            sentiment = 'BULLISH'
        elif sentiment_score < -0.3:
            sentiment = 'BEARISH'
        else:
            sentiment = 'NEUTRAL'
        
        return {
            'score': sentiment_score,
            'label': sentiment,
            'confidence': abs(sentiment_score),
            'sources': ['Twitter', 'Reddit', 'News']
        }

class RiskManager:
    """Advanced risk management system"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.max_position_size = config.get('max_position_size', 0.1)  # 10% of portfolio
        self.max_daily_loss = config.get('max_daily_loss', 0.02)  # 2% daily loss limit
        self.max_drawdown = config.get('max_drawdown', 0.15)  # 15% max drawdown
        self.position_limits = config.get('position_limits', {})
        
    def assess_risk(self, trade_request: Dict, portfolio: Dict) -> Dict:
        """Comprehensive risk assessment"""
        risk_factors = {}
        
        # Position size risk
        position_risk = self._check_position_size(trade_request, portfolio)
        risk_factors['position_size'] = position_risk
        
        # Concentration risk
        concentration_risk = self._check_concentration(trade_request, portfolio)
        risk_factors['concentration'] = concentration_risk
        
        # Volatility risk
        volatility_risk = self._check_volatility(trade_request)
        risk_factors['volatility'] = volatility_risk
        
        # Liquidity risk
        liquidity_risk = self._check_liquidity(trade_request)
        risk_factors['liquidity'] = liquidity_risk
        
        # Calculate overall risk score
        risk_score = self._calculate_risk_score(risk_factors)
        
        return {
            'risk_score': risk_score,
            'risk_factors': risk_factors,
            'approved': risk_score < 0.7,
            'warnings': self._generate_warnings(risk_factors),
            'recommendations': self._generate_recommendations(risk_factors)
        }
    
    def _check_position_size(self, trade_request: Dict, portfolio: Dict) -> Dict:
        """Check position size against limits"""
        portfolio_value = sum(portfolio.values())
        position_value = trade_request.get('quantity', 0) * trade_request.get('price', 0)
        position_percentage = position_value / portfolio_value if portfolio_value > 0 else 0
        
        risk_level = min(position_percentage / self.max_position_size, 1.0)
        
        return {
            'level': risk_level,
            'position_percentage': position_percentage,
            'max_allowed': self.max_position_size,
            'status': 'HIGH' if risk_level > 0.8 else 'MEDIUM' if risk_level > 0.5 else 'LOW'
        }
    
    def _check_concentration(self, trade_request: Dict, portfolio: Dict) -> Dict:
        """Check concentration risk"""
        symbol = trade_request.get('symbol', '')
        current_exposure = portfolio.get(symbol, 0)
        new_exposure = current_exposure + trade_request.get('quantity', 0)
        
        total_portfolio = sum(portfolio.values())
        concentration = new_exposure / total_portfolio if total_portfolio > 0 else 0
        
        risk_level = min(concentration / 0.3, 1.0)  # 30% concentration limit
        
        return {
            'level': risk_level,
            'concentration': concentration,
            'current_exposure': current_exposure,
            'new_exposure': new_exposure,
            'status': 'HIGH' if risk_level > 0.8 else 'MEDIUM' if risk_level > 0.5 else 'LOW'
        }
    
    def _check_volatility(self, trade_request: Dict) -> Dict:
        """Check volatility risk"""
        # Simulate volatility calculation
        symbol = trade_request.get('symbol', '')
        volatility = np.random.uniform(0.1, 0.8)  # Simulated volatility
        
        risk_level = min(volatility / 0.6, 1.0)  # 60% volatility threshold
        
        return {
            'level': risk_level,
            'volatility': volatility,
            'status': 'HIGH' if risk_level > 0.8 else 'MEDIUM' if risk_level > 0.5 else 'LOW'
        }
    
    def _check_liquidity(self, trade_request: Dict) -> Dict:
        """Check liquidity risk"""
        # Simulate liquidity check
        symbol = trade_request.get('symbol', '')
        liquidity_score = np.random.uniform(0.3, 1.0)  # Simulated liquidity
        
        risk_level = 1.0 - liquidity_score
        
        return {
            'level': risk_level,
            'liquidity_score': liquidity_score,
            'status': 'HIGH' if risk_level > 0.8 else 'MEDIUM' if risk_level > 0.5 else 'LOW'
        }
    
    def _calculate_risk_score(self, risk_factors: Dict) -> float:
        """Calculate overall risk score"""
        weights = {
            'position_size': 0.3,
            'concentration': 0.25,
            'volatility': 0.25,
            'liquidity': 0.2
        }
        
        total_risk = sum(
            risk_factors[factor]['level'] * weight
            for factor, weight in weights.items()
        )
        
        return min(total_risk, 1.0)
    
    def _generate_warnings(self, risk_factors: Dict) -> List[str]:
        """Generate risk warnings"""
        warnings = []
        
        for factor, data in risk_factors.items():
            if data['status'] == 'HIGH':
                warnings.append(f"HIGH {factor.upper().replace('_', ' ')} RISK detected")
            elif data['status'] == 'MEDIUM':
                warnings.append(f"MEDIUM {factor.upper().replace('_', ' ')} RISK detected")
        
        return warnings
    
    def _generate_recommendations(self, risk_factors: Dict) -> List[str]:
        """Generate risk recommendations"""
        recommendations = []
        
        if risk_factors['position_size']['level'] > 0.8:
            recommendations.append("Consider reducing position size")
        
        if risk_factors['concentration']['level'] > 0.8:
            recommendations.append("Diversify portfolio to reduce concentration")
        
        if risk_factors['volatility']['level'] > 0.8:
            recommendations.append("Consider adding stop-loss orders")
        
        if risk_factors['liquidity']['level'] > 0.8:
            recommendations.append("Ensure sufficient liquidity for exit")
        
        return recommendations
    
    def calculate_portfolio_risk(self, portfolio: Dict) -> float:
        """Calculate overall portfolio risk"""
        if not portfolio:
            return 0.0
        
        # Simulate portfolio risk calculation
        total_value = sum(portfolio.values())
        positions = len(portfolio)
        
        # Risk increases with concentration and decreases with diversification
        concentration_risk = max(v / total_value for v in portfolio.values())
        diversification_benefit = min(1.0, positions / 10)  # Max benefit at 10+ positions
        
        risk_score = concentration_risk * (1 - diversification_benefit * 0.3)
        
        return min(risk_score, 1.0)

class OrderExecutor:
    """Smart order execution system"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.order_queue = []
        self.executed_orders = []
        
    def place_order(self, order: Dict) -> Dict:
        """Place a trading order"""
        # Validate order
        validation = self._validate_order(order)
        if not validation['valid']:
            return validation
        
        # Add to queue
        order_id = self._generate_order_id()
        order['id'] = order_id
        order['status'] = 'PENDING'
        order['timestamp'] = datetime.now().isoformat()
        
        self.order_queue.append(order)
        
        # Execute immediately (simulated)
        execution_result = self._execute_order(order)
        
        return execution_result
    
    def _validate_order(self, order: Dict) -> Dict:
        """Validate order parameters"""
        required_fields = ['symbol', 'side', 'type', 'quantity']
        
        for field in required_fields:
            if field not in order:
                return {
                    'valid': False,
                    'error': f"Missing required field: {field}"
                }
        
        # Validate order type
        if order['type'] not in ['market', 'limit', 'stop', 'stop_limit']:
            return {
                'valid': False,
                'error': f"Invalid order type: {order['type']}"
            }
        
        # Validate side
        if order['side'] not in ['buy', 'sell']:
            return {
                'valid': False,
                'error': f"Invalid side: {order['side']}"
            }
        
        # Validate quantity
        if order['quantity'] <= 0:
            return {
                'valid': False,
                'error': "Quantity must be positive"
            }
        
        return {'valid': True}
    
    def _execute_order(self, order: Dict) -> Dict:
        """Execute order (simulated)"""
        try:
            # Simulate order execution
            execution_price = order.get('price', 0)
            if order['type'] == 'market':
                # Add some slippage for market orders
                slippage = np.random.uniform(-0.001, 0.001)
                execution_price = execution_price * (1 + slippage)
            
            # Calculate fees
            fee_rate = 0.001  # 0.1% trading fee
            fee = order['quantity'] * execution_price * fee_rate
            
            # Update order status
            order['status'] = 'FILLED'
            order['executed_price'] = execution_price
            order['fee'] = fee
            order['executed_at'] = datetime.now().isoformat()
            
            # Move to executed orders
            self.executed_orders.append(order)
            if order in self.order_queue:
                self.order_queue.remove(order)
            
            return {
                'success': True,
                'order_id': order['id'],
                'status': 'FILLED',
                'executed_price': execution_price,
                'fee': fee,
                'message': f"Order {order['id']} executed successfully"
            }
            
        except Exception as e:
            order['status'] = 'FAILED'
            order['error'] = str(e)
            
            return {
                'success': False,
                'order_id': order['id'],
                'status': 'FAILED',
                'error': str(e)
            }
    
    def _generate_order_id(self) -> str:
        """Generate unique order ID"""
        return f"ORD_{int(time.time() * 1000)}"
    
    def get_order_status(self, order_id: str) -> Dict:
        """Get order status"""
        # Check executed orders
        for order in self.executed_orders:
            if order['id'] == order_id:
                return order
        
        # Check pending orders
        for order in self.order_queue:
            if order['id'] == order_id:
                return order
        
        return {'error': 'Order not found'}

print("✅ Core Trading Suite Classes Created Successfully!")
print("📊 Components: TradingBot, MarketAnalyzer, RiskManager, OrderExecutor")