# Initialize and test the trading suite
import json

# ========== CONFIGURATION ==========
trading_config = {
    'exchanges': ['binance'],  # We'll use demo/sandbox mode
    'sandbox': True,  # Safe testing mode
    'api_keys': {
        'binance': {
            'key': 'DEMO_API_KEY',
            'secret': 'DEMO_SECRET_KEY'
        }
    },
    'risk': {
        'max_position_size': 0.1,     # 10% max position
        'max_daily_loss': 0.02,       # 2% daily loss limit
        'max_drawdown': 0.15,         # 15% max drawdown
        'stop_loss_percent': 0.05,    # 5% stop loss
    },
    'analysis': {
        'indicators': ['RSI', 'MACD', 'BB', 'MA'],
        'timeframes': ['1m', '5m', '15m', '1h', '4h', '1d'],
        'sentiment_sources': ['twitter', 'reddit', 'news']
    },
    'execution': {
        'default_order_type': 'limit',
        'slippage_tolerance': 0.005,  # 0.5%
        'max_order_size': 10000,      # Max order size in USD
    },
    'portfolio': {
        'starting_balance': 100000,   # $100,000 starting balance
        'currency': 'USD',
        'max_positions': 20,          # Max number of open positions
    }
}

# ========== INITIALIZE TRADING BOT ==========
print("🚀 Initializing Trading Suite...")
trading_bot = TradingBot(trading_config)

# ========== DEMO TRADING OPERATIONS ==========
print("\n📊 Running Market Analysis...")

# Test market analysis for popular crypto pairs
test_symbols = ['BTC/USDT', 'ETH/USDT', 'BNB/USDT']
market_analysis = {}

for symbol in test_symbols:
    analysis = trading_bot.market_analyzer.analyze_market(symbol)
    market_analysis[symbol] = analysis
    print(f"  ✅ {symbol}: ${analysis['price']:.2f} ({analysis['change_24h']:+.2f}%)")

# Test risk assessment
print("\n🛡️  Testing Risk Management...")
test_trade = {
    'symbol': 'BTC/USDT',
    'side': 'buy',
    'type': 'market',
    'quantity': 0.1,
    'price': 45000
}

risk_assessment = trading_bot.risk_manager.assess_risk(test_trade, trading_bot.portfolio)
print(f"  Risk Score: {risk_assessment['risk_score']:.2f}")
print(f"  Status: {'✅ APPROVED' if risk_assessment['approved'] else '❌ REJECTED'}")

# Test order execution
print("\n💼 Testing Order Execution...")
if risk_assessment['approved']:
    order_result = trading_bot.order_executor.place_order(test_trade)
    print(f"  Order Status: {'✅ FILLED' if order_result['success'] else '❌ FAILED'}")
    if order_result['success']:
        print(f"  Executed Price: ${order_result['executed_price']:.2f}")
        print(f"  Fee: ${order_result['fee']:.2f}")

# Start the bot
print("\n🎯 Starting Trading Bot...")
trading_bot.start()

# Get bot status
status = trading_bot.get_status()
print(f"  Status: {'🟢 ACTIVE' if status['active'] else '🔴 INACTIVE'}")
print(f"  Portfolio Value: ${status['portfolio_value']:.2f}")
print(f"  Total Trades: {status['total_trades']}")
print(f"  Risk Score: {status['risk_score']:.2f}")

# Save analysis data for dashboard
dashboard_data = {
    'bot_status': status,
    'market_analysis': market_analysis,
    'risk_assessment': risk_assessment,
    'config': trading_config,
    'timestamp': datetime.now().isoformat()
}

# Save to JSON file for dashboard
with open('trading_dashboard_data.json', 'w') as f:
    json.dump(dashboard_data, f, indent=2)

print("\n✅ Trading Suite Initialized Successfully!")
print("📁 Dashboard data saved to: trading_dashboard_data.json")
print("🎮 Bot is ready for trading operations!")

# Display current signals
print("\n📡 Current Trading Signals:")
for symbol, analysis in market_analysis.items():
    if analysis.get('signals'):
        print(f"\n{symbol}:")
        for signal in analysis['signals']:
            strength_bar = "🟢" * int(signal['strength'] * 5)
            print(f"  {signal['type']} - {signal['reason']} {strength_bar} ({signal['strength']:.1f})")
    else:
        print(f"{symbol}: No signals")