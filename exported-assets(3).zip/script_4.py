# Create advanced trading dashboard data and visualizations
import pandas as pd
import json
from datetime import datetime, timedelta

# ========== GENERATE COMPREHENSIVE DASHBOARD DATA ==========

print("📊 Creating Advanced Trading Dashboard...")

# Create sample portfolio data
portfolio_data = {
    'BTC': 0.5,
    'ETH': 2.0,
    'BNB': 100.0,
    'USDT': 50000.0
}

# Create sample trading history
trading_history = []
for i in range(10):
    trade = {
        'id': f'TRADE_{i+1:03d}',
        'timestamp': (datetime.now() - timedelta(hours=i*2)).isoformat(),
        'symbol': ['BTC/USDT', 'ETH/USDT', 'BNB/USDT'][i % 3],
        'side': ['buy', 'sell'][i % 2],
        'quantity': round(np.random.uniform(0.1, 2.0), 3),
        'price': round(np.random.uniform(35000, 45000), 2),
        'fee': round(np.random.uniform(1, 10), 2),
        'pnl': round(np.random.uniform(-500, 1000), 2),
        'status': 'FILLED'
    }
    trading_history.append(trade)

# Create performance metrics
performance_metrics = {
    'total_trades': len(trading_history),
    'winning_trades': len([t for t in trading_history if t['pnl'] > 0]),
    'losing_trades': len([t for t in trading_history if t['pnl'] <= 0]),
    'total_pnl': sum([t['pnl'] for t in trading_history]),
    'avg_trade_pnl': sum([t['pnl'] for t in trading_history]) / len(trading_history),
    'win_rate': len([t for t in trading_history if t['pnl'] > 0]) / len(trading_history) * 100,
    'max_drawdown': 12.5,
    'sharpe_ratio': 1.85,
    'total_fees': sum([t['fee'] for t in trading_history]),
    'portfolio_value': 125000.0,
    'daily_return': 2.3,
    'monthly_return': 15.8
}

# Create price data for charts
price_data = {}
for symbol in ['BTC/USDT', 'ETH/USDT', 'BNB/USDT']:
    base_price = 45000 if 'BTC' in symbol else 3000 if 'ETH' in symbol else 1
    prices = []
    timestamps = []
    
    for i in range(100):
        timestamp = datetime.now() - timedelta(hours=i)
        price = base_price * (1 + np.random.normal(0, 0.02))
        prices.append(round(price, 2))
        timestamps.append(timestamp.isoformat())
    
    price_data[symbol] = {
        'timestamps': timestamps[::-1],  # Reverse to get chronological order
        'prices': prices[::-1]
    }

# Create comprehensive dashboard data
comprehensive_dashboard_data = {
    'bot_status': {
        'active': True,
        'mode': 'LIVE_TRADING',
        'uptime': '2h 35m',
        'last_trade': '5 minutes ago',
        'active_orders': 3,
        'total_signals': 12
    },
    'portfolio': {
        'total_value': 125000.0,
        'available_balance': 50000.0,
        'positions': portfolio_data,
        'allocation': {
            'BTC': 35.0,
            'ETH': 25.0,
            'BNB': 15.0,
            'USDT': 25.0
        }
    },
    'performance': performance_metrics,
    'trading_history': trading_history,
    'price_data': price_data,
    'risk_metrics': {
        'current_risk_score': 0.35,
        'risk_level': 'MEDIUM',
        'var_1d': 2500.0,
        'var_1w': 8500.0,
        'beta': 1.2,
        'correlation_btc': 0.85
    },
    'market_overview': {
        'total_market_cap': 1850000000000,
        'btc_dominance': 52.3,
        'fear_greed_index': 45,
        'volatility_index': 28.5,
        'trending_coins': ['BTC', 'ETH', 'SOL', 'BNB', 'ADA']
    },
    'alerts': [
        {
            'type': 'INFO',
            'message': 'BTC broke above $45,000 resistance',
            'timestamp': datetime.now().isoformat()
        },
        {
            'type': 'WARNING',
            'message': 'High volatility detected in ETH/USDT',
            'timestamp': (datetime.now() - timedelta(minutes=15)).isoformat()
        },
        {
            'type': 'SUCCESS',
            'message': 'Order BTC_001 filled successfully',
            'timestamp': (datetime.now() - timedelta(minutes=5)).isoformat()
        }
    ],
    'timestamp': datetime.now().isoformat()
}

# Save comprehensive dashboard data
with open('comprehensive_trading_dashboard.json', 'w') as f:
    json.dump(comprehensive_dashboard_data, f, indent=2)

print("✅ Comprehensive dashboard data created")

# Create CSV file for trading history
df_trades = pd.DataFrame(trading_history)
df_trades.to_csv('trading_history.csv', index=False)

print("✅ Trading history CSV created")

# Create portfolio summary
portfolio_summary = pd.DataFrame([
    {'Asset': asset, 'Quantity': qty, 'Value_USD': qty * 
     (45000 if asset == 'BTC' else 3000 if asset == 'ETH' else 1 if asset == 'BNB' else 1)}
    for asset, qty in portfolio_data.items()
])
portfolio_summary.to_csv('portfolio_summary.csv', index=False)

print("✅ Portfolio summary CSV created")

# Display key metrics
print("\n🎯 KEY PERFORMANCE METRICS:")
print(f"  📈 Total Portfolio Value: ${performance_metrics['portfolio_value']:,.2f}")
print(f"  💰 Total P&L: ${performance_metrics['total_pnl']:,.2f}")
print(f"  📊 Win Rate: {performance_metrics['win_rate']:.1f}%")
print(f"  📉 Max Drawdown: {performance_metrics['max_drawdown']:.1f}%")
print(f"  🎲 Sharpe Ratio: {performance_metrics['sharpe_ratio']:.2f}")
print(f"  📅 Daily Return: {performance_metrics['daily_return']:.1f}%")

print("\n🔄 CURRENT POSITIONS:")
for asset, quantity in portfolio_data.items():
    if asset != 'USDT':
        price = 45000 if asset == 'BTC' else 3000 if asset == 'ETH' else 1
        value = quantity * price
        print(f"  {asset}: {quantity} units (${value:,.2f})")

print("\n📊 Files created:")
print("  - comprehensive_trading_dashboard.json")
print("  - trading_history.csv")
print("  - portfolio_summary.csv")
print("  - trading_dashboard_data.json (from earlier)")

print("\n🎮 Ready to create web dashboard interface!")