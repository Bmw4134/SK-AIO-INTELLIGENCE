// Crypto Trading Dashboard Application
class CryptoTradingDashboard {
    constructor() {
        // Application data from the provided JSON
        this.data = {
            "timestamp": "2025-07-18T05:51:28.388086",
            "market_overview": {
                "total_crypto_market_cap": 1234567890000,
                "average_24h_change": 12.2,
                "cryptocurrencies_tracked": 9,
                "trending_direction": "UP"
            },
            "top_movers": [
                {"symbol": "DOGECOIN", "name": "Dogecoin", "price": 0.24, "change_24h": 14.49, "volume": 14749610821},
                {"symbol": "CARDANO", "name": "Cardano", "price": 0.88, "change_24h": 14.18, "volume": 2894563657},
                {"symbol": "CHAINLINK", "name": "Chainlink", "price": 19.03, "change_24h": 14.02, "volume": 1382651583},
                {"symbol": "AVALANCHE-2", "name": "Avalanche", "price": 24.89, "change_24h": 10.77, "volume": 1317474833},
                {"symbol": "POLKADOT", "name": "Polkadot", "price": 4.59, "change_24h": 10.06, "volume": 681118017}
            ],
            "sentiment_analysis": {
                "positive_percentage": 11.1,
                "negative_percentage": 0.0,
                "neutral_percentage": 88.9,
                "total_articles_analyzed": 18
            },
            "trading_signals": [
                {
                    "asset": "CRYPTO",
                    "signal": "HOLD",
                    "confidence": "MEDIUM",
                    "strength": 8.3,
                    "reason": "Mixed crypto sentiment (Pos: 8.3%, Neg: 0.0%)",
                    "source": "Crypto News Analysis",
                    "timestamp": "2025-07-18T05:51:28.388086"
                },
                {
                    "asset": "AVALANCHE-2",
                    "signal": "MOMENTUM_BUY",
                    "confidence": "HIGH",
                    "strength": 10.77,
                    "reason": "Strong positive momentum (+10.77% in 24h)",
                    "source": "Price Movement Analysis",
                    "timestamp": "2025-07-18T05:51:28.388086"
                },
                {
                    "asset": "CARDANO",
                    "signal": "MOMENTUM_BUY",
                    "confidence": "HIGH",
                    "strength": 14.18,
                    "reason": "Strong positive momentum (+14.18% in 24h)",
                    "source": "Price Movement Analysis",
                    "timestamp": "2025-07-18T05:51:28.388086"
                },
                {
                    "asset": "CHAINLINK",
                    "signal": "MOMENTUM_BUY",
                    "confidence": "HIGH",
                    "strength": 14.02,
                    "reason": "Strong positive momentum (+14.02% in 24h)",
                    "source": "Price Movement Analysis",
                    "timestamp": "2025-07-18T05:51:28.388086"
                },
                {
                    "asset": "DOGECOIN",
                    "signal": "MOMENTUM_BUY",
                    "confidence": "HIGH",
                    "strength": 14.49,
                    "reason": "Strong positive momentum (+14.49% in 24h)",
                    "source": "Price Movement Analysis",
                    "timestamp": "2025-07-18T05:51:28.388086"
                },
                {
                    "asset": "POLKADOT",
                    "signal": "MOMENTUM_BUY",
                    "confidence": "HIGH",
                    "strength": 10.06,
                    "reason": "Strong positive momentum (+10.06% in 24h)",
                    "source": "Price Movement Analysis",
                    "timestamp": "2025-07-18T05:51:28.388086"
                }
            ],
            "news_summary": [
                {
                    "title": "Bitcoin Surges Above $120,000 as Institutional Adoption Accelerates",
                    "source": "CoinTelegraph",
                    "published": "2025-07-18T05:30:00Z",
                    "category": "crypto",
                    "link": "https://example.com/bitcoin-surge"
                },
                {
                    "title": "Ethereum 2.0 Upgrade Shows Promising Results",
                    "source": "Decrypt",
                    "published": "2025-07-18T04:45:00Z",
                    "category": "crypto",
                    "link": "https://example.com/ethereum-upgrade"
                },
                {
                    "title": "DeFi Protocols Experience Record Volume",
                    "source": "Bitcoinist",
                    "published": "2025-07-18T04:15:00Z",
                    "category": "crypto",
                    "link": "https://example.com/defi-volume"
                },
                {
                    "title": "Stock Market Opens Higher on Tech Earnings",
                    "source": "MarketWatch",
                    "published": "2025-07-18T05:00:00Z",
                    "category": "stocks",
                    "link": "https://example.com/stock-earnings"
                }
            ]
        };
        
        this.charts = {};
        this.botActive = true;
        this.autoRefresh = true;
        this.refreshInterval = null;
        
        this.init();
    }
    
    init() {
        this.showLoading();
        this.setupEventListeners();
        this.renderDashboard();
        this.setupAutoRefresh();
        this.hideLoading();
    }
    
    setupEventListeners() {
        // Refresh data button
        document.getElementById('refreshData').addEventListener('click', () => {
            this.refreshData();
        });
        
        // Auto-refresh toggle
        document.getElementById('autoRefresh').addEventListener('change', (e) => {
            this.autoRefresh = e.target.checked;
            if (this.autoRefresh) {
                this.setupAutoRefresh();
                this.showNotification('Auto-refresh enabled', 'success');
            } else {
                this.clearAutoRefresh();
                this.showNotification('Auto-refresh disabled', 'info');
            }
        });
        
        // Emergency stop button
        document.getElementById('emergencyStop').addEventListener('click', () => {
            this.emergencyStop();
        });
        
        // Refresh news button
        document.getElementById('refreshNews').addEventListener('click', () => {
            this.refreshNews();
        });
    }
    
    renderDashboard() {
        this.updateTimestamp();
        this.renderMarketStatus();
        this.renderMarketOverview();
        this.renderTradingSignals();
        this.renderNews();
        this.renderTechnicalAnalysis();
        this.renderCharts();
    }
    
    updateTimestamp() {
        const now = new Date();
        const timestamp = now.toLocaleString('en-US', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });
        document.getElementById('currentTime').textContent = timestamp;
    }
    
    renderMarketStatus() {
        const marketIndicator = document.getElementById('marketIndicator');
        const marketStatusText = document.getElementById('marketStatusText');
        const sentimentScore = document.getElementById('sentimentScore');
        
        // Update market status based on trending direction
        if (this.data.market_overview.trending_direction === 'UP') {
            marketIndicator.className = 'status-indicator positive';
            marketStatusText.textContent = 'Bullish Market';
        } else {
            marketIndicator.className = 'status-indicator negative';
            marketStatusText.textContent = 'Bearish Market';
        }
        
        // Update sentiment score
        sentimentScore.textContent = `${this.data.sentiment_analysis.positive_percentage.toFixed(1)}/10`;
    }
    
    renderMarketOverview() {
        // Update total market cap
        const totalMarketCap = document.getElementById('totalMarketCap');
        totalMarketCap.textContent = this.formatCurrency(this.data.market_overview.total_crypto_market_cap);
        
        // Render crypto movers
        const cryptoMovers = document.getElementById('cryptoMovers');
        cryptoMovers.innerHTML = '';
        
        this.data.top_movers.forEach(crypto => {
            const cryptoCard = document.createElement('div');
            cryptoCard.className = 'crypto-card';
            cryptoCard.innerHTML = `
                <div class="crypto-header">
                    <div class="crypto-symbol">${crypto.symbol}</div>
                </div>
                <div class="crypto-name">${crypto.name}</div>
                <div class="crypto-price">$${crypto.price.toFixed(2)}</div>
                <div class="crypto-change ${crypto.change_24h >= 0 ? 'positive' : 'negative'}">
                    ${crypto.change_24h >= 0 ? '+' : ''}${crypto.change_24h.toFixed(2)}%
                </div>
                <div class="crypto-volume">
                    Volume: ${this.formatVolume(crypto.volume)}
                </div>
            `;
            cryptoMovers.appendChild(cryptoCard);
        });
    }
    
    renderTradingSignals() {
        const signalsContainer = document.getElementById('signalsContainer');
        const signalsCount = document.getElementById('signalsCount');
        
        signalsContainer.innerHTML = '';
        signalsCount.textContent = `${this.data.trading_signals.length} Active Signals`;
        
        this.data.trading_signals.forEach(signal => {
            const signalCard = document.createElement('div');
            signalCard.className = 'signal-card';
            
            const signalType = signal.signal.toLowerCase().replace('_', ' ');
            const signalTypeClass = signal.signal.toLowerCase().replace('_', '');
            
            signalCard.innerHTML = `
                <div class="signal-header">
                    <div class="signal-asset">${this.getAssetDisplayName(signal.asset)}</div>
                    <div class="signal-type ${signalTypeClass}">${signalType}</div>
                </div>
                <div class="signal-meta">
                    <div class="signal-confidence ${signal.confidence.toLowerCase()}">
                        ${signal.confidence} Confidence
                    </div>
                    <div class="signal-strength">
                        Strength: ${signal.strength.toFixed(1)}%
                    </div>
                </div>
                <div class="signal-reason">${signal.reason}</div>
                <div class="signal-source">${signal.source}</div>
            `;
            signalsContainer.appendChild(signalCard);
        });
    }
    
    renderNews() {
        const newsGrid = document.getElementById('newsGrid');
        newsGrid.innerHTML = '';
        
        this.data.news_summary.forEach(article => {
            const newsCard = document.createElement('div');
            newsCard.className = 'news-card';
            newsCard.setAttribute('tabindex', '0');
            
            const publishedDate = new Date(article.published).toLocaleDateString();
            
            newsCard.innerHTML = `
                <div class="news-title">${article.title}</div>
                <div class="news-meta">
                    <div class="news-source">${article.source}</div>
                    <div class="news-date">${publishedDate}</div>
                </div>
                <div class="news-category ${article.category}">${article.category}</div>
            `;
            
            newsCard.addEventListener('click', () => {
                window.open(article.link, '_blank');
            });
            
            newsCard.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    window.open(article.link, '_blank');
                }
            });
            
            newsGrid.appendChild(newsCard);
        });
    }
    
    renderTechnicalAnalysis() {
        const analysisGrid = document.getElementById('analysisGrid');
        analysisGrid.innerHTML = '';
        
        // Generate technical analysis for top movers
        this.data.top_movers.forEach(crypto => {
            const analysisCard = document.createElement('div');
            analysisCard.className = 'analysis-card';
            
            // Generate mock technical indicators
            const rsi = 30 + Math.random() * 40; // RSI between 30-70
            const macd = (Math.random() - 0.5) * 10; // MACD between -5 and 5
            const sma20 = crypto.price * (0.95 + Math.random() * 0.1); // SMA20 around current price
            const ema50 = crypto.price * (0.90 + Math.random() * 0.2); // EMA50 around current price
            const support = crypto.price * (0.85 + Math.random() * 0.1);
            const resistance = crypto.price * (1.05 + Math.random() * 0.1);
            
            analysisCard.innerHTML = `
                <div class="analysis-header">
                    <div class="analysis-asset">${crypto.name}</div>
                </div>
                <div class="analysis-indicators">
                    <div class="indicator-row">
                        <span class="indicator-name">RSI (14)</span>
                        <span class="indicator-value">${rsi.toFixed(1)}</span>
                    </div>
                    <div class="indicator-row">
                        <span class="indicator-name">MACD</span>
                        <span class="indicator-value">${macd.toFixed(2)}</span>
                    </div>
                    <div class="indicator-row">
                        <span class="indicator-name">SMA (20)</span>
                        <span class="indicator-value">$${sma20.toFixed(2)}</span>
                    </div>
                    <div class="indicator-row">
                        <span class="indicator-name">EMA (50)</span>
                        <span class="indicator-value">$${ema50.toFixed(2)}</span>
                    </div>
                </div>
                <div class="support-resistance">
                    <h4>Support/Resistance</h4>
                    <div class="sr-levels">
                        <div class="sr-level">
                            <div class="sr-label">Support</div>
                            <div class="sr-value support">$${support.toFixed(2)}</div>
                        </div>
                        <div class="sr-level">
                            <div class="sr-label">Resistance</div>
                            <div class="sr-value resistance">$${resistance.toFixed(2)}</div>
                        </div>
                    </div>
                </div>
            `;
            
            analysisGrid.appendChild(analysisCard);
        });
    }
    
    renderCharts() {
        this.renderPriceChangesChart();
        this.renderSentimentChart();
    }
    
    renderPriceChangesChart() {
        const canvas = document.getElementById('priceChangesChart');
        const ctx = canvas.getContext('2d');
        
        // Destroy existing chart if it exists
        if (this.charts.priceChanges) {
            this.charts.priceChanges.destroy();
        }
        
        const labels = this.data.top_movers.map(crypto => crypto.name);
        const data = this.data.top_movers.map(crypto => crypto.change_24h);
        const colors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F'];
        
        this.charts.priceChanges = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: '24h Change (%)',
                    data: data,
                    backgroundColor: colors,
                    borderColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.parsed.y.toFixed(2)}%`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    }
    
    renderSentimentChart() {
        const canvas = document.getElementById('sentimentChart');
        const ctx = canvas.getContext('2d');
        
        // Destroy existing chart if it exists
        if (this.charts.sentiment) {
            this.charts.sentiment.destroy();
        }
        
        const sentiment = this.data.sentiment_analysis;
        const labels = ['Positive', 'Negative', 'Neutral'];
        const data = [sentiment.positive_percentage, sentiment.negative_percentage, sentiment.neutral_percentage];
        const colors = ['#1FB8CD', '#B4413C', '#ECEBD5'];
        
        this.charts.sentiment = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: colors,
                    borderColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            font: {
                                size: 12
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.parsed.toFixed(1)}%`;
                            }
                        }
                    }
                }
            }
        });
    }
    
    refreshData() {
        this.showLoading();
        this.showNotification('Refreshing market data...', 'info');
        
        // Simulate API call delay
        setTimeout(() => {
            // Simulate small price changes
            this.data.top_movers.forEach(crypto => {
                const change = (Math.random() - 0.5) * 0.5; // Random change up to 0.5%
                crypto.price += crypto.price * (change / 100);
                crypto.change_24h += change;
                
                // Add some elements update animation
                const element = document.querySelector(`.crypto-card:nth-child(${this.data.top_movers.indexOf(crypto) + 1})`);
                if (element) {
                    element.classList.add('data-update');
                    setTimeout(() => element.classList.remove('data-update'), 500);
                }
            });
            
            // Update sentiment slightly
            this.data.sentiment_analysis.positive_percentage += (Math.random() - 0.5) * 2;
            this.data.sentiment_analysis.negative_percentage += (Math.random() - 0.5) * 1;
            this.data.sentiment_analysis.neutral_percentage = 100 - this.data.sentiment_analysis.positive_percentage - this.data.sentiment_analysis.negative_percentage;
            
            this.renderDashboard();
            this.hideLoading();
            this.showNotification('Market data refreshed successfully', 'success');
        }, 1000);
    }
    
    refreshNews() {
        this.showNotification('Refreshing news feed...', 'info');
        
        // Simulate news refresh
        setTimeout(() => {
            this.showNotification('News feed updated', 'success');
        }, 500);
    }
    
    emergencyStop() {
        this.botActive = false;
        this.clearAutoRefresh();
        
        const botStatus = document.getElementById('botStatus');
        botStatus.textContent = 'OFF';
        botStatus.className = 'status-indicator inactive';
        
        const autoRefreshToggle = document.getElementById('autoRefresh');
        autoRefreshToggle.checked = false;
        this.autoRefresh = false;
        
        this.showNotification('EMERGENCY STOP ACTIVATED - All trading operations halted', 'error');
    }
    
    setupAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
        
        if (this.autoRefresh) {
            this.refreshInterval = setInterval(() => {
                this.updateTimestamp();
                // Refresh data every 30 seconds
                if (Date.now() % 30000 < 5000) {
                    this.refreshData();
                }
            }, 5000);
        }
    }
    
    clearAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }
    
    showLoading() {
        const loadingOverlay = document.getElementById('loadingOverlay');
        loadingOverlay.classList.add('show');
    }
    
    hideLoading() {
        const loadingOverlay = document.getElementById('loadingOverlay');
        loadingOverlay.classList.remove('show');
    }
    
    showNotification(message, type = 'info') {
        const notificationContainer = document.getElementById('notifications');
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-title">${this.getNotificationTitle(type)}</div>
            <div class="notification-message">${message}</div>
        `;
        
        notificationContainer.appendChild(notification);
        
        // Show notification with animation
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        // Remove notification after 4 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notificationContainer.contains(notification)) {
                    notificationContainer.removeChild(notification);
                }
            }, 300);
        }, 4000);
    }
    
    getNotificationTitle(type) {
        const titles = {
            'success': 'Success',
            'error': 'Error',
            'warning': 'Warning',
            'info': 'Info'
        };
        return titles[type] || 'Notification';
    }
    
    formatCurrency(amount) {
        if (amount >= 1e12) {
            return `$${(amount / 1e12).toFixed(2)}T`;
        } else if (amount >= 1e9) {
            return `$${(amount / 1e9).toFixed(2)}B`;
        } else if (amount >= 1e6) {
            return `$${(amount / 1e6).toFixed(2)}M`;
        } else if (amount >= 1e3) {
            return `$${(amount / 1e3).toFixed(2)}K`;
        } else {
            return `$${amount.toFixed(2)}`;
        }
    }
    
    formatVolume(volume) {
        if (volume >= 1e9) {
            return `$${(volume / 1e9).toFixed(2)}B`;
        } else if (volume >= 1e6) {
            return `$${(volume / 1e6).toFixed(2)}M`;
        } else if (volume >= 1e3) {
            return `$${(volume / 1e3).toFixed(2)}K`;
        } else {
            return `$${volume.toFixed(2)}`;
        }
    }
    
    getAssetDisplayName(asset) {
        const assetNames = {
            'CRYPTO': 'General Crypto',
            'BITCOIN': 'Bitcoin',
            'ETHEREUM': 'Ethereum',
            'DOGECOIN': 'Dogecoin',
            'CARDANO': 'Cardano',
            'CHAINLINK': 'Chainlink',
            'AVALANCHE-2': 'Avalanche',
            'POLKADOT': 'Polkadot'
        };
        return assetNames[asset] || asset;
    }
    
    destroy() {
        this.clearAutoRefresh();
        Object.values(this.charts).forEach(chart => {
            if (chart && typeof chart.destroy === 'function') {
                chart.destroy();
            }
        });
    }
}

// Initialize the dashboard when the page loads
let dashboard;
document.addEventListener('DOMContentLoaded', () => {
    dashboard = new CryptoTradingDashboard();
});

// Clean up on page unload
window.addEventListener('beforeunload', () => {
    if (dashboard) {
        dashboard.destroy();
    }
});

// Update timestamp every second
setInterval(() => {
    if (dashboard) {
        dashboard.updateTimestamp();
    }
}, 1000);