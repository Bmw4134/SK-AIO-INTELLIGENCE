import plotly.graph_objects as go
import plotly.express as px

# Data for top 5 crypto movers
crypto_data = [
    {"symbol": "DOGECOIN", "price": 0.24, "change_24h": 14.49},
    {"symbol": "CARDANO", "price": 0.88, "change_24h": 14.18},
    {"symbol": "CHAINLINK", "price": 19.03, "change_24h": 14.02},
    {"symbol": "AVALANCHE-2", "price": 24.89, "change_24h": 10.77},
    {"symbol": "POLKADOT", "price": 4.59, "change_24h": 10.06}
]

# Extract data for plotting
symbols = [item["symbol"] for item in crypto_data]
changes = [item["change_24h"] for item in crypto_data]
prices = [item["price"] for item in crypto_data]

# Shorten symbol names to fit 15 char limit
short_symbols = []
for symbol in symbols:
    if symbol == "AVALANCHE-2":
        short_symbols.append("AVALANCHE")
    else:
        short_symbols.append(symbol[:15])

# Brand colors
colors = ["#1FB8CD", "#FFC185", "#ECEBD5", "#5D878F", "#D2BA4C"]

# Create bar chart
fig = go.Figure(data=[
    go.Bar(
        x=short_symbols,
        y=changes,
        marker_color=colors,
        text=[f"+{change:.2f}%" for change in changes],
        textposition='outside',
        cliponaxis=False,
        hovertemplate='<b>%{x}</b><br>' +
                      'Price: $%{customdata:.2f}<br>' +
                      'Change: +%{y:.2f}%<br>' +
                      '<extra></extra>',
        customdata=prices
    )
])

# Update layout
fig.update_layout(
    title="Top 5 Crypto 24h Gains",
    xaxis_title="Crypto",
    yaxis_title="Change (%)",
    showlegend=False
)

# Save the chart
fig.write_image("crypto_movers.png")