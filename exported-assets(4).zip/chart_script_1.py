import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

# Portfolio allocation data
data = {
    "asset": ["CASH", "DOGECOIN", "CARDANO", "CHAINLINK", "AVALANCHE", "POLKADOT"],
    "value": [4000, 2000, 1000, 1000, 1000, 1000],
    "percentage": [40, 20, 10, 10, 10, 10]
}

df = pd.DataFrame(data)

# Define colors using the brand palette in order
colors = ['#1FB8CD', '#FFC185', '#ECEBD5', '#5D878F', '#D2BA4C', '#B4413C']

# Create pie chart with comprehensive information
fig = go.Figure(data=[go.Pie(
    labels=df['asset'],
    values=df['value'],
    hole=0.4,
    marker=dict(colors=colors, line=dict(color='#FFFFFF', width=3)),
    textinfo='label+percent',
    textposition='inside',
    textfont=dict(size=14, color='white', family='Arial Black'),
    hovertemplate='<b>%{label}</b><br>Value: $%{value:,.0f}<br>Share: %{percent}<br><b>Portfolio Info:</b><br>Total: $10k<br>Trades: 6<br>Signals: 9 (5 BUY, 4 WATCH)<br>Systems: All Active<extra></extra>'
)])

# Add center text annotation
fig.add_annotation(
    text="<b>$10k</b><br>Portfolio<br>6 Trades<br>9 Signals<br>All Systems<br>Active",
    x=0.5, y=0.5,
    font=dict(size=16, color='#13343B'),
    showarrow=False,
    align="center"
)

# Update layout with comprehensive title and styling
fig.update_layout(
    title='Trading Suite: Portfolio + Status',
    uniformtext_minsize=12,
    uniformtext_mode='hide',
    legend=dict(
        orientation='h', 
        yanchor='bottom', 
        y=1.05, 
        xanchor='center', 
        x=0.5,
        font=dict(size=12)
    ),
    font=dict(size=14),
    annotations=[
        dict(
            text="Systems: Market Data, Web Crawler, Trading Bot, Risk Mgmt, Dashboard (All Active)",
            x=0.5, y=-0.15,
            xref="paper", yref="paper",
            font=dict(size=10, color='#13343B'),
            showarrow=False,
            align="center"
        )
    ]
)

# Save the chart
fig.write_image('trading_suite_overview.png')