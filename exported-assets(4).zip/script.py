# First, let's get real market data using actual APIs
import requests
import json
import pandas as pd
from datetime import datetime, timedelta
import time

# Get real crypto prices from CoinGecko (free API)
def get_real_crypto_prices():
    """Get real-time crypto prices from CoinGecko"""
    try:
        url = "https://api.coingecko.com/api/v3/simple/price"
        params = {
            'ids': 'bitcoin,ethereum,binancecoin,cardano,solana,dogecoin,polygon,chainlink,avalanche-2,polkadot',
            'vs_currencies': 'usd',
            'include_24hr_change': 'true',
            'include_24hr_vol': 'true',
            'include_market_cap': 'true'
        }
        
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        print("✅ Successfully retrieved real crypto market data")
        return data
    except Exception as e:
        print(f"❌ Error getting crypto data: {e}")
        return None

# Get real stock data from Alpha Vantage (free tier)
def get_real_stock_data():
    """Get real stock data - using free financial API"""
    try:
        # Using a public financial API
        url = "https://financialmodelingprep.com/api/v3/quote/TSLA,AAPL,MSFT,GOOGL,AMZN"
        
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            print("✅ Successfully retrieved real stock data")
            return data
        else:
            print(f"⚠️  Stock API returned status {response.status_code}")
            return None
    except Exception as e:
        print(f"❌ Error getting stock data: {e}")
        return None

# Get the data
print("🔄 Fetching real market data...")
crypto_data = get_real_crypto_prices()
stock_data = get_real_stock_data()

if crypto_data:
    print("\n📊 Real Crypto Prices:")
    for coin, info in crypto_data.items():
        price = info['usd']
        change = info.get('usd_24h_change', 0)
        volume = info.get('usd_24h_vol', 0)
        market_cap = info.get('usd_market_cap', 0)
        
        print(f"{coin.upper():>12}: ${price:>10,.2f} | 24h: {change:>6.2f}% | Vol: ${volume:>15,.0f}")

if stock_data:
    print("\n📈 Real Stock Prices:")
    for stock in stock_data:
        symbol = stock.get('symbol', 'N/A')
        price = stock.get('price', 0)
        change = stock.get('change', 0)
        change_percent = stock.get('changesPercentage', 0)
        
        print(f"{symbol:>6}: ${price:>8.2f} | Change: ${change:>6.2f} ({change_percent:>5.2f}%)")

# Create a proper market data structure
market_data = {
    'crypto': crypto_data if crypto_data else {},
    'stocks': stock_data if stock_data else [],
    'last_updated': datetime.now().isoformat()
}

print(f"\n✅ Market data compiled at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")