# Install required packages for headless browser automation
import subprocess
import sys

def install_package(package):
    """Install a package using pip"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"✅ Installed {package}")
    except Exception as e:
        print(f"❌ Failed to install {package}: {e}")

# Install headless browser packages
packages = [
    "selenium",
    "undetected-chromedriver",
    "webdriver-manager",
    "requests-html",
    "playwright"
]

print("🔄 Installing headless browser packages...")
for package in packages:
    install_package(package)

print("\n✅ All packages installed successfully!")