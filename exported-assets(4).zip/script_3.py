# Create a comprehensive web crawling system for financial data
import requests
import re
import json
from datetime import datetime, timedelta
import pandas as pd
from bs4 import BeautifulSoup
import time
import random
from urllib.parse import urljoin, urlparse
import warnings
warnings.filterwarnings('ignore')

class FinancialWebCrawler:
    """Comprehensive financial web crawling system"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        self.crawl_results = {}
        
    def random_delay(self, min_seconds=1, max_seconds=3):
        """Add random delays to avoid being blocked"""
        delay = random.uniform(min_seconds, max_seconds)
        time.sleep(delay)
        return delay
    
    def safe_get(self, url, timeout=10):
        """Safely get webpage content"""
        try:
            response = self.session.get(url, timeout=timeout)
            response.raise_for_status()
            return response
        except Exception as e:
            print(f"❌ Error fetching {url}: {e}")
            return None
    
    def crawl_forex_factory(self):
        """Crawl Forex Factory for economic calendar and news"""
        print("🔄 Crawling Forex Factory...")
        
        try:
            # Forex Factory Calendar
            url = "https://www.forexfactory.com/calendar"
            response = self.safe_get(url)
            
            if response:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Extract calendar events
                events = []
                calendar_rows = soup.find_all('tr', class_='calendar_row')
                
                for row in calendar_rows[:10]:  # Limit to first 10 events
                    try:
                        time_elem = row.find('td', class_='calendar__time')
                        currency_elem = row.find('td', class_='calendar__currency')
                        event_elem = row.find('td', class_='calendar__event')
                        impact_elem = row.find('td', class_='calendar__impact')
                        
                        if event_elem:
                            event_data = {
                                'time': time_elem.text.strip() if time_elem else 'N/A',
                                'currency': currency_elem.text.strip() if currency_elem else 'N/A',
                                'event': event_elem.text.strip() if event_elem else 'N/A',
                                'impact': impact_elem.get('title', 'N/A') if impact_elem else 'N/A'
                            }
                            events.append(event_data)
                    except Exception as e:
                        continue
                
                self.crawl_results['forex_factory'] = {
                    'events': events,
                    'source': 'ForexFactory Calendar',
                    'timestamp': datetime.now().isoformat()
                }
                
                print(f"✅ Extracted {len(events)} forex events")
                return events
                
        except Exception as e:
            print(f"❌ Forex Factory crawling failed: {e}")
            return None
    
    def crawl_tradingview_ideas(self):
        """Crawl TradingView for trading ideas and sentiment"""
        print("🔄 Crawling TradingView ideas...")
        
        try:
            # TradingView public ideas
            url = "https://www.tradingview.com/ideas/"
            response = self.safe_get(url)
            
            if response:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Extract trading ideas
                ideas = []
                idea_cards = soup.find_all('div', class_='tv-widget-idea__container')
                
                for card in idea_cards[:10]:  # Limit to first 10
                    try:
                        title_elem = card.find('a', class_='tv-widget-idea__title')
                        author_elem = card.find('span', class_='tv-widget-idea__author')
                        likes_elem = card.find('span', class_='tv-widget-idea__likes')
                        
                        if title_elem:
                            idea_data = {
                                'title': title_elem.text.strip(),
                                'author': author_elem.text.strip() if author_elem else 'N/A',
                                'likes': likes_elem.text.strip() if likes_elem else '0',
                                'url': urljoin(url, title_elem.get('href', ''))
                            }
                            ideas.append(idea_data)
                    except Exception as e:
                        continue
                
                self.crawl_results['tradingview'] = {
                    'ideas': ideas,
                    'source': 'TradingView Ideas',
                    'timestamp': datetime.now().isoformat()
                }
                
                print(f"✅ Extracted {len(ideas)} trading ideas")
                return ideas
                
        except Exception as e:
            print(f"❌ TradingView crawling failed: {e}")
            return None
    
    def crawl_reddit_trading(self):
        """Crawl Reddit trading communities"""
        print("🔄 Crawling Reddit trading discussions...")
        
        try:
            # Reddit trading subreddits
            subreddits = ['investing', 'stocks', 'SecurityAnalysis', 'ValueInvesting']
            all_posts = []
            
            for subreddit in subreddits:
                url = f"https://www.reddit.com/r/{subreddit}/hot.json"
                response = self.safe_get(url)
                
                if response:
                    try:
                        data = response.json()
                        posts = data.get('data', {}).get('children', [])
                        
                        for post in posts[:5]:  # Limit to 5 posts per subreddit
                            post_data = post.get('data', {})
                            
                            post_info = {
                                'subreddit': subreddit,
                                'title': post_data.get('title', 'N/A'),
                                'score': post_data.get('score', 0),
                                'comments': post_data.get('num_comments', 0),
                                'author': post_data.get('author', 'N/A'),
                                'url': f"https://reddit.com{post_data.get('permalink', '')}"
                            }
                            all_posts.append(post_info)
                            
                    except Exception as e:
                        print(f"⚠️  Error parsing Reddit data for {subreddit}: {e}")
                        continue
                
                self.random_delay(1, 2)  # Be respectful to Reddit's servers
            
            self.crawl_results['reddit'] = {
                'posts': all_posts,
                'source': 'Reddit Trading Communities',
                'timestamp': datetime.now().isoformat()
            }
            
            print(f"✅ Extracted {len(all_posts)} Reddit posts")
            return all_posts
            
        except Exception as e:
            print(f"❌ Reddit crawling failed: {e}")
            return None
    
    def crawl_yahoo_finance_news(self):
        """Crawl Yahoo Finance for latest market news"""
        print("🔄 Crawling Yahoo Finance news...")
        
        try:
            url = "https://finance.yahoo.com/news/"
            response = self.safe_get(url)
            
            if response:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Extract news articles
                articles = []
                news_items = soup.find_all('h3', class_='Mb(5px)')
                
                for item in news_items[:10]:  # Limit to first 10
                    try:
                        link_elem = item.find('a')
                        if link_elem:
                            title = link_elem.text.strip()
                            url_path = link_elem.get('href', '')
                            full_url = urljoin('https://finance.yahoo.com', url_path)
                            
                            article_data = {
                                'title': title,
                                'url': full_url,
                                'source': 'Yahoo Finance'
                            }
                            articles.append(article_data)
                    except Exception as e:
                        continue
                
                self.crawl_results['yahoo_finance'] = {
                    'articles': articles,
                    'source': 'Yahoo Finance News',
                    'timestamp': datetime.now().isoformat()
                }
                
                print(f"✅ Extracted {len(articles)} Yahoo Finance articles")
                return articles
                
        except Exception as e:
            print(f"❌ Yahoo Finance crawling failed: {e}")
            return None
    
    def crawl_seeking_alpha(self):
        """Crawl Seeking Alpha for analysis and opinions"""
        print("🔄 Crawling Seeking Alpha...")
        
        try:
            url = "https://seekingalpha.com/market-news"
            response = self.safe_get(url)
            
            if response:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Extract articles
                articles = []
                article_links = soup.find_all('a', href=re.compile(r'/article/'))
                
                for link in article_links[:10]:  # Limit to first 10
                    try:
                        title = link.text.strip()
                        if title and len(title) > 10:  # Filter out short/empty titles
                            url_path = link.get('href', '')
                            full_url = urljoin('https://seekingalpha.com', url_path)
                            
                            article_data = {
                                'title': title,
                                'url': full_url,
                                'source': 'Seeking Alpha'
                            }
                            articles.append(article_data)
                    except Exception as e:
                        continue
                
                self.crawl_results['seeking_alpha'] = {
                    'articles': articles,
                    'source': 'Seeking Alpha',
                    'timestamp': datetime.now().isoformat()
                }
                
                print(f"✅ Extracted {len(articles)} Seeking Alpha articles")
                return articles
                
        except Exception as e:
            print(f"❌ Seeking Alpha crawling failed: {e}")
            return None
    
    def analyze_sentiment(self, text):
        """Basic sentiment analysis"""
        positive_words = ['bull', 'bullish', 'buy', 'strong', 'gain', 'rise', 'up', 'positive', 'growth', 'profit']
        negative_words = ['bear', 'bearish', 'sell', 'weak', 'loss', 'fall', 'down', 'negative', 'decline', 'crash']
        
        text_lower = text.lower()
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            return 'positive'
        elif negative_count > positive_count:
            return 'negative'
        else:
            return 'neutral'
    
    def run_comprehensive_crawl(self):
        """Run comprehensive crawl of all sources"""
        print("🚀 Starting comprehensive financial web crawl...")
        
        # Crawl all sources
        sources = [
            ('Forex Factory', self.crawl_forex_factory),
            ('TradingView', self.crawl_tradingview_ideas),
            ('Reddit Trading', self.crawl_reddit_trading),
            ('Yahoo Finance', self.crawl_yahoo_finance_news),
            ('Seeking Alpha', self.crawl_seeking_alpha)
        ]
        
        for source_name, crawl_func in sources:
            print(f"\n🔍 Crawling {source_name}...")
            try:
                crawl_func()
                self.random_delay(2, 4)  # Be respectful between sources
            except Exception as e:
                print(f"❌ {source_name} crawl failed: {e}")
                continue
        
        # Analyze overall sentiment
        self.analyze_overall_sentiment()
        
        return self.crawl_results
    
    def analyze_overall_sentiment(self):
        """Analyze overall market sentiment from all sources"""
        print("\n📊 Analyzing overall market sentiment...")
        
        all_texts = []
        sentiment_scores = {'positive': 0, 'negative': 0, 'neutral': 0}
        
        # Collect all text data
        for source, data in self.crawl_results.items():
            if 'articles' in data:
                for article in data['articles']:
                    all_texts.append(article.get('title', ''))
            elif 'posts' in data:
                for post in data['posts']:
                    all_texts.append(post.get('title', ''))
            elif 'ideas' in data:
                for idea in data['ideas']:
                    all_texts.append(idea.get('title', ''))
            elif 'events' in data:
                for event in data['events']:
                    all_texts.append(event.get('event', ''))
        
        # Analyze sentiment
        for text in all_texts:
            sentiment = self.analyze_sentiment(text)
            sentiment_scores[sentiment] += 1
        
        # Calculate overall sentiment
        total_items = sum(sentiment_scores.values())
        if total_items > 0:
            sentiment_percentages = {
                'positive': (sentiment_scores['positive'] / total_items) * 100,
                'negative': (sentiment_scores['negative'] / total_items) * 100,
                'neutral': (sentiment_scores['neutral'] / total_items) * 100
            }
            
            self.crawl_results['overall_sentiment'] = {
                'scores': sentiment_scores,
                'percentages': sentiment_percentages,
                'total_items': total_items,
                'timestamp': datetime.now().isoformat()
            }
            
            print(f"✅ Sentiment Analysis Complete:")
            print(f"   📈 Positive: {sentiment_percentages['positive']:.1f}%")
            print(f"   📉 Negative: {sentiment_percentages['negative']:.1f}%")
            print(f"   ⚖️  Neutral: {sentiment_percentages['neutral']:.1f}%")
    
    def get_trading_signals(self):
        """Generate trading signals based on crawled data"""
        print("\n🎯 Generating trading signals...")
        
        signals = []
        
        # Analyze sentiment for signals
        if 'overall_sentiment' in self.crawl_results:
            sentiment_data = self.crawl_results['overall_sentiment']
            positive_pct = sentiment_data['percentages']['positive']
            negative_pct = sentiment_data['percentages']['negative']
            
            if positive_pct > 60:
                signals.append({
                    'type': 'BUY',
                    'confidence': 'HIGH',
                    'reason': f'Strong positive sentiment ({positive_pct:.1f}%)',
                    'source': 'Sentiment Analysis'
                })
            elif negative_pct > 60:
                signals.append({
                    'type': 'SELL',
                    'confidence': 'HIGH',
                    'reason': f'Strong negative sentiment ({negative_pct:.1f}%)',
                    'source': 'Sentiment Analysis'
                })
            else:
                signals.append({
                    'type': 'HOLD',
                    'confidence': 'MEDIUM',
                    'reason': 'Mixed sentiment signals',
                    'source': 'Sentiment Analysis'
                })
        
        # Analyze Forex Factory events
        if 'forex_factory' in self.crawl_results:
            events = self.crawl_results['forex_factory']['events']
            high_impact_events = [e for e in events if 'high' in e.get('impact', '').lower()]
            
            if len(high_impact_events) > 3:
                signals.append({
                    'type': 'CAUTION',
                    'confidence': 'HIGH',
                    'reason': f'{len(high_impact_events)} high-impact events today',
                    'source': 'Forex Factory'
                })
        
        self.crawl_results['trading_signals'] = signals
        
        for signal in signals:
            print(f"🚨 {signal['type']} Signal - {signal['confidence']} confidence")
            print(f"   Reason: {signal['reason']}")
            print(f"   Source: {signal['source']}")
        
        return signals
    
    def save_results(self, filename='crawl_results.json'):
        """Save crawl results to file"""
        try:
            with open(filename, 'w') as f:
                json.dump(self.crawl_results, f, indent=2, default=str)
            print(f"✅ Results saved to {filename}")
            return True
        except Exception as e:
            print(f"❌ Failed to save results: {e}")
            return False

# Initialize and run the financial web crawler
print("🚀 Initializing Financial Web Crawler...")
crawler = FinancialWebCrawler()

# Run comprehensive crawl
results = crawler.run_comprehensive_crawl()

# Generate trading signals
signals = crawler.get_trading_signals()

# Save results
crawler.save_results()

print(f"\n🎉 Crawling complete! Processed {len(results)} sources")
print(f"📊 Total crawl results: {json.dumps(results, indent=2, default=str)}")