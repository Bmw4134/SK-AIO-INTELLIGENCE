// Infinity Singularity Kernel Trading Suite
class InfinitySingularityKernel {
    constructor() {
        this.currentView = 'dashboard';
        this.db = null;
        this.websocket = null;
        this.charts = {};
        this.agents = new Map();
        this.traces = [];
        this.memoryScore = 8.7;
        this.mutationCount = 156;
        this.isTrading = false;
        this.systemLoop = {
            intent: null,
            goal: null,
            agent: null,
            trace: null,
            feedback: null,
            mutation: null,
            memory: null
        };
        
        // Load initial data from assets
        this.loadInitialData();
        this.initializeDatabase();
        this.init();
    }

    async loadInitialData() {
        try {
            // Load from provided assets
            const [promptDnaResponse, goalTrackerResponse, workflowsResponse] = await Promise.all([
                fetch('https://ppl-ai-code-interpreter-files.s3.amazonaws.com/web/direct-files/5f51e98e96f7c0afd6a240060f25f2de/58277f2a-459f-4ba6-bf0f-e6b6dc915a38/b63f859f.json'),
                fetch('https://ppl-ai-code-interpreter-files.s3.amazonaws.com/web/direct-files/5f51e98e96f7c0afd6a240060f25f2de/58277f2a-459f-4ba6-bf0f-e6b6dc915a38/cc878d95.json'),
                fetch('https://ppl-ai-code-interpreter-files.s3.amazonaws.com/web/direct-files/5f51e98e96f7c0afd6a240060f25f2de/58277f2a-459f-4ba6-bf0f-e6b6dc915a38/ba9a9230.json')
            ]);
            
            if (promptDnaResponse.ok) {
                this.promptDna = await promptDnaResponse.json();
            }
            if (goalTrackerResponse.ok) {
                this.goalTracker = await goalTrackerResponse.json();
            }
            if (workflowsResponse.ok) {
                this.workflows = await workflowsResponse.json();
            }
        } catch (error) {
            console.warn('Failed to load initial data from assets, using defaults:', error);
            this.loadDefaultData();
        }
    }

    loadDefaultData() {
        // Default data if assets can't be loaded
        this.promptDna = {
            version: "1.0.0",
            mutations: [],
            branches: [],
            fitness_scores: [],
            evolution_history: []
        };
        
        this.goalTracker = {
            goals: [],
            achievements: [],
            performance_metrics: {}
        };
        
        this.workflows = {
            nodes: [],
            edges: [],
            configurations: {}
        };
    }

    async initializeDatabase() {
        try {
            this.db = new Dexie('InfinitySingularityDB');
            this.db.version(1).stores({
                traces: '++id, timestamp, type, agent_id, message, metadata',
                agents: '++id, name, type, config, status',
                prompts: '++id, content, mutations, score, timestamp',
                goals: '++id, description, status, metrics, timestamp',
                memory: '++id, score, context, timestamp',
                bundles: '++id, name, version, data, timestamp'
            });
            
            await this.db.open();
            console.log('Database initialized successfully');
        } catch (error) {
            console.error('Failed to initialize database:', error);
        }
    }

    async init() {
        this.showLoading();
        this.initializeAgents();
        this.setupEventListeners();
        this.setupWebSocket();
        this.renderCurrentView();
        this.startSystemLoop();
        this.hideLoading();
    }

    setupEventListeners() {
        // Navigation - Fix the event listeners
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const route = e.target.getAttribute('data-route');
                if (route) {
                    this.navigateTo(route);
                }
            });
        });

        // Trading controls - Fix the button references
        const startBtn = document.getElementById('startTradingBtn');
        const stopBtn = document.getElementById('stopTradingBtn');
        
        if (startBtn) {
            startBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.startTrading();
            });
        }

        if (stopBtn) {
            stopBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.stopTrading();
            });
        }

        // Dashboard controls
        const exportDnaBtn = document.getElementById('exportDnaBtn');
        if (exportDnaBtn) {
            exportDnaBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.exportPromptDna();
            });
        }

        const replayDnaBtn = document.getElementById('replayDnaBtn');
        if (replayDnaBtn) {
            replayDnaBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.replayPromptDna();
            });
        }

        const clearTracesBtn = document.getElementById('clearTracesBtn');
        if (clearTracesBtn) {
            clearTracesBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.clearTraces();
            });
        }

        // Settings controls
        const exportBundleBtn = document.getElementById('exportBundleBtn');
        if (exportBundleBtn) {
            exportBundleBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.exportSingularityBundle();
            });
        }

        const importBundleBtn = document.getElementById('importBundleBtn');
        if (importBundleBtn) {
            importBundleBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.importSingularityBundle();
            });
        }

        const testConnectionBtn = document.getElementById('testConnectionBtn');
        if (testConnectionBtn) {
            testConnectionBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.testAPIConnections();
            });
        }

        // Agent controls
        const createAgentBtn = document.getElementById('createAgentBtn');
        if (createAgentBtn) {
            createAgentBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.showCreateAgentModal();
            });
        }

        const saveAgentBtn = document.getElementById('saveAgentBtn');
        if (saveAgentBtn) {
            saveAgentBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.saveAgent();
            });
        }

        const closeModal = document.getElementById('closeModal');
        if (closeModal) {
            closeModal.addEventListener('click', (e) => {
                e.preventDefault();
                this.hideModal();
            });
        }

        // Settings toggles
        const mutationRate = document.getElementById('mutationRate');
        if (mutationRate) {
            mutationRate.addEventListener('input', (e) => {
                const valueSpan = document.getElementById('mutationRateValue');
                if (valueSpan) {
                    valueSpan.textContent = e.target.value;
                }
            });
        }

        const memoryThreshold = document.getElementById('memoryThreshold');
        if (memoryThreshold) {
            memoryThreshold.addEventListener('input', (e) => {
                const valueSpan = document.getElementById('memoryThresholdValue');
                if (valueSpan) {
                    valueSpan.textContent = e.target.value;
                }
            });
        }

        // Trace filtering
        const traceFilter = document.getElementById('traceFilter');
        if (traceFilter) {
            traceFilter.addEventListener('change', (e) => {
                this.filterTraces(e.target.value);
            });
        }

        // Performance period selection
        document.querySelectorAll('[data-period]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                document.querySelectorAll('[data-period]').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.updatePerformanceChart(e.target.dataset.period);
            });
        });

        // Save API keys on change
        const apiKeys = ['openaiKey', 'anthropicKey', 'perplexityKey', 'coinbaseKey', 'geminiKey'];
        apiKeys.forEach(keyId => {
            const input = document.getElementById(keyId);
            if (input) {
                input.addEventListener('change', (e) => {
                    localStorage.setItem(keyId, e.target.value);
                });
            }
        });
    }

    setupWebSocket() {
        // Mock WebSocket for real-time updates
        this.websocket = {
            readyState: 1,
            send: (data) => console.log('WebSocket send:', data),
            close: () => console.log('WebSocket closed'),
            onopen: null,
            onmessage: null,
            onerror: null,
            onclose: null
        };

        // Simulate WebSocket connection
        setTimeout(() => {
            this.updateConnectionStatus('connected');
            this.startMockWebSocketUpdates();
        }, 1000);
    }

    startMockWebSocketUpdates() {
        // Simulate real-time trace updates
        setInterval(() => {
            if (this.isTrading) {
                this.generateMockTrace();
            }
        }, 2000);

        // Simulate mutation updates
        setInterval(() => {
            this.generateMockMutation();
        }, 5000);

        // Update memory score
        setInterval(() => {
            this.updateMemoryScore();
        }, 3000);
    }

    generateMockTrace() {
        const traceTypes = ['trading', 'mutation', 'feedback'];
        const type = traceTypes[Math.floor(Math.random() * traceTypes.length)];
        const agents = ['TradingAgent', 'MutationEngine', 'FeedbackCollector'];
        const agent = agents[Math.floor(Math.random() * agents.length)];
        
        const messages = {
            trading: ['Executed buy order for BTC', 'Analyzing market trends', 'Position opened at $65,234'],
            mutation: ['Prompt mutated with fitness +0.23', 'New branch created', 'Crossover operation completed'],
            feedback: ['Positive feedback received', 'Performance metrics updated', 'Goal achievement recorded']
        };

        const trace = {
            id: Date.now(),
            timestamp: new Date(),
            type: type,
            agent_id: agent,
            message: messages[type][Math.floor(Math.random() * messages[type].length)],
            metadata: {
                score: Math.random() * 10,
                confidence: Math.random(),
                context: 'system_loop'
            }
        };

        this.addTrace(trace);
    }

    generateMockMutation() {
        this.mutationCount++;
        const mutationCountEl = document.getElementById('mutationCount');
        if (mutationCountEl) {
            mutationCountEl.textContent = this.mutationCount;
        }
        
        const timeSinceLastMutation = Math.random() * 10;
        const lastMutationEl = document.getElementById('lastMutation');
        if (lastMutationEl) {
            lastMutationEl.textContent = `${timeSinceLastMutation.toFixed(1)}s ago`;
        }
        
        this.updateMutationHeatmap();
    }

    updateMemoryScore() {
        const change = (Math.random() - 0.5) * 0.2;
        this.memoryScore = Math.max(0, Math.min(10, this.memoryScore + change));
        const memoryScoreEl = document.getElementById('memoryScore');
        if (memoryScoreEl) {
            memoryScoreEl.textContent = `${this.memoryScore.toFixed(1)}/10`;
        }
    }

    addTrace(trace) {
        this.traces.unshift(trace);
        if (this.traces.length > 100) {
            this.traces.pop();
        }
        
        // Store in IndexedDB
        if (this.db) {
            this.db.traces.add(trace);
        }
        
        // Update UI
        this.renderTraces();
        this.updateActiveTraces();
    }

    updateActiveTraces() {
        const activeCount = this.traces.filter(t => 
            Date.now() - t.timestamp < 30000 // Last 30 seconds
        ).length;
        const activeTracesEl = document.getElementById('activeTraces');
        if (activeTracesEl) {
            activeTracesEl.textContent = activeCount;
        }
    }

    initializeAgents() {
        const defaultAgents = [
            { name: 'TradingAgent', type: 'trading', status: 'active' },
            { name: 'MutationEngine', type: 'mutation', status: 'active' },
            { name: 'FeedbackCollector', type: 'feedback', status: 'active' },
            { name: 'MemoryScorer', type: 'analysis', status: 'active' },
            { name: 'GoalTracker', type: 'analysis', status: 'active' }
        ];

        defaultAgents.forEach(agent => {
            this.agents.set(agent.name, {
                ...agent,
                id: agent.name,
                config: {},
                lastActivity: new Date(),
                performance: Math.random() * 100
            });
        });
    }

    navigateTo(route) {
        console.log('Navigating to:', route);
        
        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        const activeLink = document.querySelector(`[data-route="${route}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }

        // Show/hide views
        document.querySelectorAll('.view').forEach(view => {
            view.classList.add('hidden');
        });
        
        const targetView = document.getElementById(`${route}-view`);
        if (targetView) {
            targetView.classList.remove('hidden');
        }

        this.currentView = route;
        this.renderCurrentView();
    }

    renderCurrentView() {
        switch (this.currentView) {
            case 'dashboard':
                this.renderDashboard();
                break;
            case 'agents':
                this.renderAgents();
                break;
            case 'settings':
                this.renderSettings();
                break;
        }
    }

    renderDashboard() {
        this.renderPromptDnaChart();
        this.renderMutationHeatmap();
        this.renderTraces();
        this.renderPerformanceChart();
        this.renderAgentStatus();
    }

    renderPromptDnaChart() {
        const container = document.getElementById('promptDnaChart');
        if (!container) return;

        // Clear previous chart
        container.innerHTML = '';

        // Create SVG
        const width = container.offsetWidth || 400;
        const height = 250;
        const svg = d3.select(container)
            .append('svg')
            .attr('width', width)
            .attr('height', height);

        // Sample DNA data
        const dnaData = {
            nodes: [
                { id: 'root', x: width/2, y: height/2, level: 0 },
                { id: 'branch1', x: width/2 - 80, y: height/2 - 60, level: 1 },
                { id: 'branch2', x: width/2 + 80, y: height/2 - 60, level: 1 },
                { id: 'mutation1', x: width/2 - 120, y: height/2 - 120, level: 2 },
                { id: 'mutation2', x: width/2, y: height/2 - 120, level: 2 },
                { id: 'mutation3', x: width/2 + 120, y: height/2 - 120, level: 2 }
            ],
            links: [
                { source: 'root', target: 'branch1' },
                { source: 'root', target: 'branch2' },
                { source: 'branch1', target: 'mutation1' },
                { source: 'branch1', target: 'mutation2' },
                { source: 'branch2', target: 'mutation3' }
            ]
        };

        // Draw links
        svg.selectAll('line')
            .data(dnaData.links)
            .enter()
            .append('line')
            .attr('x1', d => dnaData.nodes.find(n => n.id === d.source).x)
            .attr('y1', d => dnaData.nodes.find(n => n.id === d.source).y)
            .attr('x2', d => dnaData.nodes.find(n => n.id === d.target).x)
            .attr('y2', d => dnaData.nodes.find(n => n.id === d.target).y)
            .attr('stroke', '#1FB8CD')
            .attr('stroke-width', 2);

        // Draw nodes
        svg.selectAll('circle')
            .data(dnaData.nodes)
            .enter()
            .append('circle')
            .attr('cx', d => d.x)
            .attr('cy', d => d.y)
            .attr('r', d => 8 + d.level * 2)
            .attr('fill', d => d.level === 0 ? '#1FB8CD' : d.level === 1 ? '#FFC185' : '#B4413C')
            .attr('stroke', '#fff')
            .attr('stroke-width', 2);

        // Add labels
        svg.selectAll('text')
            .data(dnaData.nodes)
            .enter()
            .append('text')
            .attr('x', d => d.x)
            .attr('y', d => d.y + 25)
            .attr('text-anchor', 'middle')
            .attr('font-size', '10px')
            .attr('fill', '#626c71')
            .text(d => d.id);
    }

    renderMutationHeatmap() {
        const canvas = document.getElementById('mutationHeatmap');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const width = canvas.width = canvas.offsetWidth;
        const height = canvas.height = 200;

        // Generate heatmap data
        const data = [];
        for (let i = 0; i < 10; i++) {
            const row = [];
            for (let j = 0; j < 20; j++) {
                row.push(Math.random());
            }
            data.push(row);
        }

        const cellWidth = width / 20;
        const cellHeight = height / 10;

        // Clear canvas
        ctx.clearRect(0, 0, width, height);

        // Draw heatmap
        for (let i = 0; i < data.length; i++) {
            for (let j = 0; j < data[i].length; j++) {
                const intensity = data[i][j];
                const color = intensity > 0.7 ? '#1FB8CD' : 
                             intensity > 0.4 ? '#FFC185' : '#B4413C';
                
                ctx.fillStyle = color;
                ctx.fillRect(j * cellWidth, i * cellHeight, cellWidth, cellHeight);
            }
        }
    }

    renderTraces() {
        const traceList = document.getElementById('traceList');
        if (!traceList) return;

        traceList.innerHTML = '';
        
        this.traces.slice(0, 20).forEach(trace => {
            const traceItem = document.createElement('div');
            traceItem.className = 'trace-item';
            traceItem.innerHTML = `
                <div class="trace-header">
                    <span class="trace-type ${trace.type}">${trace.type}</span>
                    <span class="trace-timestamp">${trace.timestamp.toLocaleTimeString()}</span>
                </div>
                <div class="trace-message">${trace.message}</div>
            `;
            
            traceItem.addEventListener('click', () => {
                this.showTraceDetail(trace);
                document.querySelectorAll('.trace-item').forEach(item => item.classList.remove('selected'));
                traceItem.classList.add('selected');
            });
            
            traceList.appendChild(traceItem);
        });
    }

    showTraceDetail(trace) {
        const traceDetail = document.getElementById('traceDetail');
        if (!traceDetail) return;

        traceDetail.innerHTML = `
            <div class="trace-detail-header">
                <h4>Trace Details</h4>
                <span class="trace-type ${trace.type}">${trace.type}</span>
            </div>
            <div class="trace-detail-content">
                <div class="detail-row">
                    <strong>ID:</strong> ${trace.id}
                </div>
                <div class="detail-row">
                    <strong>Agent:</strong> ${trace.agent_id}
                </div>
                <div class="detail-row">
                    <strong>Timestamp:</strong> ${trace.timestamp.toLocaleString()}
                </div>
                <div class="detail-row">
                    <strong>Message:</strong> ${trace.message}
                </div>
                <div class="detail-row">
                    <strong>Score:</strong> ${trace.metadata?.score?.toFixed(2) || 'N/A'}
                </div>
                <div class="detail-row">
                    <strong>Confidence:</strong> ${trace.metadata?.confidence?.toFixed(2) || 'N/A'}
                </div>
                <div class="detail-row">
                    <strong>Context:</strong> ${trace.metadata?.context || 'N/A'}
                </div>
            </div>
        `;
    }

    renderPerformanceChart() {
        const canvas = document.getElementById('performanceChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        
        if (this.charts.performance) {
            this.charts.performance.destroy();
        }

        // Generate mock performance data
        const data = [];
        for (let i = 0; i < 24; i++) {
            data.push(Math.random() * 1000 + 500);
        }

        this.charts.performance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: Array.from({length: 24}, (_, i) => `${i}:00`),
                datasets: [{
                    label: 'P&L',
                    data: data,
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toFixed(0);
                            }
                        }
                    }
                }
            }
        });
    }

    renderAgentStatus() {
        const agentList = document.getElementById('agentStatusList');
        if (!agentList) return;

        agentList.innerHTML = '';
        
        this.agents.forEach(agent => {
            const agentItem = document.createElement('div');
            agentItem.className = 'agent-item';
            agentItem.innerHTML = `
                <div class="agent-info">
                    <div class="agent-avatar">${agent.name[0]}</div>
                    <div class="agent-details">
                        <div class="agent-name">${agent.name}</div>
                        <div class="agent-type">${agent.type}</div>
                    </div>
                </div>
                <div class="agent-status">
                    <span class="status-indicator ${agent.status}"></span>
                    <span>${agent.status}</span>
                </div>
            `;
            agentList.appendChild(agentItem);
        });
    }

    renderAgents() {
        this.renderAgentGraph();
        this.renderStrategyTable();
    }

    renderAgentGraph() {
        const container = document.getElementById('agentGraph');
        if (!container) return;

        // Clear previous graph
        container.innerHTML = '';

        // Initialize Cytoscape
        const cy = cytoscape({
            container: container,
            elements: [
                // Nodes
                { data: { id: 'trading', label: 'Trading Agent' } },
                { data: { id: 'mutation', label: 'Mutation Engine' } },
                { data: { id: 'feedback', label: 'Feedback Collector' } },
                { data: { id: 'memory', label: 'Memory Scorer' } },
                { data: { id: 'goal', label: 'Goal Tracker' } },
                // Edges
                { data: { source: 'trading', target: 'feedback' } },
                { data: { source: 'feedback', target: 'mutation' } },
                { data: { source: 'mutation', target: 'memory' } },
                { data: { source: 'memory', target: 'goal' } },
                { data: { source: 'goal', target: 'trading' } }
            ],
            style: [
                {
                    selector: 'node',
                    style: {
                        'background-color': '#1FB8CD',
                        'label': 'data(label)',
                        'text-valign': 'center',
                        'text-halign': 'center',
                        'color': '#fff',
                        'font-size': '10px',
                        'width': '60px',
                        'height': '60px'
                    }
                },
                {
                    selector: 'edge',
                    style: {
                        'width': 2,
                        'line-color': '#626c71',
                        'target-arrow-color': '#626c71',
                        'target-arrow-shape': 'triangle'
                    }
                }
            ],
            layout: {
                name: 'circle',
                radius: 100
            }
        });

        this.agentGraph = cy;
    }

    renderStrategyTable() {
        const tableBody = document.getElementById('strategyTableBody');
        if (!tableBody) return;

        tableBody.innerHTML = '';
        
        this.agents.forEach(agent => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${agent.name}</td>
                <td>
                    <select class="form-control">
                        <option>Momentum</option>
                        <option>Mean Reversion</option>
                        <option>Arbitrage</option>
                    </select>
                </td>
                <td>
                    <select class="form-control">
                        <option>Low</option>
                        <option>Medium</option>
                        <option>High</option>
                    </select>
                </td>
                <td>
                    <input type="number" class="form-control" value="25" min="0" max="100">%
                </td>
                <td>
                    <span class="status ${agent.status}">${agent.status}</span>
                </td>
                <td>
                    <div class="strategy-actions">
                        <button class="btn btn--sm btn--secondary">Edit</button>
                        <button class="btn btn--sm btn--error">Stop</button>
                    </div>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    renderSettings() {
        this.loadAPIKeys();
        this.renderPlugins();
    }

    loadAPIKeys() {
        // Load API keys from localStorage
        const keys = ['openaiKey', 'anthropicKey', 'perplexityKey', 'coinbaseKey', 'geminiKey'];
        keys.forEach(key => {
            const input = document.getElementById(key);
            if (input) {
                input.value = localStorage.getItem(key) || '';
            }
        });
    }

    renderPlugins() {
        const pluginList = document.getElementById('pluginList');
        if (!pluginList) return;

        const plugins = [
            { name: 'Trading Plugin', version: '1.0.0', status: 'active' },
            { name: 'Mutation Engine', version: '1.2.3', status: 'active' },
            { name: 'Memory Scorer', version: '0.9.1', status: 'inactive' }
        ];

        pluginList.innerHTML = '';
        plugins.forEach(plugin => {
            const pluginItem = document.createElement('div');
            pluginItem.className = 'plugin-item';
            pluginItem.innerHTML = `
                <div class="plugin-info">
                    <div class="plugin-name">${plugin.name}</div>
                    <div class="plugin-version">v${plugin.version}</div>
                </div>
                <div class="plugin-status">
                    <span class="status-indicator ${plugin.status}"></span>
                    <span>${plugin.status}</span>
                </div>
            `;
            pluginList.appendChild(pluginItem);
        });
    }

    startTrading() {
        this.isTrading = true;
        const startBtn = document.getElementById('startTradingBtn');
        const stopBtn = document.getElementById('stopTradingBtn');
        
        if (startBtn) startBtn.classList.add('hidden');
        if (stopBtn) stopBtn.classList.remove('hidden');
        
        const kernelStatus = document.getElementById('kernelStatus');
        if (kernelStatus) {
            kernelStatus.innerHTML = `
                <span class="status-indicator active"></span>
                <span>Trading</span>
            `;
        }
        
        this.showNotification('Trading started successfully', 'success');
        this.logIntent('START_TRADING');
    }

    stopTrading() {
        this.isTrading = false;
        const startBtn = document.getElementById('startTradingBtn');
        const stopBtn = document.getElementById('stopTradingBtn');
        
        if (startBtn) startBtn.classList.remove('hidden');
        if (stopBtn) stopBtn.classList.add('hidden');
        
        const kernelStatus = document.getElementById('kernelStatus');
        if (kernelStatus) {
            kernelStatus.innerHTML = `
                <span class="status-indicator active"></span>
                <span>Active</span>
            `;
        }
        
        this.showNotification('Trading stopped', 'info');
        this.logIntent('STOP_TRADING');
    }

    logIntent(intent) {
        console.log(`Intent logged: ${intent}`);
        this.systemLoop.intent = intent;
        this.processSystemLoop();
    }

    processSystemLoop() {
        // INTENT → GOAL → AGENT → TRACE → FEEDBACK → SELF-MUTATE → MEMORY SCORE
        const intent = this.systemLoop.intent;
        
        // Generate goal based on intent
        const goal = this.generateGoal(intent);
        this.systemLoop.goal = goal;
        
        // Select agent for goal
        const agent = this.selectAgent(goal);
        this.systemLoop.agent = agent;
        
        // Create trace
        const trace = {
            id: Date.now(),
            timestamp: new Date(),
            type: 'system',
            agent_id: agent,
            message: `Processing ${intent} → ${goal}`,
            metadata: { intent, goal, agent }
        };
        this.systemLoop.trace = trace;
        this.addTrace(trace);
        
        // Generate feedback
        const feedback = this.generateFeedback(trace);
        this.systemLoop.feedback = feedback;
        
        // Self-mutate
        const mutation = this.performMutation(feedback);
        this.systemLoop.mutation = mutation;
        
        // Update memory score
        this.updateMemoryScore();
        this.systemLoop.memory = this.memoryScore;
        
        console.log('System loop processed:', this.systemLoop);
    }

    generateGoal(intent) {
        const goalMapping = {
            'START_TRADING': 'MAXIMIZE_PROFIT',
            'STOP_TRADING': 'PRESERVE_CAPITAL',
            'ANALYZE_MARKET': 'IDENTIFY_OPPORTUNITIES',
            'UPDATE_STRATEGY': 'OPTIMIZE_PERFORMANCE'
        };
        return goalMapping[intent] || 'MAINTAIN_SYSTEM';
    }

    selectAgent(goal) {
        const agentMapping = {
            'MAXIMIZE_PROFIT': 'TradingAgent',
            'PRESERVE_CAPITAL': 'TradingAgent',
            'IDENTIFY_OPPORTUNITIES': 'MutationEngine',
            'OPTIMIZE_PERFORMANCE': 'MemoryScorer'
        };
        return agentMapping[goal] || 'TradingAgent';
    }

    generateFeedback(trace) {
        return {
            score: Math.random() * 10,
            confidence: Math.random(),
            recommendation: 'Continue current strategy'
        };
    }

    performMutation(feedback) {
        if (feedback.score > 7) {
            return 'POSITIVE_MUTATION';
        } else if (feedback.score < 3) {
            return 'CORRECTIVE_MUTATION';
        } else {
            return 'NEUTRAL_MUTATION';
        }
    }

    async exportSingularityBundle() {
        try {
            const zip = new JSZip();
            
            // Add configuration files
            zip.file('prompt_dna.json', JSON.stringify(this.promptDna, null, 2));
            zip.file('goal_tracker.json', JSON.stringify(this.goalTracker, null, 2));
            zip.file('orchestration_workflows.json', JSON.stringify(this.workflows, null, 2));
            
            // Add agent configurations
            const agentConfigs = {};
            this.agents.forEach((agent, name) => {
                agentConfigs[name] = agent;
            });
            zip.file('agent_configs.json', JSON.stringify(agentConfigs, null, 2));
            
            // Add traces
            zip.file('traces.json', JSON.stringify(this.traces, null, 2));
            
            // Add bundle metadata
            const metadata = {
                version: '1.0.0',
                timestamp: new Date().toISOString(),
                mutation_count: this.mutationCount,
                memory_score: this.memoryScore
            };
            zip.file('singularity-bundle.json', JSON.stringify(metadata, null, 2));
            
            // Generate and download
            const content = await zip.generateAsync({type: 'blob'});
            const url = URL.createObjectURL(content);
            const a = document.createElement('a');
            a.href = url;
            a.download = `singularity-bundle-${Date.now()}.zip`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showNotification('Bundle exported successfully', 'success');
        } catch (error) {
            console.error('Export error:', error);
            this.showNotification('Export failed: ' + error.message, 'error');
        }
    }

    importSingularityBundle() {
        const input = document.getElementById('importBundleInput');
        if (!input) return;
        
        const file = input.files[0];
        
        if (!file) {
            this.showNotification('Please select a bundle file', 'warning');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = async (e) => {
            try {
                const zip = new JSZip();
                const contents = await zip.loadAsync(e.target.result);
                
                // Extract files
                const files = {};
                for (const [filename, file] of Object.entries(contents.files)) {
                    if (!file.dir) {
                        files[filename] = await file.async('string');
                    }
                }
                
                // Parse and load data
                if (files['prompt_dna.json']) {
                    this.promptDna = JSON.parse(files['prompt_dna.json']);
                }
                if (files['goal_tracker.json']) {
                    this.goalTracker = JSON.parse(files['goal_tracker.json']);
                }
                if (files['orchestration_workflows.json']) {
                    this.workflows = JSON.parse(files['orchestration_workflows.json']);
                }
                
                this.showNotification('Bundle imported successfully', 'success');
                this.renderCurrentView();
            } catch (error) {
                console.error('Import error:', error);
                this.showNotification('Import failed: ' + error.message, 'error');
            }
        };
        reader.readAsArrayBuffer(file);
    }

    testAPIConnections() {
        this.showNotification('Testing API connections...', 'info');
        
        // Mock API testing
        setTimeout(() => {
            this.showNotification('API connections tested successfully', 'success');
        }, 2000);
    }

    showCreateAgentModal() {
        const modal = document.getElementById('modalOverlay');
        if (modal) {
            modal.classList.add('show');
        }
    }

    hideModal() {
        const modal = document.getElementById('modalOverlay');
        if (modal) {
            modal.classList.remove('show');
        }
    }

    saveAgent() {
        const name = document.getElementById('agentName')?.value;
        const type = document.getElementById('agentType')?.value;
        const config = document.getElementById('agentConfig')?.value;
        
        if (!name || !type) {
            this.showNotification('Please fill in all required fields', 'warning');
            return;
        }
        
        let parsedConfig = {};
        if (config) {
            try {
                parsedConfig = JSON.parse(config);
            } catch (error) {
                this.showNotification('Invalid JSON configuration', 'error');
                return;
            }
        }
        
        this.agents.set(name, {
            id: name,
            name: name,
            type: type,
            config: parsedConfig,
            status: 'active',
            performance: Math.random() * 100
        });
        
        this.hideModal();
        this.showNotification('Agent created successfully', 'success');
        this.renderCurrentView();
    }

    clearTraces() {
        this.traces = [];
        this.renderTraces();
        this.showNotification('Traces cleared', 'info');
    }

    filterTraces(type) {
        console.log('Filtering traces by type:', type);
        this.renderTraces();
    }

    updatePerformanceChart(period) {
        console.log('Updating performance chart for period:', period);
        this.renderPerformanceChart();
    }

    updateMutationHeatmap() {
        this.renderMutationHeatmap();
    }

    exportPromptDna() {
        const data = JSON.stringify(this.promptDna, null, 2);
        const blob = new Blob([data], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'prompt_dna.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        this.showNotification('PromptDNA exported', 'success');
    }

    replayPromptDna() {
        this.showNotification('Replaying PromptDNA evolution...', 'info');
        // Animation logic would go here
    }

    startSystemLoop() {
        // Start the main system loop
        setInterval(() => {
            this.logIntent('SYSTEM_HEARTBEAT');
        }, 10000);
    }

    updateConnectionStatus(status) {
        const indicator = document.getElementById('connectionIndicator');
        const text = document.getElementById('connectionText');
        
        if (indicator) {
            indicator.className = `connection-indicator ${status}`;
        }
        if (text) {
            text.textContent = status === 'connected' ? 'Connected' : 
                              status === 'connecting' ? 'Connecting...' : 'Disconnected';
        }
    }

    showLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.add('show');
        }
    }

    hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.remove('show');
        }
    }

    showNotification(message, type = 'info') {
        const container = document.getElementById('notifications');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-title">${this.getNotificationTitle(type)}</div>
            <div class="notification-message">${message}</div>
        `;
        
        container.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (container.contains(notification)) {
                    container.removeChild(notification);
                }
            }, 300);
        }, 4000);
    }

    getNotificationTitle(type) {
        const titles = {
            'success': 'Success',
            'error': 'Error',
            'warning': 'Warning',
            'info': 'Info'
        };
        return titles[type] || 'Notification';
    }

    destroy() {
        if (this.websocket) {
            this.websocket.close();
        }
        Object.values(this.charts).forEach(chart => {
            if (chart && typeof chart.destroy === 'function') {
                chart.destroy();
            }
        });
        if (this.db) {
            this.db.close();
        }
    }
}

// Initialize the application
let kernelApp;
document.addEventListener('DOMContentLoaded', () => {
    kernelApp = new InfinitySingularityKernel();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (kernelApp) {
        kernelApp.destroy();
    }
});

// Export for global access
window.InfinitySingularityKernel = InfinitySingularityKernel;