
import json
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import numpy as np

class MemoryScorer:
    def __init__(self):
        self.memory_types = {
            "short_term": {"duration": 3600, "weight": 0.3},  # 1 hour
            "long_term": {"duration": 86400 * 30, "weight": 0.4},  # 30 days
            "procedural": {"duration": 86400 * 7, "weight": 0.2},  # 7 days
            "episodic": {"duration": 86400 * 1, "weight": 0.1}  # 1 day
        }
        self.memory_database = []
        self.scores = {}

    async def score_memory(self, memory_item: Dict) -> Dict:
        memory_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()

        # Classify memory type
        memory_type = self.classify_memory_type(memory_item)

        # Calculate relevance score
        relevance_score = await self.calculate_relevance(memory_item)

        # Calculate retention score
        retention_score = await self.calculate_retention(memory_item)

        # Calculate utility score
        utility_score = await self.calculate_utility(memory_item)

        # Weighted final score
        final_score = (relevance_score * 0.4) + (retention_score * 0.3) + (utility_score * 0.3)

        memory_record = {
            "id": memory_id,
            "timestamp": timestamp,
            "memory_type": memory_type,
            "content": memory_item,
            "relevance_score": relevance_score,
            "retention_score": retention_score,
            "utility_score": utility_score,
            "final_score": final_score
        }

        self.memory_database.append(memory_record)
        self.scores[memory_id] = final_score

        return memory_record

    def classify_memory_type(self, memory_item: Dict) -> str:
        # Classify memory based on content and context
        if "procedure" in str(memory_item).lower():
            return "procedural"
        elif "recent" in str(memory_item).lower() or "now" in str(memory_item).lower():
            return "short_term"
        elif "episode" in str(memory_item).lower() or "event" in str(memory_item).lower():
            return "episodic"
        else:
            return "long_term"

    async def calculate_relevance(self, memory_item: Dict) -> float:
        # Calculate relevance based on current context
        current_context = memory_item.get("context", {})

        # Simple relevance calculation
        relevance_factors = [
            memory_item.get("frequency", 0.0),
            memory_item.get("importance", 0.0),
            memory_item.get("recency", 0.0)
        ]

        return np.mean(relevance_factors) if relevance_factors else 0.0

    async def calculate_retention(self, memory_item: Dict) -> float:
        # Calculate how well this memory should be retained
        age = memory_item.get("age", 0)
        access_frequency = memory_item.get("access_frequency", 0)

        # Retention decreases with age but increases with frequency
        retention = max(0, 1 - (age / 86400)) + (access_frequency / 10)
        return min(1.0, retention)

    async def calculate_utility(self, memory_item: Dict) -> float:
        # Calculate utility based on past performance
        performance_history = memory_item.get("performance_history", [])

        if not performance_history:
            return 0.5  # Default utility

        return np.mean(performance_history)

    async def get_memory_insights(self) -> Dict:
        if not self.memory_database:
            return {"insights": "No memory data available"}

        return {
            "total_memories": len(self.memory_database),
            "average_score": np.mean(list(self.scores.values())),
            "memory_distribution": self.get_memory_distribution(),
            "top_memories": self.get_top_memories(),
            "optimization_suggestions": self.generate_memory_optimization_suggestions()
        }

    def get_memory_distribution(self) -> Dict:
        distribution = {}
        for memory in self.memory_database:
            mem_type = memory["memory_type"]
            if mem_type not in distribution:
                distribution[mem_type] = 0
            distribution[mem_type] += 1
        return distribution

    def get_top_memories(self, limit: int = 5) -> List[Dict]:
        sorted_memories = sorted(self.memory_database, 
                               key=lambda x: x["final_score"], 
                               reverse=True)
        return sorted_memories[:limit]
