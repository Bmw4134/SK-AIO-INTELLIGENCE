
import random
import json
from typing import Dict, List, Tuple
from datetime import datetime

class MutationEngine:
    def __init__(self):
        self.mutation_strategies = [
            "parameter_adjustment",
            "strategy_crossover", 
            "prompt_variation",
            "context_expansion",
            "timing_modification"
        ]
        self.mutation_history = []

    async def mutate_prompt(self, prompt_id: str, fitness_score: float, 
                           performance_data: Dict) -> Dict:
        mutation_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()

        # Select mutation strategy based on fitness score
        if fitness_score < 0.5:
            strategy = "parameter_adjustment"
        elif fitness_score < 0.7:
            strategy = "strategy_crossover"
        else:
            strategy = "prompt_variation"

        # Apply mutation
        mutation_result = await self.apply_mutation(prompt_id, strategy, performance_data)

        # Record mutation
        mutation_record = {
            "id": mutation_id,
            "timestamp": timestamp,
            "prompt_id": prompt_id,
            "strategy": strategy,
            "fitness_before": fitness_score,
            "mutation_result": mutation_result,
            "performance_data": performance_data
        }

        self.mutation_history.append(mutation_record)
        return mutation_record

    async def apply_mutation(self, prompt_id: str, strategy: str, 
                           performance_data: Dict) -> Dict:
        if strategy == "parameter_adjustment":
            return await self.adjust_parameters(prompt_id, performance_data)
        elif strategy == "strategy_crossover":
            return await self.crossover_strategies(prompt_id, performance_data)
        elif strategy == "prompt_variation":
            return await self.vary_prompt(prompt_id, performance_data)
        else:
            return {"success": False, "error": "Unknown mutation strategy"}

    async def calculate_fitness(self, prompt_id: str, results: List[Dict]) -> float:
        # Calculate fitness score based on trading results
        if not results:
            return 0.0

        total_score = 0.0
        for result in results:
            if result.get("success", False):
                profit = result.get("profit", 0.0)
                risk_score = result.get("risk_score", 0.5)
                latency = result.get("latency", 1.0)

                # Weighted fitness calculation
                score = (profit * 0.4) + ((1 - risk_score) * 0.3) + ((1 / latency) * 0.3)
                total_score += max(0, min(1, score))

        return total_score / len(results)
