# First, let's examine the singularity-bundle.json to understand the current state
import json
import os

# Check if we have access to the bundle files
bundle_files = []
for file in os.listdir('.'):
    if file.endswith('.json'):
        bundle_files.append(file)
        
print("Available JSON files:", bundle_files)

# Let's also check what files we have available
all_files = os.listdir('.')
print("\nAll files in current directory:", all_files)