# Load and analyze the singularity-bundle.json
with open('singularity-bundle.json', 'r') as f:
    bundle_data = json.load(f)

print("Bundle structure:")
print(json.dumps(bundle_data, indent=2))