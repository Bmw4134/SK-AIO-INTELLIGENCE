# Create .singularity-bundle.zip export
bundle_files_to_zip = [
    'singularity-bundle.json',
    'goal_tracker.json',
    'prompt_dna.json',
    '.env.template',
    'agents/configs/trading_strategies.json',
    'langgraph/dags/orchestration_workflows.json',
    'plugins/chatgpt/ai-plugin.json',
    'plugins/openapi/openapi.yaml'
]

zip_buffer = io.BytesIO()
with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for file_path in bundle_files_to_zip:
        zipf.write(file_path)

# Save zip file
zip_filename = 'singularity-bundle.zip'
with open(zip_filename, 'wb') as f:
    f.write(zip_buffer.getvalue())

print(f"✅ Exported {zip_filename} with {len(bundle_files_to_zip)} files")