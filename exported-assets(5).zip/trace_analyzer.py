
import json
from typing import Dict, List, Optional
from datetime import datetime
import numpy as np

class TraceAnalyzer:
    def __init__(self):
        self.trace_database = []
        self.correlation_matrix = {}
        self.pattern_cache = {}

    async def capture_trace(self, agent_execution: Dict) -> Dict:
        trace_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()

        trace_record = {
            "id": trace_id,
            "timestamp": timestamp,
            "agent_id": agent_execution.get("agent_id"),
            "execution_path": agent_execution.get("execution_path", []),
            "parameters": agent_execution.get("parameters", {}),
            "result": agent_execution.get("result", {}),
            "latency": agent_execution.get("latency", 0.0),
            "memory_usage": agent_execution.get("memory_usage", 0),
            "success": agent_execution.get("success", False)
        }

        self.trace_database.append(trace_record)

        # Analyze patterns
        await self.analyze_patterns(trace_record)

        return trace_record

    async def analyze_patterns(self, trace: Dict):
        # Pattern analysis for optimization
        patterns = {
            "execution_frequency": self.calculate_execution_frequency(trace),
            "success_correlation": self.calculate_success_correlation(trace),
            "performance_trend": self.calculate_performance_trend(trace),
            "resource_usage": self.calculate_resource_usage(trace)
        }

        self.pattern_cache[trace["id"]] = patterns
        return patterns

    def calculate_execution_frequency(self, trace: Dict) -> float:
        # Calculate how often this execution path is used
        similar_traces = [t for t in self.trace_database 
                         if t.get("execution_path") == trace.get("execution_path")]
        return len(similar_traces) / len(self.trace_database) if self.trace_database else 0.0

    def calculate_success_correlation(self, trace: Dict) -> float:
        # Calculate correlation between parameters and success
        if not trace.get("success", False):
            return 0.0

        similar_successful = [t for t in self.trace_database 
                            if t.get("success", False) and 
                            t.get("parameters", {}).keys() == trace.get("parameters", {}).keys()]

        return len(similar_successful) / len(self.trace_database) if self.trace_database else 0.0

    async def generate_insights(self) -> Dict:
        if not self.trace_database:
            return {"insights": "No traces available"}

        # Generate insights from trace analysis
        insights = {
            "total_traces": len(self.trace_database),
            "success_rate": sum(1 for t in self.trace_database if t.get("success", False)) / len(self.trace_database),
            "average_latency": np.mean([t.get("latency", 0.0) for t in self.trace_database]),
            "most_common_patterns": self.get_most_common_patterns(),
            "optimization_suggestions": self.generate_optimization_suggestions()
        }

        return insights
