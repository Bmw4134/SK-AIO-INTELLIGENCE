// Infinity Singularity - Multi-Agent Orchestration Platform
class InfinitySingularity {
  constructor() {
    this.currentSection = 'dashboard';
    this.charts = {};
    this.chartColors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454', '#13343B'];
    
    // Application data from JSON
    this.data = {
      agents: [
        {
          id: "schema-adapter-001",
          name: "Schema Coherence Adapter",
          type: "Translation",
          status: "active",
          provider: "Gemini Pro",
          successRate: 94.2,
          avgLatency: 150,
          costPerHour: 0.45,
          lastActivity: "2025-07-16T20:15:00Z"
        },
        {
          id: "prompt-evolution-001",
          name: "Prompt Evolution Engine",
          type: "Optimization",
          status: "active",
          provider: "Claude 3.5",
          successRate: 87.8,
          avgLatency: 280,
          costPerHour: 0.78,
          lastActivity: "2025-07-16T20:12:00Z"
        },
        {
          id: "trading-bot-001",
          name: "Crypto Trading Agent",
          type: "Trading",
          status: "paused",
          provider: "Mixtral 8x7B",
          successRate: 76.5,
          avgLatency: 95,
          costPerHour: 0.23,
          lastActivity: "2025-07-16T19:45:00Z"
        },
        {
          id: "llm-router-001",
          name: "LLM Router",
          type: "Orchestration",
          status: "active",
          provider: "Multi-Provider",
          successRate: 99.1,
          avgLatency: 45,
          costPerHour: 0.12,
          lastActivity: "2025-07-16T20:16:00Z"
        }
      ],
      systemMetrics: {
        totalRequests: 15847,
        successfulRequests: 14923,
        failedRequests: 924,
        avgResponseTime: 167,
        costToday: 15.67,
        costThisMonth: 342.89,
        activeAgents: 3,
        totalAgents: 4
      },
      apiCredentials: {
        openai: {
          key: "sk-proj-QTK_m7trpFRgSTpDEFu7S7ICpIoceP8T_BKyPVLagRAHCPyM6nPjQemrdexfEDDJsvrNeOZPAH",
          status: "active",
          usage: "78%"
        },
        anthropic: {
          key: "sk-ant-api03-b5Mj9aSBLOTqzJ3hkEmSUs-JSM3U7gyalPdDqe3bjOP_CmY13mJD8m6cRze1nlOPbYoTsn20zBJ",
          status: "active",
          usage: "45%"
        },
        google: {
          key: "AIzaSyAmN_hRlFdtn6czMSNrvlgHW4aJph2aQKY",
          status: "active",
          usage: "62%"
        },
        perplexity: {
          key: "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",
          status: "active",
          usage: "32%"
        }
      },
      tradingApis: {
        coinbase: {
          key: "organizations/0d0b2954-b380-4fca-99e3-bdcd636690c0/apiKeys/97f8484f-aade-40e0-a3d6-34cfe3770edc",
          status: "connected",
          balance: 15420.67
        },
        stripe: {
          key: "sk_test_51RY7e3PHi6sCnH97wspOjrhLYRMfQZkSJNivDp3GF6YajFta8XQr0Cyj8rhKAi43UDDwYi9y6JEBjEt",
          status: "connected"
        }
      },
      schemaTranslations: [
        {
          id: "translation-001",
          source: "OpenAI",
          target: "Anthropic",
          status: "successful",
          timestamp: "2025-07-16T20:10:00Z",
          latency: 145,
          accuracy: 96.8
        },
        {
          id: "translation-002",
          source: "Google Gemini",
          target: "HuggingFace",
          status: "successful",
          timestamp: "2025-07-16T20:08:00Z",
          latency: 203,
          accuracy: 91.2
        }
      ],
      deploymentOptions: [
        {
          platform: "Docker",
          status: "configured",
          description: "Containerized deployment with Docker Compose",
          complexity: "beginner"
        },
        {
          platform: "Kubernetes",
          status: "available",
          description: "Production-grade orchestration with K8s",
          complexity: "advanced"
        },
        {
          platform: "AWS",
          status: "available",
          description: "Cloud deployment with AWS Lambda and ECS",
          complexity: "intermediate"
        }
      ],
      promptEvolution: {
        currentGeneration: 7,
        bestFitness: 0.847,
        mutations: 156,
        improvements: 23,
        avgImprovement: 0.034
      },
      performanceMetrics: {
        cpuUsage: 45.2,
        memoryUsage: 67.8,
        networkLatency: 23,
        errorRate: 0.08,
        throughput: 1247
      }
    };
    
    this.init();
  }

  init() {
    this.initializeNavigation();
    this.renderDashboard();
    this.initializeEventListeners();
    this.startRealTimeUpdates();
    this.showNotification('Infinity Singularity initialized successfully', 'success');
  }

  initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const section = link.dataset.section;
        this.showSection(section);
        
        // Update active nav link
        navLinks.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
      });
    });
  }

  showSection(sectionId) {
    // Hide all sections
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
      section.classList.remove('active');
    });
    
    // Show target section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
      targetSection.classList.add('active');
      this.currentSection = sectionId;
      this.renderSection(sectionId);
    }
  }

  renderSection(sectionId) {
    switch(sectionId) {
      case 'dashboard':
        this.renderDashboard();
        break;
      case 'schema-studio':
        this.renderSchemaStudio();
        break;
      case 'prompt-lab':
        this.renderPromptLab();
        break;
      case 'llm-router':
        this.renderLLMRouter();
        break;
      case 'trading-hub':
        this.renderTradingHub();
        break;
      case 'deployment-manager':
        this.renderDeploymentManager();
        break;
      case 'monitoring':
        this.renderMonitoring();
        break;
    }
  }

  renderDashboard() {
    // Render system metrics
    const metricsContainer = document.getElementById('metrics-container');
    if (metricsContainer) {
      const metrics = this.data.systemMetrics;
      metricsContainer.innerHTML = `
        <div class="metric-card">
          <div class="metric-card__header">
            <h3 class="metric-card__title">Total Requests</h3>
          </div>
          <div class="metric-card__value">${metrics.totalRequests.toLocaleString()}</div>
          <div class="metric-card__change positive">+${((metrics.successfulRequests / metrics.totalRequests) * 100).toFixed(1)}% success rate</div>
        </div>
        <div class="metric-card">
          <div class="metric-card__header">
            <h3 class="metric-card__title">Average Response Time</h3>
          </div>
          <div class="metric-card__value">${metrics.avgResponseTime}ms</div>
          <div class="metric-card__change">Network latency optimized</div>
        </div>
        <div class="metric-card">
          <div class="metric-card__header">
            <h3 class="metric-card__title">Cost Today</h3>
          </div>
          <div class="metric-card__value">$${metrics.costToday}</div>
          <div class="metric-card__change">Monthly: $${metrics.costThisMonth}</div>
        </div>
        <div class="metric-card">
          <div class="metric-card__header">
            <h3 class="metric-card__title">Active Agents</h3>
          </div>
          <div class="metric-card__value">${metrics.activeAgents}/${metrics.totalAgents}</div>
          <div class="metric-card__change positive">All systems operational</div>
        </div>
      `;
    }

    // Render agents table
    this.renderAgentsTable();
  }

  renderAgentsTable() {
    const tableWrapper = document.getElementById('agents-table-wrapper');
    if (tableWrapper) {
      const agentsHtml = this.data.agents.map(agent => `
        <tr>
          <td>
            <div class="flex items-center gap-8">
              <div class="status-indicator status-indicator--${agent.status === 'active' ? 'success' : 'warning'}">
                <div class="status-dot"></div>
                ${agent.status}
              </div>
              <strong>${agent.name}</strong>
            </div>
          </td>
          <td>${agent.type}</td>
          <td>${agent.provider}</td>
          <td>${agent.successRate}%</td>
          <td>${agent.avgLatency}ms</td>
          <td>$${agent.costPerHour}/hr</td>
          <td class="text-sm text-mono">${new Date(agent.lastActivity).toLocaleTimeString()}</td>
        </tr>
      `).join('');

      tableWrapper.innerHTML = `
        <table class="data-table">
          <thead>
            <tr>
              <th>Agent</th>
              <th>Type</th>
              <th>Provider</th>
              <th>Success Rate</th>
              <th>Avg Latency</th>
              <th>Cost/Hour</th>
              <th>Last Activity</th>
            </tr>
          </thead>
          <tbody>
            ${agentsHtml}
          </tbody>
        </table>
      `;
    }
  }

  renderSchemaStudio() {
    const tableWrapper = document.getElementById('translations-table-wrapper');
    if (tableWrapper) {
      const translationsHtml = this.data.schemaTranslations.map(translation => `
        <tr>
          <td><strong>${translation.source}</strong></td>
          <td>${translation.target}</td>
          <td>
            <div class="status-indicator status-indicator--success">
              <div class="status-dot"></div>
              ${translation.status}
            </div>
          </td>
          <td>${translation.latency}ms</td>
          <td>${translation.accuracy}%</td>
          <td class="text-sm text-mono">${new Date(translation.timestamp).toLocaleTimeString()}</td>
        </tr>
      `).join('');

      tableWrapper.innerHTML = `
        <table class="data-table">
          <thead>
            <tr>
              <th>Source Provider</th>
              <th>Target Provider</th>
              <th>Status</th>
              <th>Latency</th>
              <th>Accuracy</th>
              <th>Timestamp</th>
            </tr>
          </thead>
          <tbody>
            ${translationsHtml}
          </tbody>
        </table>
      `;
    }
  }

  renderPromptLab() {
    const statsContainer = document.getElementById('prompt-stats');
    if (statsContainer) {
      const evolution = this.data.promptEvolution;
      statsContainer.innerHTML = `
        <div class="metric-card">
          <div class="metric-card__header">
            <h3 class="metric-card__title">Current Generation</h3>
          </div>
          <div class="metric-card__value">${evolution.currentGeneration}</div>
          <div class="metric-card__change">${evolution.mutations} mutations applied</div>
        </div>
        <div class="metric-card">
          <div class="metric-card__header">
            <h3 class="metric-card__title">Best Fitness Score</h3>
          </div>
          <div class="metric-card__value">${evolution.bestFitness}</div>
          <div class="metric-card__change positive">+${evolution.improvements} improvements</div>
        </div>
      `;
    }
  }

  renderLLMRouter() {
    const tableWrapper = document.getElementById('credentials-table-wrapper');
    if (tableWrapper) {
      const credentialsHtml = Object.entries(this.data.apiCredentials).map(([provider, data]) => `
        <tr>
          <td><strong>${provider.toUpperCase()}</strong></td>
          <td class="text-mono">${data.key.substring(0, 20)}...</td>
          <td>
            <div class="status-indicator status-indicator--success">
              <div class="status-dot"></div>
              ${data.status}
            </div>
          </td>
          <td>
            <div class="progress-bar">
              <div class="progress-bar__fill" style="width: ${data.usage}"></div>
            </div>
            ${data.usage}
          </td>
        </tr>
      `).join('');

      tableWrapper.innerHTML = `
        <table class="data-table">
          <thead>
            <tr>
              <th>Provider</th>
              <th>API Key</th>
              <th>Status</th>
              <th>Usage</th>
            </tr>
          </thead>
          <tbody>
            ${credentialsHtml}
          </tbody>
        </table>
      `;
    }
  }

  renderTradingHub() {
    const tableWrapper = document.getElementById('trading-table-wrapper');
    if (tableWrapper) {
      const tradingHtml = Object.entries(this.data.tradingApis).map(([platform, data]) => `
        <tr>
          <td><strong>${platform.toUpperCase()}</strong></td>
          <td class="text-mono">${data.key.substring(0, 30)}...</td>
          <td>
            <div class="status-indicator status-indicator--success">
              <div class="status-dot"></div>
              ${data.status}
            </div>
          </td>
          <td>${data.balance ? `$${data.balance.toLocaleString()}` : 'N/A'}</td>
        </tr>
      `).join('');

      tableWrapper.innerHTML = `
        <table class="data-table">
          <thead>
            <tr>
              <th>Platform</th>
              <th>API Key</th>
              <th>Status</th>
              <th>Balance</th>
            </tr>
          </thead>
          <tbody>
            ${tradingHtml}
          </tbody>
        </table>
      `;
    }
  }

  renderDeploymentManager() {
    const tableWrapper = document.getElementById('deployment-table-wrapper');
    if (tableWrapper) {
      const deploymentHtml = this.data.deploymentOptions.map(option => `
        <tr>
          <td><strong>${option.platform}</strong></td>
          <td>${option.description}</td>
          <td>
            <div class="status-indicator status-indicator--${option.status === 'configured' ? 'success' : 'warning'}">
              <div class="status-dot"></div>
              ${option.status}
            </div>
          </td>
          <td>${option.complexity}</td>
        </tr>
      `).join('');

      tableWrapper.innerHTML = `
        <table class="data-table">
          <thead>
            <tr>
              <th>Platform</th>
              <th>Description</th>
              <th>Status</th>
              <th>Complexity</th>
            </tr>
          </thead>
          <tbody>
            ${deploymentHtml}
          </tbody>
        </table>
      `;
    }
  }

  renderMonitoring() {
    setTimeout(() => {
      this.initializeMetricsChart();
    }, 100);
  }

  initializeMetricsChart() {
    const ctx = document.getElementById('metricChart');
    if (!ctx) return;

    const generateTimeSeriesData = () => {
      const data = [];
      const now = new Date();
      for (let i = 23; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 60 * 60 * 1000);
        data.push({
          x: time,
          y: Math.random() * 100 + 50
        });
      }
      return data;
    };

    this.charts.metrics = new Chart(ctx, {
      type: 'line',
      data: {
        datasets: [
          {
            label: 'CPU Usage (%)',
            data: generateTimeSeriesData(),
            borderColor: this.chartColors[0],
            backgroundColor: this.chartColors[0] + '20',
            fill: true,
            tension: 0.4
          },
          {
            label: 'Memory Usage (%)',
            data: generateTimeSeriesData(),
            borderColor: this.chartColors[1],
            backgroundColor: this.chartColors[1] + '20',
            fill: true,
            tension: 0.4
          },
          {
            label: 'Throughput (req/s)',
            data: generateTimeSeriesData(),
            borderColor: this.chartColors[2],
            backgroundColor: this.chartColors[2] + '20',
            fill: true,
            tension: 0.4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: {
              color: '#f5f5f5'
            }
          }
        },
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'hour',
              displayFormats: {
                hour: 'HH:mm'
              }
            },
            ticks: {
              color: '#a7a9a9'
            },
            grid: {
              color: '#777c7c30'
            }
          },
          y: {
            beginAtZero: true,
            max: 100,
            ticks: {
              color: '#a7a9a9'
            },
            grid: {
              color: '#777c7c30'
            }
          }
        }
      }
    });
  }

  initializeEventListeners() {
    // Button event listeners
    document.getElementById('btn-new-translation')?.addEventListener('click', () => {
      this.showModal('New Schema Translation', this.getTranslationModalContent());
    });

    document.getElementById('btn-evolve')?.addEventListener('click', () => {
      this.evolvePrompts();
    });

    document.getElementById('btn-optimize-routing')?.addEventListener('click', () => {
      this.optimizeRouting();
    });

    document.getElementById('btn-refresh-balances')?.addEventListener('click', () => {
      this.refreshTradingBalances();
    });

    document.getElementById('btn-generate-script')?.addEventListener('click', () => {
      this.generateDeploymentScript();
    });

    document.getElementById('btn-refresh-metrics')?.addEventListener('click', () => {
      this.refreshMetrics();
    });
  }

  getTranslationModalContent() {
    return `
      <div class="form-group">
        <label class="form-label">Source Provider</label>
        <select class="form-control">
          <option>OpenAI</option>
          <option>Anthropic</option>
          <option>Google Gemini</option>
          <option>Perplexity</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Target Provider</label>
        <select class="form-control">
          <option>OpenAI</option>
          <option>Anthropic</option>
          <option>Google Gemini</option>
          <option>HuggingFace</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Translation Mode</label>
        <select class="form-control">
          <option>Automatic</option>
          <option>Manual with Review</option>
          <option>Batch Processing</option>
        </select>
      </div>
    `;
  }

  evolvePrompts() {
    this.showNotification('Evolving prompts to next generation...', 'info');
    
    setTimeout(() => {
      this.data.promptEvolution.currentGeneration++;
      this.data.promptEvolution.bestFitness = Math.min(1, this.data.promptEvolution.bestFitness + 0.01);
      this.data.promptEvolution.mutations += Math.floor(Math.random() * 10) + 5;
      this.data.promptEvolution.improvements++;
      
      this.renderPromptLab();
      this.showNotification(`Evolution complete! Generation ${this.data.promptEvolution.currentGeneration} achieved`, 'success');
    }, 2000);
  }

  optimizeRouting() {
    this.showNotification('Optimizing LLM routing patterns...', 'info');
    
    setTimeout(() => {
      this.showNotification('Routing optimization complete - cost reduced by 15%', 'success');
    }, 1500);
  }

  refreshTradingBalances() {
    this.showNotification('Refreshing trading account balances...', 'info');
    
    setTimeout(() => {
      // Simulate balance updates
      this.data.tradingApis.coinbase.balance = 15420.67 + (Math.random() - 0.5) * 1000;
      this.renderTradingHub();
      this.showNotification('Trading balances updated successfully', 'success');
    }, 1000);
  }

  generateDeploymentScript() {
    const script = `#!/bin/bash
# Infinity Singularity Deployment Script

echo "🚀 Deploying Infinity Singularity Multi-Agent Platform..."

# Build Docker images
docker-compose build

# Deploy to Kubernetes
kubectl apply -f k8s/

# Configure environment variables
export OPENAI_API_KEY="${this.data.apiCredentials.openai.key}"
export ANTHROPIC_API_KEY="${this.data.apiCredentials.anthropic.key}"
export GOOGLE_API_KEY="${this.data.apiCredentials.google.key}"
export COINBASE_API_KEY="${this.data.tradingApis.coinbase.key}"

# Start services
docker-compose up -d

echo "✅ Deployment complete! Platform available at https://localhost:8080"
`;

    this.showModal('Deployment Script', `
      <div class="code-block">
        <div class="code-block__header">
          <span class="code-block__title">deploy.sh</span>
          <button class="code-block__copy" onclick="navigator.clipboard.writeText(\`${script.replace(/`/g, '\\`')}\`)">Copy</button>
        </div>
        <pre>${script}</pre>
      </div>
    `);
  }

  refreshMetrics() {
    this.showNotification('Refreshing system metrics...', 'info');
    
    setTimeout(() => {
      // Update performance metrics
      this.data.performanceMetrics.cpuUsage = Math.random() * 100;
      this.data.performanceMetrics.memoryUsage = Math.random() * 100;
      this.data.performanceMetrics.throughput = Math.floor(Math.random() * 2000) + 500;
      
      if (this.charts.metrics) {
        // Add new data points
        this.charts.metrics.data.datasets.forEach(dataset => {
          dataset.data.push({
            x: new Date(),
            y: Math.random() * 100 + 50
          });
          
          // Keep only last 24 data points
          if (dataset.data.length > 24) {
            dataset.data.shift();
          }
        });
        
        this.charts.metrics.update();
      }
      
      this.showNotification('System metrics refreshed', 'success');
    }, 1000);
  }

  showModal(title, content) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal">
        <div class="modal__header">
          <h3 class="modal__title">${title}</h3>
          <button class="modal__close" onclick="this.closest('.modal-overlay').remove()">&times;</button>
        </div>
        <div class="modal__body">
          ${content}
        </div>
        <div class="modal__footer">
          <button class="btn btn--outline" onclick="this.closest('.modal-overlay').remove()">Cancel</button>
          <button class="btn btn--primary" onclick="this.closest('.modal-overlay').remove()">Confirm</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // Close on background click
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.remove();
      }
    });
  }

  showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.remove();
    }, 4000);
  }

  startRealTimeUpdates() {
    // Update metrics every 30 seconds
    setInterval(() => {
      this.updateRealTimeData();
    }, 30000);
  }

  updateRealTimeData() {
    // Simulate real-time data updates
    this.data.systemMetrics.totalRequests += Math.floor(Math.random() * 100) + 10;
    this.data.systemMetrics.successfulRequests += Math.floor(Math.random() * 95) + 8;
    this.data.systemMetrics.avgResponseTime = Math.floor(Math.random() * 50) + 120;
    
    // Update agent last activity
    this.data.agents.forEach(agent => {
      if (agent.status === 'active') {
        agent.lastActivity = new Date().toISOString();
      }
    });
    
    // Re-render current section if it's dashboard
    if (this.currentSection === 'dashboard') {
      this.renderDashboard();
    }
  }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
  window.app = new InfinitySingularity();
});