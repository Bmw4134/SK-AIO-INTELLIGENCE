# 🧠💥 INFINITY SINGULARITY KERNEL - QUICK START GUIDE

## 🚀 EZ SETUP STEPS (5 Minutes to Running System)

### Step 1: Prerequisites Check
```bash
# Check if you have the essentials
node --version  # Need v18+
docker --version # Need Docker Desktop
git --version   # Need Git

# If missing any, run the setup script:
chmod +x setup.sh && ./setup.sh
```

### Step 2: Get Your API Keys (REQUIRED)
You need at least ONE of these to start:

| Provider | Free Tier? | Get Key From |
|----------|------------|--------------|
| 🔥 **Gemini** | ✅ Yes | [Google AI Studio](https://makersuite.google.com/app/apikey) |
| 🤖 **Claude** | ✅ Limited | [Anthropic Console](https://console.anthropic.com/) |
| 🤗 **HuggingFace** | ✅ Yes | [HF Token Settings](https://huggingface.co/settings/tokens) |
| ⚡ **Groq** | ✅ Yes | [Groq Console](https://console.groq.com/keys) |

### Step 3: Configure Environment
```bash
# Copy the template and edit it
cp .env.template .env

# Edit .env file with your API keys
nano .env  # or use any text editor

# Minimum required:
GEMINI_API_KEY=your_actual_key_here
FIREBASE_PROJECT_ID=my-singularity-project
```

### Step 4: Choose Your Deployment Mode

#### 🖥️ Option A: Local Desktop (Easiest)
```bash
# Install dependencies
npm install

# Start in development mode
npm run dev

# Your kernel is running at:
# http://localhost:3000 - Main interface
# http://localhost:8080 - WebSocket for agents
```

#### 🐳 Option B: Full Docker Stack (Recommended)
```bash
# Build and start all services
npm run docker:up

# Services will be available at:
# http://localhost:3000 - Singularity Kernel
# http://localhost:4000 - Firebase UI
# http://localhost:3001 - Grafana Dashboard
# http://localhost:9090 - Prometheus Metrics
```

#### ☁️ Option C: Cloud Deployment
```bash
# Deploy to Google Cloud Run
npm run deploy:cloud

# Deploy to edge with WASM
npm run deploy:edge
```

### Step 5: Test Your Setup
```bash
# Test the kernel
curl http://localhost:3000/health

# Expected response:
# {"status":"healthy","components":{"schema_adapter":"ready","llm_router":"ready"}}
```

---

## 🤖 CUSTOM GPT MIGRATION (Save Your GPTs Before Billing Issues!)

### Quick Backup Method:
```bash
# 1. Export your Custom GPT settings manually:
#    - Go to your Custom GPT
#    - Copy the instructions text
#    - Note any uploaded files
#    - Save capabilities list

# 2. Run the migration tool:
npm run migrate:gpt

# 3. Edit the generated config file:
nano local-gpt-backup/MyCustomGPT-config.json

# 4. Start your local version:
node local-gpt-backup/MyCustomGPT-server.js

# Your GPT clone runs at: http://localhost:3002
```

### Advanced: Full Intelligence Extraction
```bash
# Create a complete backup with conversation history
npm run migrate:gpt -- --full-backup --include-conversations

# Export to multiple formats
npm run migrate:gpt -- --export-formats=json,yaml,markdown

# Create standalone executable
npm run migrate:gpt -- --package-standalone
```

---

## 🌐 AGENT ORCHESTRATION USAGE

### Basic Multi-Agent Setup:
```typescript
import { SingularityKernel } from './src/SingularityKernel';

const kernel = new SingularityKernel({
    apiKeys: {
        gemini: process.env.GEMINI_API_KEY,
        claude: process.env.CLAUDE_API_KEY
    }
});

// Create a goal-driven agent workflow
const result = await kernel.orchestrate({
    goal: "Research AI trends and write a report",
    agents: {
        researcher: { model: "gemini", tools: ["web_search"] },
        writer: { model: "claude", tools: ["document_generation"] },
        reviewer: { model: "gemini", tools: ["quality_check"] }
    },
    workflow: "sequential" // or "parallel" or "adaptive"
});
```

### Schema Coherence Between APIs:
```typescript
// Automatically translate between different API formats
const coherentData = await kernel.adaptSchema({
    source: gptApiResponse,
    sourceSchema: "openai_format",
    targetSchema: "anthropic_format"
});
```

### Prompt Evolution:
```typescript
// Evolve prompts automatically for better performance
const evolvedPrompt = await kernel.evolvePrompt({
    basePrompt: "You are a helpful assistant",
    task: "code_generation",
    fitnessGoal: "minimize_errors"
});
```

---

## 🔧 TROUBLESHOOTING

### Common Issues:

#### ❌ "API Key Invalid"
```bash
# Check your .env file
cat .env | grep API_KEY

# Test API key manually
curl -H "Authorization: Bearer $GEMINI_API_KEY" https://generativelanguage.googleapis.com/v1/models
```

#### ❌ "Docker won't start"
```bash
# Check Docker is running
docker ps

# Restart Docker service
sudo systemctl restart docker  # Linux
# or restart Docker Desktop      # Windows/Mac
```

#### ❌ "Firebase connection failed"
```bash
# Check Firebase emulator
docker-compose logs firebase-emulator

# Reset Firebase data
rm -rf firebase/data && npm run docker:up
```

#### ❌ "WASM module not found"
```bash
# Rebuild WASM modules
npm run build:wasm

# Check WASM runtime
wasmedge --version
```

---

## 📊 MONITORING YOUR KERNEL

### Real-time Metrics:
- **Grafana Dashboard**: http://localhost:3001 (admin/admin)
- **Prometheus Metrics**: http://localhost:9090
- **Firebase Console**: http://localhost:4000

### Key Metrics to Watch:
- Schema translation latency
- LLM routing accuracy
- Agent success rates
- Cost per operation
- Edge deployment uptime

---

## 🎯 PRODUCTION DEPLOYMENT

### Security Checklist:
- [ ] Change default passwords in .env
- [ ] Enable Firebase security rules
- [ ] Set up rate limiting
- [ ] Configure SSL certificates
- [ ] Enable monitoring alerts

### Scaling:
```bash
# Horizontal scaling with Docker Swarm
docker swarm init
docker stack deploy -c docker-compose.prod.yml singularity

# Kubernetes deployment
kubectl apply -f k8s/singularity-namespace.yaml
kubectl apply -f k8s/singularity-deployment.yaml
```

---

## 🆘 EMERGENCY OFFLINE MODE

If you lose access to paid APIs:

1. **Switch to Local LLMs**:
   ```bash
   ./scripts/setup-local-llm.sh
   # Choose Ollama and run: ollama pull llama2
   ```

2. **Use Your Backed-up Custom GPTs**:
   ```bash
   node local-gpt-backup/YourGPT-server.js
   ```

3. **Enable Edge-Only Mode**:
   ```bash
   export OFFLINE_MODE=true
   npm start
   ```

Your Singularity Kernel will continue operating with reduced capabilities but full local control!
