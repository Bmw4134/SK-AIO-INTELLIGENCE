// Application data
const appData = {
  agents: [
    {
      id: "supervisor-001",
      name: "Schema Supervisor",
      status: "active",
      model: "anthropic.claude-3-5-sonnet-20241022-v2:0",
      collaborators: ["schema-translator", "validator", "lineage-tracker"],
      performance: {
        success_rate: 0.94,
        avg_latency: 1240,
        cost_per_request: 0.0034
      }
    },
    {
      id: "evolution-001", 
      name: "Prompt Evolution Agent",
      status: "active",
      model: "google/gemini-2.5-pro-preview",
      collaborators: ["mutation-engine", "fitness-evaluator"],
      performance: {
        success_rate: 0.89,
        avg_latency: 2100,
        cost_per_request: 0.0067
      }
    },
    {
      id: "router-001",
      name: "LLM Router Agent", 
      status: "active",
      model: "mistral/mixtral-8x7b-instruct",
      collaborators: ["cost-optimizer", "performance-tracker"],
      performance: {
        success_rate: 0.97,
        avg_latency: 890,
        cost_per_request: 0.0021
      }
    }
  ],
  schemas: [
    {
      id: "schema-001",
      name: "Gemini to HuggingFace",
      source: "gemini-chat-completion",
      target: "huggingface-inference",
      translations: 1247,
      success_rate: 0.963,
      avg_latency: 340
    },
    {
      id: "schema-002",
      name: "OpenAI to Bedrock",
      source: "openai-completion",
      target: "bedrock-invoke",
      translations: 892,
      success_rate: 0.981,
      avg_latency: 280
    }
  ],
  prompts: [
    {
      id: "prompt-001",
      generation: 15,
      content: "You are a schema translation agent...",
      fitness: 0.92,
      mutations: [
        {type: "semantic_swap", position: 45, improvement: 0.03},
        {type: "rewrite", position: 123, improvement: 0.07}
      ],
      lineage: ["prompt-000", "prompt-003", "prompt-008"]
    }
  ],
  models: [
    {
      provider: "anthropic",
      model: "claude-3-5-sonnet",
      tasks: ["code", "reasoning"],
      cost_per_token: 0.000003,
      performance: 0.94,
      latency: 1200
    },
    {
      provider: "google",
      model: "gemini-2.5-pro",
      tasks: ["vision", "long_context"],
      cost_per_token: 0.0000025,
      performance: 0.91,
      latency: 800
    },
    {
      provider: "mistral",
      model: "mixtral-8x7b",
      tasks: ["generation", "chat"],
      cost_per_token: 0.0000007,
      performance: 0.87,
      latency: 600
    }
  ],
  edge_deployments: [
    {
      region: "us-east-1",
      status: "active",
      functions: 23,
      wasm_size: "2.4MB",
      cold_start: "45ms",
      throughput: "15000 rps"
    },
    {
      region: "eu-west-1",
      status: "active", 
      functions: 18,
      wasm_size: "2.2MB",
      cold_start: "52ms",
      throughput: "12000 rps"
    },
    {
      region: "ap-southeast-1",
      status: "deploying",
      functions: 15,
      wasm_size: "2.1MB",
      cold_start: "48ms",
      throughput: "9000 rps"
    }
  ],
  metrics: {
    total_requests: 145230,
    success_rate: 0.943,
    avg_latency: 1100,
    cost_savings: 0.67,
    edge_cache_hit: 0.82
  }
};

// Chart configurations
const chartColors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454', '#13343B'];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
  initializeNavigation();
  initializeCharts();
  initializeInteractions();
  startRealTimeUpdates();
});

// Navigation functionality
function initializeNavigation() {
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('.content-section');
  
  navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetSection = this.getAttribute('data-section');
      
      // Update active nav link
      navLinks.forEach(nav => nav.classList.remove('active'));
      this.classList.add('active');
      
      // Update active section
      sections.forEach(section => section.classList.remove('active'));
      document.getElementById(targetSection).classList.add('active');
    });
  });
}

// Chart initialization
function initializeCharts() {
  initializePerformanceChart();
  initializeAgentPerformanceChart();
  initializeSchemaChart();
  initializeEvolutionChart();
  initializeWasmChart();
  initializeCostPerformanceChart();
}

function initializePerformanceChart() {
  const ctx = document.getElementById('performanceChart').getContext('2d');
  
  // Generate sample time series data
  const generateTimeSeriesData = (points, baseValue, variance) => {
    const data = [];
    const now = new Date();
    for (let i = points; i >= 0; i--) {
      const time = new Date(now.getTime() - i * 5 * 60 * 1000); // 5 minute intervals
      const value = baseValue + (Math.random() - 0.5) * variance;
      data.push({x: time, y: value});
    }
    return data;
  };
  
  new Chart(ctx, {
    type: 'line',
    data: {
      datasets: [
        {
          label: 'Success Rate (%)',
          data: generateTimeSeriesData(24, 94, 4),
          borderColor: chartColors[0],
          backgroundColor: chartColors[0] + '20',
          fill: true,
          tension: 0.4
        },
        {
          label: 'Latency (ms)',
          data: generateTimeSeriesData(24, 1100, 200),
          borderColor: chartColors[1],
          backgroundColor: chartColors[1] + '20',
          fill: true,
          tension: 0.4,
          yAxisID: 'y1'
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: '#f5f5f5'
          }
        }
      },
      scales: {
        x: {
          type: 'time',
          time: {
            unit: 'hour',
            displayFormats: {
              hour: 'HH:mm'
            }
          },
          ticks: {
            color: '#a7a9a9'
          },
          grid: {
            color: '#777c7c30'
          }
        },
        y: {
          beginAtZero: true,
          max: 100,
          ticks: {
            color: '#a7a9a9'
          },
          grid: {
            color: '#777c7c30'
          }
        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          ticks: {
            color: '#a7a9a9'
          },
          grid: {
            drawOnChartArea: false,
            color: '#777c7c30'
          }
        }
      }
    }
  });
}

function initializeAgentPerformanceChart() {
  const ctx = document.getElementById('agentPerformanceChart').getContext('2d');
  
  new Chart(ctx, {
    type: 'radar',
    data: {
      labels: ['Success Rate', 'Latency', 'Cost Efficiency', 'Throughput', 'Reliability'],
      datasets: [
        {
          label: 'Schema Supervisor',
          data: [94, 76, 85, 88, 92],
          borderColor: chartColors[0],
          backgroundColor: chartColors[0] + '30',
          pointBackgroundColor: chartColors[0]
        },
        {
          label: 'Evolution Agent',
          data: [89, 52, 70, 75, 85],
          borderColor: chartColors[1],
          backgroundColor: chartColors[1] + '30',
          pointBackgroundColor: chartColors[1]
        },
        {
          label: 'Router Agent',
          data: [97, 90, 95, 92, 96],
          borderColor: chartColors[2],
          backgroundColor: chartColors[2] + '30',
          pointBackgroundColor: chartColors[2]
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: '#f5f5f5'
          }
        }
      },
      scales: {
        r: {
          beginAtZero: true,
          max: 100,
          ticks: {
            color: '#a7a9a9'
          },
          grid: {
            color: '#777c7c30'
          },
          pointLabels: {
            color: '#f5f5f5'
          }
        }
      }
    }
  });
}

function initializeSchemaChart() {
  const ctx = document.getElementById('schemaChart').getContext('2d');
  
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Successful', 'Failed', 'Pending'],
      datasets: [{
        data: [94.3, 3.2, 2.5],
        backgroundColor: [
          chartColors[0],
          chartColors[2],
          chartColors[1]
        ],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: '#f5f5f5',
            padding: 20
          }
        }
      }
    }
  });
}

function initializeEvolutionChart() {
  const ctx = document.getElementById('evolutionChart').getContext('2d');
  
  const generations = Array.from({length: 16}, (_, i) => i);
  const fitnessData = [0.45, 0.52, 0.58, 0.62, 0.67, 0.71, 0.74, 0.77, 0.80, 0.83, 0.85, 0.87, 0.89, 0.90, 0.91, 0.92];
  
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: generations,
      datasets: [{
        label: 'Fitness Score',
        data: fitnessData,
        borderColor: chartColors[0],
        backgroundColor: chartColors[0] + '20',
        fill: true,
        tension: 0.4,
        pointRadius: 4,
        pointHoverRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: '#f5f5f5'
          }
        }
      },
      scales: {
        x: {
          title: {
            display: true,
            text: 'Generation',
            color: '#f5f5f5'
          },
          ticks: {
            color: '#a7a9a9'
          },
          grid: {
            color: '#777c7c30'
          }
        },
        y: {
          title: {
            display: true,
            text: 'Fitness Score',
            color: '#f5f5f5'
          },
          beginAtZero: true,
          max: 1,
          ticks: {
            color: '#a7a9a9'
          },
          grid: {
            color: '#777c7c30'
          }
        }
      }
    }
  });
}

function initializeWasmChart() {
  const ctx = document.getElementById('wasmChart').getContext('2d');
  
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['us-east-1', 'eu-west-1', 'ap-southeast-1'],
      datasets: [
        {
          label: 'Cold Start (ms)',
          data: [45, 52, 48],
          backgroundColor: chartColors[0],
          yAxisID: 'y'
        },
        {
          label: 'Throughput (K rps)',
          data: [15, 12, 9],
          backgroundColor: chartColors[1],
          yAxisID: 'y1'
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: '#f5f5f5'
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: '#a7a9a9'
          },
          grid: {
            color: '#777c7c30'
          }
        },
        y: {
          beginAtZero: true,
          position: 'left',
          title: {
            display: true,
            text: 'Cold Start (ms)',
            color: '#f5f5f5'
          },
          ticks: {
            color: '#a7a9a9'
          },
          grid: {
            color: '#777c7c30'
          }
        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          title: {
            display: true,
            text: 'Throughput (K rps)',
            color: '#f5f5f5'
          },
          ticks: {
            color: '#a7a9a9'
          },
          grid: {
            drawOnChartArea: false,
            color: '#777c7c30'
          }
        }
      }
    }
  });
}

function initializeCostPerformanceChart() {
  const ctx = document.getElementById('costPerformanceChart').getContext('2d');
  
  new Chart(ctx, {
    type: 'scatter',
    data: {
      datasets: [
        {
          label: 'Claude 3.5 Sonnet',
          data: [{x: 0.000003, y: 94}],
          backgroundColor: chartColors[0],
          borderColor: chartColors[0],
          pointRadius: 8
        },
        {
          label: 'Gemini 2.5 Pro',
          data: [{x: 0.0000025, y: 91}],
          backgroundColor: chartColors[1],
          borderColor: chartColors[1],
          pointRadius: 8
        },
        {
          label: 'Mixtral 8x7B',
          data: [{x: 0.0000007, y: 87}],
          backgroundColor: chartColors[2],
          borderColor: chartColors[2],
          pointRadius: 8
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: '#f5f5f5'
          }
        }
      },
      scales: {
        x: {
          title: {
            display: true,
            text: 'Cost per Token ($)',
            color: '#f5f5f5'
          },
          ticks: {
            color: '#a7a9a9'
          },
          grid: {
            color: '#777c7c30'
          }
        },
        y: {
          title: {
            display: true,
            text: 'Performance Score',
            color: '#f5f5f5'
          },
          beginAtZero: true,
          max: 100,
          ticks: {
            color: '#a7a9a9'
          },
          grid: {
            color: '#777c7c30'
          }
        }
      }
    }
  });
}

// Interactive functionality
function initializeInteractions() {
  // Range slider updates
  const rangeInputs = document.querySelectorAll('input[type="range"]');
  rangeInputs.forEach(input => {
    const valueSpan = input.parentElement.querySelector('.range-value');
    if (valueSpan) {
      input.addEventListener('input', function() {
        valueSpan.textContent = this.value;
      });
    }
  });
  
  // Button interactions
  const buttons = document.querySelectorAll('.btn');
  buttons.forEach(button => {
    button.addEventListener('click', function() {
      if (!this.disabled) {
        this.classList.add('loading');
        setTimeout(() => {
          this.classList.remove('loading');
        }, 1000);
      }
    });
  });
  
  // Form submissions
  const forms = document.querySelectorAll('form');
  forms.forEach(form => {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      const submitBtn = this.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.classList.add('loading');
        setTimeout(() => {
          submitBtn.classList.remove('loading');
        }, 1500);
      }
    });
  });
}

// Real-time updates
function startRealTimeUpdates() {
  // Update metrics every 5 seconds
  setInterval(updateMetrics, 5000);
  
  // Update activity feed every 30 seconds
  setInterval(updateActivityFeed, 30000);
  
  // Update agent status every 10 seconds
  setInterval(updateAgentStatus, 10000);
}

function updateMetrics() {
  // Simulate metric updates
  const totalRequests = document.querySelector('.metric-value');
  if (totalRequests) {
    const current = parseInt(totalRequests.textContent.replace(/,/g, ''));
    const updated = current + Math.floor(Math.random() * 50) + 10;
    totalRequests.textContent = updated.toLocaleString();
  }
  
  // Update other metrics with small variations
  const successRate = document.querySelectorAll('.metric-value')[1];
  if (successRate) {
    const current = parseFloat(successRate.textContent);
    const variation = (Math.random() - 0.5) * 0.2;
    const updated = Math.max(90, Math.min(100, current + variation));
    successRate.textContent = updated.toFixed(1) + '%';
  }
}

function updateActivityFeed() {
  const activities = [
    'Schema translation completed: OpenAI to Bedrock',
    'Prompt evolution generation deployed',
    'Edge deployment updated in region',
    'LLM router optimized for cost',
    'New agent collaboration established',
    'Schema validation passed',
    'Mutation improvement detected',
    'WebAssembly deployment optimized'
  ];
  
  const activityList = document.querySelector('.activity-list');
  if (activityList) {
    const newActivity = document.createElement('div');
    newActivity.className = 'activity-item';
    newActivity.innerHTML = `
      <span class="activity-time">Just now</span>
      <span class="activity-text">${activities[Math.floor(Math.random() * activities.length)]}</span>
    `;
    
    activityList.insertBefore(newActivity, activityList.firstChild);
    
    // Remove old activities to maintain list size
    const items = activityList.querySelectorAll('.activity-item');
    if (items.length > 6) {
      items[items.length - 1].remove();
    }
    
    // Update timestamps
    const timeElements = activityList.querySelectorAll('.activity-time');
    timeElements.forEach((el, index) => {
      if (index === 0) {
        el.textContent = 'Just now';
      } else {
        const minutes = index * 3 + Math.floor(Math.random() * 3);
        el.textContent = `${minutes} min ago`;
      }
    });
  }
}

function updateAgentStatus() {
  const statusElements = document.querySelectorAll('.status--success, .status--warning, .status--error');
  statusElements.forEach(status => {
    // Add a subtle pulse effect for active statuses
    if (status.classList.contains('status--success')) {
      status.style.animation = 'pulse 2s ease-in-out';
      setTimeout(() => {
        status.style.animation = '';
      }, 2000);
    }
  });
}

// Utility functions
function formatNumber(num) {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toString();
}

function formatCurrency(amount) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(amount);
}

function formatPercentage(value) {
  return (value * 100).toFixed(1) + '%';
}

// Theme switching (if needed)
function toggleTheme() {
  const body = document.body;
  const currentTheme = body.getAttribute('data-color-scheme');
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  body.setAttribute('data-color-scheme', newTheme);
}

// Export functions for potential external use
window.InfinitySingularity = {
  appData,
  updateMetrics,
  updateActivityFeed,
  updateAgentStatus,
  toggleTheme
};