#!/bin/bash
# Infinity Singularity Kernel - Universal Setup Script
# Supports: Local Desktop/Laptop, Cloud Functions, Edge Runtime, Custom GPT Migration

set -e

echo "🧠💥 INFINITY SINGULARITY KERNEL SETUP 🧠💥"
echo "=============================================="

# Check if we're on supported OS
check_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        OS="linux"
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
        OS="windows"
    else
        echo "❌ Unsupported OS: $OSTYPE"
        exit 1
    fi
    echo "✅ Detected OS: $OS"
}

# Install basic dependencies
install_deps() {
    echo "📦 Installing dependencies..."

    case $OS in
        "linux")
            sudo apt-get update
            sudo apt-get install -y curl git docker.io docker-compose nodejs npm python3 python3-pip
            ;;
        "macos")
            # Check if Homebrew is installed
            if ! command -v brew &> /dev/null; then
                echo "Installing Homebrew..."
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
            fi
            brew install curl git docker docker-compose node npm python3
            ;;
        "windows")
            echo "Please install the following manually:"
            echo "- Docker Desktop for Windows"
            echo "- Node.js 18+"
            echo "- Python 3.8+"
            echo "- Git for Windows"
            read -p "Press Enter when done..."
            ;;
    esac
}

# Setup Node.js and TypeScript environment
setup_nodejs() {
    echo "🟢 Setting up Node.js environment..."

    # Install global dependencies
    npm install -g typescript ts-node @types/node

    # Create package.json if it doesn't exist
    if [ ! -f "package.json" ]; then
        cat > package.json << 'EOF'
{
  "name": "infinity-singularity-kernel",
  "version": "1.0.0",
  "description": "Multi-agent orchestration framework with custom GPT migration",
  "main": "dist/index.js",
  "scripts": {
    "build": "tsc",
    "start": "ts-node src/index.ts",
    "dev": "ts-node --watch src/index.ts",
    "docker:build": "docker-compose -f docker-compose.singularity.yml build",
    "docker:up": "docker-compose -f docker-compose.singularity.yml up -d",
    "docker:down": "docker-compose -f docker-compose.singularity.yml down",
    "migrate:gpt": "ts-node scripts/migrate-custom-gpt.ts",
    "deploy:edge": "ts-node scripts/deploy-edge.ts",
    "deploy:cloud": "ts-node scripts/deploy-cloud.ts"
  },
  "dependencies": {
    "ajv": "^8.12.0",
    "firebase-admin": "^12.0.0",
    "@google/generative-ai": "^0.7.1",
    "@huggingface/inference": "^2.6.4",
    "express": "^4.18.2",
    "redis": "^4.6.5",
    "ws": "^8.13.0",
    "axios": "^1.4.0",
    "dotenv": "^16.0.3",
    "uuid": "^9.0.0",
    "openai": "^4.28.0"
  },
  "devDependencies": {
    "@types/express": "^4.17.17",
    "@types/ws": "^8.5.4",
    "@types/uuid": "^9.0.1",
    "typescript": "^5.0.4"
  }
}
EOF
    fi

    # Install Node.js dependencies
    npm install
}

# Setup Custom GPT Migration Tools
setup_gpt_migration() {
    echo "🤖 Setting up Custom GPT Migration Tools..."

    mkdir -p scripts/gpt-migration

    cat > scripts/migrate-custom-gpt.ts << 'EOF'
import * as fs from 'fs';
import * as path from 'path';
import axios from 'axios';

interface CustomGPTConfig {
    name: string;
    description: string;
    instructions: string;
    knowledge_files: string[];
    capabilities: string[];
    actions: any[];
}

class CustomGPTMigrator {
    private outputDir = './local-gpt-backup';

    constructor() {
        if (!fs.existsSync(this.outputDir)) {
            fs.mkdirSync(this.outputDir, { recursive: true });
        }
    }

    // Manual backup method for when you can't access ChatGPT API
    async createLocalBackup(gptConfig: CustomGPTConfig) {
        console.log(`🔄 Creating local backup for ${gptConfig.name}...`);

        // Save configuration
        const configPath = path.join(this.outputDir, `${gptConfig.name}-config.json`);
        fs.writeFileSync(configPath, JSON.stringify(gptConfig, null, 2));

        // Create standalone HTML interface
        const htmlInterface = this.generateHTMLInterface(gptConfig);
        const htmlPath = path.join(this.outputDir, `${gptConfig.name}-interface.html`);
        fs.writeFileSync(htmlPath, htmlInterface);

        // Create local server script
        const serverScript = this.generateLocalServer(gptConfig);
        const serverPath = path.join(this.outputDir, `${gptConfig.name}-server.js`);
        fs.writeFileSync(serverPath, serverScript);

        console.log(`✅ Local backup created in ${this.outputDir}`);
        console.log(`📁 Files created:`);
        console.log(`   - ${configPath}`);
        console.log(`   - ${htmlPath}`);
        console.log(`   - ${serverPath}`);
        console.log(`🚀 Run: node ${serverPath} to start local version`);
    }

    private generateHTMLInterface(config: CustomGPTConfig): string {
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${config.name} - Local Version</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .chat-container { max-width: 800px; margin: 0 auto; }
        .message { margin: 10px 0; padding: 10px; border-radius: 8px; }
        .user { background-color: #e3f2fd; text-align: right; }
        .assistant { background-color: #f5f5f5; }
        .input-area { display: flex; margin-top: 20px; }
        input { flex: 1; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }
        button { padding: 10px 20px; margin-left: 10px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="chat-container">
        <h1>${config.name}</h1>
        <p><strong>Description:</strong> ${config.description}</p>
        <div id="chat-messages"></div>
        <div class="input-area">
            <input type="text" id="user-input" placeholder="Type your message...">
            <button onclick="sendMessage()">Send</button>
        </div>
    </div>

    <script>
        const instructions = ${JSON.stringify(config.instructions)};

        async function sendMessage() {
            const input = document.getElementById('user-input');
            const message = input.value.trim();
            if (!message) return;

            addMessage(message, 'user');
            input.value = '';

            try {
                const response = await fetch('/chat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ message, instructions })
                });

                const data = await response.json();
                addMessage(data.response, 'assistant');
            } catch (error) {
                addMessage('Error: Could not get response', 'assistant');
            }
        }

        function addMessage(text, sender) {
            const messages = document.getElementById('chat-messages');
            const div = document.createElement('div');
            div.className = 'message ' + sender;
            div.textContent = text;
            messages.appendChild(div);
            messages.scrollTop = messages.scrollHeight;
        }

        document.getElementById('user-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') sendMessage();
        });
    </script>
</body>
</html>`;
    }

    private generateLocalServer(config: CustomGPTConfig): string {
        return `const express = require('express');
const path = require('path');
const app = express();
const port = 3002;

app.use(express.json());
app.use(express.static(path.dirname(__filename)));

// Serve the HTML interface
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '${config.name}-interface.html'));
});

// Chat endpoint that uses local AI or fallback logic
app.post('/chat', async (req, res) => {
    const { message, instructions } = req.body;

    try {
        // You can integrate with local LLM here (Ollama, LM Studio, etc.)
        // For now, we'll use simple pattern matching based on your GPT's behavior

        const response = await processMessageLocally(message, instructions);
        res.json({ response });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Failed to process message' });
    }
});

async function processMessageLocally(message, instructions) {
    // Simple local processing - you can enhance this with:
    // - Ollama integration
    // - LM Studio connection  
    // - Pattern matching rules
    // - Knowledge base queries

    const patterns = [
        { trigger: /hello|hi|hey/i, response: "Hello! I'm the local version of ${config.name}. How can I help you?" },
        { trigger: /help|assistance/i, response: "I'm here to help! Based on my instructions: " + instructions.substring(0, 200) + "..." },
        { trigger: /.*/, response: "I understand you're asking about: " + message + ". Let me process this based on my training..." }
    ];

    for (const pattern of patterns) {
        if (pattern.trigger.test(message)) {
            return pattern.response;
        }
    }

    return "I'm processing your request locally. For full functionality, please configure an LLM provider.";
}

app.listen(port, () => {
    console.log(\`🤖 ${config.name} local server running at http://localhost:\${port}\`);
    console.log('📖 Instructions loaded:', instructions.substring(0, 100) + '...');
});`;
    }
}

// Example usage - replace with your actual Custom GPT config
const exampleGPT: CustomGPTConfig = {
    name: "MyCustomGPT",
    description: "My specialized GPT assistant",
    instructions: "You are a helpful assistant that specializes in...",
    knowledge_files: [],
    capabilities: ["web_browsing", "code_interpreter"],
    actions: []
};

const migrator = new CustomGPTMigrator();
migrator.createLocalBackup(exampleGPT);
EOF

    echo "✅ Custom GPT migration tools created"
}

# Setup local LLM options (for offline operation)
setup_local_llm() {
    echo "🏠 Setting up local LLM options..."

    cat > scripts/setup-local-llm.sh << 'EOF'
#!/bin/bash
# Setup local LLM options for offline operation

echo "🏠 Local LLM Setup Options:"
echo "1. Ollama (recommended for most users)"
echo "2. LM Studio (GUI option)"
echo "3. GPT4All (lightweight option)"
echo "4. Llama.cpp (advanced users)"

read -p "Choose option (1-4): " choice

case $choice in
    1)
        echo "Installing Ollama..."
        curl -fsSL https://ollama.ai/install.sh | sh
        echo "To start: ollama serve"
        echo "To download models: ollama pull llama2"
        ;;
    2)
        echo "Please download LM Studio from: https://lmstudio.ai/"
        echo "Then load a model and start the local server"
        ;;
    3)
        echo "Installing GPT4All..."
        pip3 install gpt4all
        echo "Python usage: from gpt4all import GPT4All"
        ;;
    4)
        echo "Building llama.cpp..."
        git clone https://github.com/ggerganov/llama.cpp
        cd llama.cpp && make
        echo "Download GGML models and use ./main"
        ;;
esac
EOF

    chmod +x scripts/setup-local-llm.sh
}

# Setup WASM Edge for edge deployment
setup_wasm_edge() {
    echo "🌐 Setting up WASM Edge runtime..."

    # Install WasmEdge
    case $OS in
        "linux"|"macos")
            curl -sSf https://raw.githubusercontent.com/WasmEdge/WasmEdge/master/utils/install.sh | bash
            ;;
        "windows")
            echo "Download WasmEdge installer from: https://github.com/WasmEdge/WasmEdge/releases"
            ;;
    esac

    # Create WASM config
    cat > config/wasm-config.json << 'EOF'
{
    "runtime": "wasmedge",
    "memory_limit": "512MB",
    "cpu_limit": "1000m",
    "modules": {
        "schema_validator": "/wasm/schema-validator.wasm",
        "prompt_processor": "/wasm/prompt-processor.wasm"
    },
    "networking": {
        "allowed_hosts": ["api.openai.com", "api.anthropic.com", "api-inference.huggingface.co"]
    }
}
EOF
}

# Main setup function
main() {
    echo "🚀 Starting Infinity Singularity Kernel setup..."

    check_os
    install_deps
    setup_nodejs
    setup_gpt_migration
    setup_local_llm
    setup_wasm_edge

    # Create directories
    mkdir -p {config,logs,scripts,src,monitoring}

    # Copy configuration files
    if [ ! -f ".env" ]; then
        cp .env.template .env
        echo "⚠️  Please edit .env file with your API keys"
    fi

    echo ""
    echo "🎉 Setup complete! Next steps:"
    echo "1. Edit .env file with your API keys"
    echo "2. Run: npm run docker:up (for full stack)"
    echo "3. Run: npm run migrate:gpt (to backup Custom GPTs)"
    echo "4. Visit: http://localhost:3000 (main interface)"
    echo "5. Visit: http://localhost:4000 (Firebase emulator)"
    echo "6. Visit: http://localhost:3001 (monitoring dashboard)"
    echo ""
    echo "🤖 For Custom GPT migration:"
    echo "1. Export your GPT instructions manually"
    echo "2. Run: npm run migrate:gpt"
    echo "3. Start local version with: node local-gpt-backup/YourGPT-server.js"
    echo ""
    echo "🏠 For offline operation:"
    echo "1. Run: ./scripts/setup-local-llm.sh"
    echo "2. Choose your preferred local LLM"
    echo "3. Configure .env to use local endpoints"
}

main "$@"
