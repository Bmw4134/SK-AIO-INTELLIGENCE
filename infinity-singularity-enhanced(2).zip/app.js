// Quantum ASI Dashboard Application - Enhanced Version with Advanced Features
class QuantumASIDashboard {
  constructor() {
    this.currentSection = 'overview';
    this.charts = {};
    this.animations = {};
    this.isMobile = window.innerWidth <= 768;
    this.isTablet = window.innerWidth <= 1024;
    this.devicePixelRatio = window.devicePixelRatio || 1;
    this.isOffline = !navigator.onLine;
    
    // Circuit Breaker System
    this.circuitBreaker = {
      chartRenders: 0,
      apiCalls: 0,
      renderLimit: 100,
      apiLimit: 1000,
      fuseOpen: false,
      resetTime: 60000, // 1 minute
      lastReset: Date.now()
    };
    
    // Token Bucket for Rate Limiting
    this.tokenBucket = {
      tokens: 60,
      maxTokens: 60,
      refillRate: 1, // 1 token per second
      lastRefill: Date.now()
    };
    
    // Gesture Recognition
    this.gestureState = {
      isActive: false,
      startPoints: [],
      currentPoints: [],
      gestureType: null
    };
    
    // WebSocket connection for real-time updates
    this.wsConnection = null;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
    
    // Performance monitoring
    this.performanceMetrics = {
      renderTimes: [],
      apiResponseTimes: [],
      memoryUsage: [],
      networkLatency: []
    };
    
    // Cache for offline functionality
    this.dataCache = {
      tradingData: [],
      vectorMatrix: {},
      correlationNodes: [],
      performanceData: {},
      lastUpdate: null
    };
    
    // API Configuration
    this.apiConfig = {
      providers: {
        openai: { enabled: false, rateLimit: 3000, currentUsage: 0 },
        anthropic: { enabled: false, rateLimit: 1000, currentUsage: 0 },
        google: { enabled: false, rateLimit: 1500, currentUsage: 0 },
        perplexity: { enabled: false, rateLimit: 3000, currentUsage: 0 },
        huggingface: { enabled: false, rateLimit: 1200, currentUsage: 0 }
      },
      trading: {
        coinbase: { enabled: false, sandbox: false },
        binance: { enabled: false, testnet: false },
        alphaVantage: { enabled: false, dailyLimit: 25 }
      }
    };
    
    // Initialize data from provided JSON
    this.initializeData();
    this.init();
  }

  initializeData() {
    this.vectorMatrix = {
      vectors: {
        scheduler: [1.0, 3, 0.7, "idle"],
        validator: [0.9, 4, 0.9, "idle"],
        diff_engine: [0.6, 2, 0.5, "idle"],
        prompt_loader: [0.8, 5, 0.4, "idle"]
      }
    };

    this.tradingData = [
      {timestamp: 1642790400000, balance: 150.75, profit: 2.34, signal: "BULLISH_MOMENTUM", confidence: 0.87},
      {timestamp: 1642790700000, balance: 153.09, profit: 2.34, signal: "MARKET_MOMENTUM", confidence: 0.91},
      {timestamp: 1642791000000, balance: 151.45, profit: -1.64, signal: "BEARISH_REVERSAL", confidence: 0.76},
      {timestamp: 1642791300000, balance: 153.89, profit: 2.44, signal: "VOLUME_SPIKE", confidence: 0.82},
      {timestamp: 1642791600000, balance: 156.23, profit: 2.34, signal: "SUPPORT_BOUNCE", confidence: 0.88},
      {timestamp: 1642791900000, balance: 158.67, profit: 2.44, signal: "RSI_OVERSOLD", confidence: 0.85},
      {timestamp: 1642792200000, balance: 161.11, profit: 2.44, signal: "MACD_BULLISH", confidence: 0.93}
    ];

    this.correlationNodes = [
      {id: "revenue", label: "Revenue Vector", value: 125000, category: "financial", correlations: {"leads": 0.87, "automation": 0.72}, momentum: 0.85, trend: "up"},
      {id: "leads", label: "Lead Generation", value: 847, category: "business", correlations: {"revenue": 0.87, "conversion": 0.94}, momentum: 0.78, trend: "up"},
      {id: "automation", label: "Process Automation", value: 23, category: "technical", correlations: {"revenue": 0.72, "efficiency": 0.96}, momentum: 0.92, trend: "up"}
    ];

    this.performanceData = {
      totalProfit: 12.45,
      winRate: 78.5,
      tradeCount: 156,
      efficiency: 0.94,
      hourlyRate: 4.23,
      dailyGain: 2.8
    };

    this.signalColors = {
      'BULLISH_MOMENTUM': '#1FB8CD',
      'BEARISH_REVERSAL': '#B4413C',
      'MARKET_MOMENTUM': '#FFC185',
      'VOLUME_SPIKE': '#ECEBD5',
      'SUPPORT_BOUNCE': '#5D878F',
      'RSI_OVERSOLD': '#DB4545',
      'MACD_BULLISH': '#D2BA4C'
    };
  }

  init() {
    this.setupEventListeners();
    this.initializeNavigation();
    this.setupMobileNavigation();
    this.setupGestureRecognition();
    this.setupServiceWorker();
    this.initializeWebSocket();
    this.startPerformanceMonitoring();
    this.startRealTimeUpdates();
    this.updateOverviewMetrics();
    this.showSection('overview');
    this.checkNetworkStatus();
    this.setupInstallPrompt();
  }

  // Anti-Infinite Chart Render System
  useRenderFuse(renderFunction, context = 'chart') {
    if (this.circuitBreaker.fuseOpen) {
      console.warn('Circuit breaker is open - skipping render');
      return false;
    }

    if (this.circuitBreaker.chartRenders >= this.circuitBreaker.renderLimit) {
      this.openCircuitBreaker();
      return false;
    }

    if (!this.consumeToken()) {
      console.warn('Rate limit exceeded - throttling render');
      return false;
    }

    const startTime = performance.now();
    const result = renderFunction();
    const endTime = performance.now();

    this.circuitBreaker.chartRenders++;
    this.performanceMetrics.renderTimes.push(endTime - startTime);
    this.updateCircuitBreakerUI();

    return result;
  }

  openCircuitBreaker() {
    this.circuitBreaker.fuseOpen = true;
    this.updateCircuitBreakerUI();
    this.showNotification('Circuit breaker activated - system protection engaged', 'warning');
    
    setTimeout(() => {
      this.circuitBreaker.fuseOpen = false;
      this.circuitBreaker.chartRenders = 0;
      this.circuitBreaker.apiCalls = 0;
      this.updateCircuitBreakerUI();
      this.showNotification('Circuit breaker reset - system restored', 'success');
    }, this.circuitBreaker.resetTime);
  }

  consumeToken() {
    this.refillTokens();
    if (this.tokenBucket.tokens > 0) {
      this.tokenBucket.tokens--;
      return true;
    }
    return false;
  }

  refillTokens() {
    const now = Date.now();
    const timePassed = now - this.tokenBucket.lastRefill;
    const tokensToAdd = Math.floor(timePassed / 1000) * this.tokenBucket.refillRate;
    
    if (tokensToAdd > 0) {
      this.tokenBucket.tokens = Math.min(
        this.tokenBucket.maxTokens,
        this.tokenBucket.tokens + tokensToAdd
      );
      this.tokenBucket.lastRefill = now;
    }
  }

  updateCircuitBreakerUI() {
    const chartRenders = document.getElementById('chart-renders');
    const apiCalls = document.getElementById('api-calls');
    const fuseStatus = document.getElementById('fuse-status');

    if (chartRenders) chartRenders.textContent = this.circuitBreaker.chartRenders;
    if (apiCalls) apiCalls.textContent = this.circuitBreaker.apiCalls;
    if (fuseStatus) {
      fuseStatus.textContent = this.circuitBreaker.fuseOpen ? 'OPEN' : 'CLOSED';
      fuseStatus.className = `circuit-status-indicator ${this.circuitBreaker.fuseOpen ? 'fuse-open' : 'fuse-closed'}`;
    }
  }

  // Gesture Recognition System
  setupGestureRecognition() {
    if (!('ontouchstart' in window) && !navigator.maxTouchPoints) return;

    const canvases = document.querySelectorAll('.vector-canvas, .correlation-canvas, .chart-canvas');
    
    canvases.forEach(canvas => {
      const hammer = new Hammer(canvas);
      
      // Enable pinch and pan gestures
      hammer.get('pinch').set({ enable: true });
      hammer.get('pan').set({ direction: Hammer.DIRECTION_ALL });
      
      // Pinch to zoom
      hammer.on('pinchstart', (e) => {
        this.gestureState.isActive = true;
        this.gestureState.gestureType = 'pinch';
        this.showGestureHint('Pinch to zoom');
      });
      
      hammer.on('pinchmove', (e) => {
        if (canvas.id === 'vector-canvas') {
          this.handleVectorPinch(e);
        } else if (canvas.id === 'correlation-canvas') {
          this.handleCorrelationPinch(e);
        }
      });
      
      // Pan to move
      hammer.on('panstart', (e) => {
        this.gestureState.isActive = true;
        this.gestureState.gestureType = 'pan';
        this.showGestureHint('Drag to move');
      });
      
      hammer.on('panmove', (e) => {
        if (canvas.id === 'vector-canvas') {
          this.handleVectorPan(e);
        } else if (canvas.id === 'correlation-canvas') {
          this.handleCorrelationPan(e);
        }
      });
      
      // Tap to select
      hammer.on('tap', (e) => {
        this.gestureState.gestureType = 'tap';
        this.showGestureHint('Tap to select');
        this.handleCanvasTap(e, canvas);
      });
      
      // Double tap to reset
      hammer.on('doubletap', (e) => {
        this.gestureState.gestureType = 'doubletap';
        this.showGestureHint('Double tap to reset');
        this.handleCanvasDoubleTap(e, canvas);
      });
      
      hammer.on('panend pinchend', () => {
        this.gestureState.isActive = false;
        this.hideGestureHint();
      });
    });
  }

  handleVectorPinch(e) {
    // Implement vector canvas zoom
    const scale = e.scale;
    // Apply zoom transformation to vector visualization
    this.vectorZoom = (this.vectorZoom || 1) * scale;
    this.vectorZoom = Math.max(0.5, Math.min(3, this.vectorZoom));
  }

  handleVectorPan(e) {
    // Implement vector canvas pan
    this.vectorPan = this.vectorPan || { x: 0, y: 0 };
    this.vectorPan.x += e.deltaX;
    this.vectorPan.y += e.deltaY;
  }

  handleCorrelationPinch(e) {
    // Implement correlation canvas zoom
    const scale = e.scale;
    this.correlationZoom = (this.correlationZoom || 1) * scale;
    this.correlationZoom = Math.max(0.5, Math.min(3, this.correlationZoom));
  }

  handleCorrelationPan(e) {
    // Implement correlation canvas pan
    this.correlationPan = this.correlationPan || { x: 0, y: 0 };
    this.correlationPan.x += e.deltaX;
    this.correlationPan.y += e.deltaY;
  }

  handleCanvasTap(e, canvas) {
    const rect = canvas.getBoundingClientRect();
    const x = e.center.x - rect.left;
    const y = e.center.y - rect.top;
    
    if (canvas.id === 'vector-canvas') {
      this.selectVectorAtPoint(x, y);
    } else if (canvas.id === 'correlation-canvas') {
      this.selectCorrelationNodeAtPoint(x, y);
    }
  }

  handleCanvasDoubleTap(e, canvas) {
    if (canvas.id === 'vector-canvas') {
      this.vectorZoom = 1;
      this.vectorPan = { x: 0, y: 0 };
    } else if (canvas.id === 'correlation-canvas') {
      this.correlationZoom = 1;
      this.correlationPan = { x: 0, y: 0 };
    }
  }

  showGestureHint(text) {
    const overlay = document.getElementById('gesture-overlay');
    const hint = overlay.querySelector('.gesture-hint');
    if (hint) {
      hint.textContent = text;
      overlay.style.display = 'flex';
      overlay.style.opacity = '1';
    }
  }

  hideGestureHint() {
    const overlay = document.getElementById('gesture-overlay');
    overlay.style.opacity = '0';
    setTimeout(() => {
      overlay.style.display = 'none';
    }, 300);
  }

  // Progressive Web App Features
  setupServiceWorker() {
    if ('serviceWorker' in navigator) {
      const swCode = `
        const CACHE_NAME = 'quantum-asi-v1';
        const urlsToCache = [
          '/',
          '/style.css',
          '/app.js',
          'https://cdn.jsdelivr.net/npm/chart.js',
          'https://cdn.jsdelivr.net/npm/hammerjs@2.0.8'
        ];

        self.addEventListener('install', event => {
          event.waitUntil(
            caches.open(CACHE_NAME)
              .then(cache => cache.addAll(urlsToCache))
          );
        });

        self.addEventListener('fetch', event => {
          event.respondWith(
            caches.match(event.request)
              .then(response => {
                if (response) {
                  return response;
                }
                return fetch(event.request);
              })
          );
        });

        self.addEventListener('push', event => {
          const options = {
            body: event.data.text(),
            icon: '/icon-192x192.png',
            badge: '/badge-72x72.png'
          };
          event.waitUntil(
            self.registration.showNotification('Quantum ASI', options)
          );
        });
      `;

      const blob = new Blob([swCode], { type: 'application/javascript' });
      const swUrl = URL.createObjectURL(blob);

      navigator.serviceWorker.register(swUrl)
        .then(registration => {
          console.log('ServiceWorker registered:', registration);
        })
        .catch(error => {
          console.log('ServiceWorker registration failed:', error);
        });
    }
  }

  setupInstallPrompt() {
    let deferredPrompt;

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      
      const installBtn = document.getElementById('install-btn');
      if (installBtn) {
        installBtn.style.display = 'block';
        installBtn.addEventListener('click', () => {
          deferredPrompt.prompt();
          deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
              console.log('User accepted the install prompt');
            }
            deferredPrompt = null;
          });
        });
      }
    });
  }

  // WebSocket Real-time Updates
  initializeWebSocket() {
    // Mock WebSocket connection (in real implementation, connect to actual server)
    this.simulateWebSocketConnection();
  }

  simulateWebSocketConnection() {
    // Simulate real-time market data updates
    setInterval(() => {
      this.handleRealTimeUpdate({
        type: 'market_data',
        data: {
          timestamp: Date.now(),
          balance: this.generateRealisticBalance(),
          signal: this.generateRandomSignal(),
          confidence: 0.7 + Math.random() * 0.3
        }
      });
    }, 3000);

    // Simulate vector updates
    setInterval(() => {
      this.handleRealTimeUpdate({
        type: 'vector_update',
        data: this.generateVectorUpdate()
      });
    }, 5000);
  }

  handleRealTimeUpdate(update) {
    switch (update.type) {
      case 'market_data':
        this.updateMarketData(update.data);
        break;
      case 'vector_update':
        this.updateVectorData(update.data);
        break;
      case 'api_status':
        this.updateApiStatus(update.data);
        break;
    }
  }

  updateMarketData(data) {
    // Add to trading data
    this.tradingData.push({
      timestamp: data.timestamp,
      balance: data.balance,
      profit: data.balance - (this.tradingData[this.tradingData.length - 1]?.balance || 150),
      signal: data.signal,
      confidence: data.confidence
    });

    // Keep only last 50 data points
    if (this.tradingData.length > 50) {
      this.tradingData.shift();
    }

    // Update signal stream
    this.updateSignalStream(data);

    // Update charts if trading section is active
    if (this.currentSection === 'trading') {
      this.useRenderFuse(() => this.renderTradingCharts());
    }
  }

  updateSignalStream(data) {
    const signalStream = document.getElementById('signal-stream');
    if (!signalStream) return;

    const signalItem = document.createElement('div');
    signalItem.className = 'signal-item';
    signalItem.innerHTML = `
      <span class="signal-type">${data.signal}</span>
      <span class="signal-confidence">${Math.round(data.confidence * 100)}%</span>
      <span class="signal-timestamp">${new Date(data.timestamp).toLocaleTimeString()}</span>
    `;

    signalStream.insertBefore(signalItem, signalStream.firstChild);

    // Keep only last 10 signals
    while (signalStream.children.length > 10) {
      signalStream.removeChild(signalStream.lastChild);
    }
  }

  generateRealisticBalance() {
    const lastBalance = this.tradingData[this.tradingData.length - 1]?.balance || 161.11;
    const change = (Math.random() - 0.5) * 3; // ±$1.50 change
    return Math.max(0, lastBalance + change);
  }

  generateRandomSignal() {
    const signals = Object.keys(this.signalColors);
    return signals[Math.floor(Math.random() * signals.length)];
  }

  generateVectorUpdate() {
    const agents = Object.keys(this.vectorMatrix.vectors);
    const agent = agents[Math.floor(Math.random() * agents.length)];
    const vector = this.vectorMatrix.vectors[agent];
    
    return {
      agent,
      velocity: Math.min(1.0, Math.max(0.1, vector[0] + (Math.random() - 0.5) * 0.2)),
      load: Math.min(1.0, Math.max(0.1, vector[2] + (Math.random() - 0.5) * 0.2)),
      status: Math.random() > 0.7 ? 'active' : 'idle'
    };
  }

  updateVectorData(data) {
    const vector = this.vectorMatrix.vectors[data.agent];
    if (vector) {
      vector[0] = data.velocity;
      vector[2] = data.load;
      vector[3] = data.status;
      
      if (this.currentSection === 'vectors') {
        this.updateAgentMetrics();
      }
    }
  }

  // Enhanced Event Listeners
  setupEventListeners() {
    // Vector controls
    document.getElementById('vector-analyze')?.addEventListener('click', () => this.analyzeVectors());
    document.getElementById('vector-sync')?.addEventListener('click', () => this.syncVectors());
    document.getElementById('vector-reset')?.addEventListener('click', () => this.resetVectors());
    document.getElementById('phase-mode')?.addEventListener('click', () => this.togglePhaseMode());
    
    // Trading controls
    document.getElementById('execute-trade')?.addEventListener('click', () => this.executeTrade());
    document.getElementById('set-stop-loss')?.addEventListener('click', () => this.setStopLoss());
    document.getElementById('portfolio-view')?.addEventListener('click', () => this.showPortfolioView());
    
    // Correlation controls
    document.getElementById('analyze-correlations')?.addEventListener('click', () => this.analyzeCorrelations());
    document.getElementById('geographic-mode')?.addEventListener('click', () => this.toggleGeographicMode());
    
    // Quick actions
    document.getElementById('emergency-stop')?.addEventListener('click', () => this.emergencyStop());
    document.getElementById('sync-all')?.addEventListener('click', () => this.syncAllAPIs());
    document.getElementById('export-data')?.addEventListener('click', () => this.exportData());
    
    // Settings
    document.getElementById('save-api-keys')?.addEventListener('click', () => this.saveApiKeys());
    document.getElementById('notifications-btn')?.addEventListener('click', () => this.toggleNotifications());
    
    // View toggles
    document.querySelectorAll('[data-view]').forEach(btn => {
      btn.addEventListener('click', (e) => this.switchView(e.target.dataset.view));
    });
    
    // Timeframe controls
    document.querySelectorAll('[data-timeframe]').forEach(btn => {
      btn.addEventListener('click', (e) => this.switchTimeframe(e.target.dataset.timeframe));
    });

    // Network status
    window.addEventListener('online', () => this.handleOnline());
    window.addEventListener('offline', () => this.handleOffline());
    
    // Window resize
    window.addEventListener('resize', this.handleResize.bind(this));
  }

  initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const bottomNavItems = document.querySelectorAll('.bottom-nav__item');
    
    [...navLinks, ...bottomNavItems].forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const section = link.dataset.section;
        if (section) {
          this.navigateToSection(section);
        }
      });
    });
  }

  setupMobileNavigation() {
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const sidebar = document.getElementById('sidebar');
    const sidebarClose = document.getElementById('sidebar-close');

    mobileMenuToggle?.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      mobileMenuToggle.classList.toggle('active');
    });

    sidebarClose?.addEventListener('click', () => {
      sidebar.classList.remove('open');
      mobileMenuToggle.classList.remove('active');
    });

    // Close sidebar when clicking outside
    document.addEventListener('click', (e) => {
      if (this.isMobile && sidebar?.classList.contains('open')) {
        if (!sidebar.contains(e.target) && !mobileMenuToggle?.contains(e.target)) {
          sidebar.classList.remove('open');
          mobileMenuToggle?.classList.remove('active');
        }
      }
    });
  }

  navigateToSection(sectionId) {
    // Update navigation state
    document.querySelectorAll('.nav-link, .bottom-nav__item').forEach(item => {
      item.classList.remove('active');
      if (item.dataset.section === sectionId) {
        item.classList.add('active');
      }
    });

    // Close mobile sidebar
    if (this.isMobile) {
      const sidebar = document.getElementById('sidebar');
      const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
      sidebar?.classList.remove('open');
      mobileMenuToggle?.classList.remove('active');
    }

    this.showSection(sectionId);
  }

  showSection(sectionId) {
    // Hide all sections first
    document.querySelectorAll('.content-section').forEach(section => {
      section.classList.remove('active');
    });
    
    // Show target section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
      targetSection.classList.add('active');
      this.currentSection = sectionId;
      
      // Render section content after showing
      setTimeout(() => {
        this.renderSection(sectionId);
      }, 50);
    }
  }

  renderSection(sectionId) {
    switch(sectionId) {
      case 'overview':
        this.updateOverviewMetrics();
        break;
      case 'vectors':
        this.useRenderFuse(() => this.renderVectorMatrix());
        break;
      case 'trading':
        this.useRenderFuse(() => this.renderTradingCharts());
        break;
      case 'correlations':
        this.useRenderFuse(() => this.renderCorrelationMatrix());
        break;
      case 'performance':
        this.renderPerformanceMetrics();
        break;
      case 'settings':
        this.renderSettings();
        break;
    }
  }

  updateOverviewMetrics() {
    const currentBalance = this.tradingData[this.tradingData.length - 1]?.balance || 161.11;
    const totalProfit = this.performanceData.totalProfit;
    const winRate = this.performanceData.winRate;
    const efficiency = this.performanceData.efficiency;
    const progress = ((currentBalance - 150) / (1000 - 150)) * 100;

    const elements = {
      'balance-value': `$${currentBalance.toFixed(2)}`,
      'balance-change': `+$${totalProfit.toFixed(2)}`,
      'winrate-value': `${winRate.toFixed(1)}%`,
      'winrate-change': `${this.performanceData.tradeCount} trades`,
      'efficiency-value': `${(efficiency * 100).toFixed(1)}%`,
      'efficiency-change': `$${this.performanceData.hourlyRate.toFixed(2)}/hr`,
      'progress-value': `${progress.toFixed(1)}%`
    };

    Object.entries(elements).forEach(([id, value]) => {
      const element = document.getElementById(id);
      if (element) element.textContent = value;
    });

    this.updateApiHealthDisplay();
  }

  updateApiHealthDisplay() {
    const apiHealth = document.getElementById('api-health');
    if (!apiHealth) return;

    const healthData = [
      { name: 'OpenAI', latency: '142ms', rate: '2847/3000', status: 'online' },
      { name: 'Coinbase', latency: '89ms', rate: 'Live', status: 'online' },
      { name: 'Anthropic', latency: '203ms', rate: '847/1000', status: 'online' }
    ];

    apiHealth.innerHTML = healthData.map(api => `
      <div class="api-item">
        <span>${api.name}</span>
        <span class="api-latency">${api.latency}</span>
        <span class="api-rate">${api.rate}</span>
      </div>
    `).join('');
  }

  renderVectorMatrix() {
    const canvas = document.getElementById('vector-canvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    
    // High DPI support
    canvas.width = rect.width * this.devicePixelRatio;
    canvas.height = rect.height * this.devicePixelRatio;
    ctx.scale(this.devicePixelRatio, this.devicePixelRatio);
    canvas.style.width = rect.width + 'px';
    canvas.style.height = rect.height + 'px';

    // Apply zoom and pan transformations
    const zoom = this.vectorZoom || 1;
    const pan = this.vectorPan || { x: 0, y: 0 };
    
    ctx.save();
    ctx.scale(zoom, zoom);
    ctx.translate(pan.x / zoom, pan.y / zoom);

    const centerX = rect.width / 2 / zoom;
    const centerY = rect.height / 2 / zoom;
    const radius = Math.min(rect.width, rect.height) * 0.3 / zoom;

    // Clear any existing animation
    if (this.animations.vectorMatrix) {
      cancelAnimationFrame(this.animations.vectorMatrix);
    }

    const animate = () => {
      ctx.clearRect(-pan.x / zoom, -pan.y / zoom, rect.width / zoom, rect.height / zoom);
      
      // Draw enhanced grid with phase-aware patterns
      this.drawEnhancedGrid(ctx, rect.width / zoom, rect.height / zoom);
      
      // Draw quantum connections
      this.drawQuantumConnections(ctx, centerX, centerY, radius);
      
      // Draw agent nodes with phase visualization
      this.drawPhaseAwareNodes(ctx, centerX, centerY, radius);
      
      // Draw central quantum hub
      this.drawQuantumHub(ctx, centerX, centerY);
      
      ctx.restore();
      ctx.save();
      ctx.scale(zoom, zoom);
      ctx.translate(pan.x / zoom, pan.y / zoom);
      
      this.animations.vectorMatrix = requestAnimationFrame(animate);
    };

    animate();
    this.updateAgentMetrics();
  }

  drawEnhancedGrid(ctx, width, height) {
    const time = Date.now() * 0.001;
    ctx.strokeStyle = `rgba(139, 92, 246, ${0.1 + Math.sin(time) * 0.05})`;
    ctx.lineWidth = 1;
    
    const gridSize = 30;
    for (let i = 0; i <= width; i += gridSize) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, height);
      ctx.stroke();
    }
    
    for (let i = 0; i <= height; i += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(width, i);
      ctx.stroke();
    }
  }

  drawQuantumConnections(ctx, centerX, centerY, radius) {
    const agents = Object.keys(this.vectorMatrix.vectors);
    const time = Date.now() * 0.001;
    
    agents.forEach((agent, index) => {
      const angle = (index / agents.length) * 2 * Math.PI + time * 0.1;
      const x = centerX + Math.cos(angle) * radius;
      const y = centerY + Math.sin(angle) * radius;
      
      // Quantum entanglement visualization
      const [velocity, priority, load] = this.vectorMatrix.vectors[agent];
      const intensity = velocity * load;
      
      ctx.strokeStyle = `rgba(139, 92, 246, ${0.3 + intensity * 0.4})`;
      ctx.lineWidth = 2 + intensity * 2;
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(x, y);
      ctx.stroke();
      
      // Quantum interference patterns
      if (Math.random() > 0.95) {
        ctx.strokeStyle = `rgba(0, 255, 136, ${0.8})`;
        ctx.lineWidth = 1;
        ctx.setLineDash([5, 10]);
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(x, y);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    });
  }

  drawPhaseAwareNodes(ctx, centerX, centerY, radius) {
    const agents = Object.keys(this.vectorMatrix.vectors);
    const time = Date.now() * 0.001;
    
    agents.forEach((agent, index) => {
      const [velocity, priority, load, state] = this.vectorMatrix.vectors[agent];
      const angle = (index / agents.length) * 2 * Math.PI + time * 0.1;
      const x = centerX + Math.cos(angle) * radius;
      const y = centerY + Math.sin(angle) * radius;
      
      // Phase-aware size and color
      const phase = Math.sin(time * 2 + index * Math.PI / 2);
      const nodeSize = 10 + priority * 3 + phase * 2;
      const phaseColor = this.getPhaseColor(phase, agent);
      
      // Quantum field visualization
      ctx.shadowColor = phaseColor;
      ctx.shadowBlur = 20 + phase * 10;
      ctx.fillStyle = phaseColor;
      ctx.beginPath();
      ctx.arc(x, y, nodeSize, 0, 2 * Math.PI);
      ctx.fill();
      
      // Inner quantum core
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(x, y, nodeSize * 0.4, 0, 2 * Math.PI);
      ctx.fill();
      
      // Velocity vectors with quantum uncertainty
      if (velocity > 0.5) {
        this.drawQuantumVelocity(ctx, x, y, velocity, angle, phase);
      }
    });
  }

  drawQuantumHub(ctx, centerX, centerY) {
    const time = Date.now() * 0.001;
    const pulseSize = Math.sin(time * 3) * 8 + 25;
    
    // Quantum core with multiple layers
    for (let i = 0; i < 3; i++) {
      const layerSize = pulseSize - i * 5;
      const opacity = 0.8 - i * 0.2;
      
      ctx.shadowColor = '#8b5cf6';
      ctx.shadowBlur = 30 - i * 5;
      ctx.fillStyle = `rgba(139, 92, 246, ${opacity})`;
      ctx.beginPath();
      ctx.arc(centerX, centerY, layerSize, 0, 2 * Math.PI);
      ctx.fill();
    }
    
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#ffffff';
    ctx.font = '14px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('QUANTUM', centerX, centerY - 5);
    ctx.fillText('CORE', centerX, centerY + 10);
  }

  getPhaseColor(phase, agent) {
    const colors = {
      scheduler: `rgba(59, 130, 246, ${0.8 + phase * 0.2})`,
      validator: `rgba(16, 185, 129, ${0.8 + phase * 0.2})`,
      diff_engine: `rgba(245, 158, 11, ${0.8 + phase * 0.2})`,
      prompt_loader: `rgba(139, 92, 246, ${0.8 + phase * 0.2})`
    };
    return colors[agent] || `rgba(107, 114, 128, ${0.8 + phase * 0.2})`;
  }

  drawQuantumVelocity(ctx, x, y, velocity, baseAngle, phase) {
    const length = velocity * 30 + phase * 5;
    const angle = baseAngle + Math.PI / 2 + phase * 0.1;
    
    ctx.strokeStyle = `rgba(0, 255, 136, ${0.8 + phase * 0.2})`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(angle) * length, y + Math.sin(angle) * length);
    ctx.stroke();
  }

  updateAgentMetrics() {
    Object.entries(this.vectorMatrix.vectors).forEach(([agent, vector]) => {
      const [velocity, priority, load, state] = vector;
      
      const elements = {
        [`${agent}-velocity`]: velocity.toFixed(1),
        [`${agent}-priority`]: priority,
        [`${agent}-load`]: load.toFixed(1),
        [`${agent}-status`]: state
      };

      Object.entries(elements).forEach(([id, value]) => {
        const element = document.getElementById(id);
        if (element) {
          if (id.includes('status') && element.textContent !== value) {
            element.style.animation = 'statusFlash 0.5s ease-in-out';
            setTimeout(() => element.style.animation = '', 500);
          }
          element.textContent = value;
        }
      });
    });
  }

  renderTradingCharts() {
    this.renderBalanceChart();
    this.renderSignalChart();
    this.renderProfitChart();
    this.renderConfidenceChart();
  }

  renderBalanceChart() {
    const ctx = document.getElementById('balance-chart')?.getContext('2d');
    if (!ctx) return;

    if (this.charts.balance) {
      this.charts.balance.destroy();
    }

    this.charts.balance = new Chart(ctx, {
      type: 'line',
      data: {
        labels: this.tradingData.map(d => new Date(d.timestamp).toLocaleTimeString()),
        datasets: [{
          label: 'Balance',
          data: this.tradingData.map(d => d.balance),
          borderColor: '#1FB8CD',
          backgroundColor: 'rgba(31, 184, 205, 0.1)',
          fill: true,
          tension: 0.4,
          pointRadius: 4,
          pointHoverRadius: 8
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: {
            ticks: { color: '#9CA3AF' },
            grid: { color: 'rgba(156, 163, 175, 0.1)' }
          },
          y: {
            ticks: { color: '#9CA3AF' },
            grid: { color: 'rgba(156, 163, 175, 0.1)' }
          }
        },
        interaction: {
          intersect: false,
          mode: 'index'
        }
      }
    });
  }

  renderSignalChart() {
    const ctx = document.getElementById('signal-chart')?.getContext('2d');
    if (!ctx) return;

    if (this.charts.signal) {
      this.charts.signal.destroy();
    }

    const signalData = {};
    this.tradingData.forEach(trade => {
      signalData[trade.signal] = (signalData[trade.signal] || 0) + Math.abs(trade.profit);
    });

    this.charts.signal = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: Object.keys(signalData),
        datasets: [{
          data: Object.values(signalData),
          backgroundColor: Object.keys(signalData).map(signal => this.signalColors[signal] || '#666666'),
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        }
      }
    });

    this.updateSignalLegend(signalData);
  }

  updateSignalLegend(signalData) {
    const legendContainer = document.getElementById('signal-legend');
    if (legendContainer) {
      legendContainer.innerHTML = Object.keys(signalData).map(signal => `
        <div class="legend-item">
          <div class="legend-color" style="background-color: ${this.signalColors[signal] || '#666666'}"></div>
          <span>${signal}</span>
        </div>
      `).join('');
    }
  }

  renderProfitChart() {
    const ctx = document.getElementById('profit-chart')?.getContext('2d');
    if (!ctx) return;

    if (this.charts.profit) {
      this.charts.profit.destroy();
    }

    this.charts.profit = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: this.tradingData.map(d => new Date(d.timestamp).toLocaleTimeString()),
        datasets: [{
          label: 'Profit',
          data: this.tradingData.map(d => d.profit),
          backgroundColor: this.tradingData.map(d => d.profit > 0 ? '#1FB8CD' : '#B4413C'),
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: {
            ticks: { color: '#9CA3AF' },
            grid: { color: 'rgba(156, 163, 175, 0.1)' }
          },
          y: {
            ticks: { color: '#9CA3AF' },
            grid: { color: 'rgba(156, 163, 175, 0.1)' }
          }
        }
      }
    });

    this.updateProfitSummary();
  }

  updateProfitSummary() {
    const profitSummary = document.getElementById('profit-summary');
    if (profitSummary) {
      const totalProfit = this.tradingData.reduce((sum, d) => sum + d.profit, 0);
      const winCount = this.tradingData.filter(d => d.profit > 0).length;
      profitSummary.innerHTML = `
        <span>Total: $${totalProfit.toFixed(2)}</span>
        <span>Wins: ${winCount}/${this.tradingData.length}</span>
      `;
    }
  }

  renderConfidenceChart() {
    const ctx = document.getElementById('confidence-chart')?.getContext('2d');
    if (!ctx) return;

    if (this.charts.confidence) {
      this.charts.confidence.destroy();
    }

    this.charts.confidence = new Chart(ctx, {
      type: 'line',
      data: {
        labels: this.tradingData.map(d => new Date(d.timestamp).toLocaleTimeString()),
        datasets: [{
          label: 'AI Confidence',
          data: this.tradingData.map(d => d.confidence * 100),
          borderColor: '#FFC185',
          backgroundColor: 'rgba(255, 193, 133, 0.1)',
          fill: true,
          tension: 0.4,
          pointRadius: 6,
          pointHoverRadius: 10
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: {
            ticks: { color: '#9CA3AF' },
            grid: { color: 'rgba(156, 163, 175, 0.1)' }
          },
          y: {
            min: 0,
            max: 100,
            ticks: { 
              color: '#9CA3AF',
              callback: value => `${value}%`
            },
            grid: { color: 'rgba(156, 163, 175, 0.1)' }
          }
        }
      }
    });

    this.updateConfidenceIndicator();
  }

  updateConfidenceIndicator() {
    const confidenceIndicator = document.getElementById('confidence-indicator');
    if (confidenceIndicator) {
      const avgConfidence = this.tradingData.reduce((sum, d) => sum + d.confidence, 0) / this.tradingData.length;
      confidenceIndicator.innerHTML = `
        <span>Average: ${(avgConfidence * 100).toFixed(1)}%</span>
      `;
    }
  }

  renderCorrelationMatrix() {
    const canvas = document.getElementById('correlation-canvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    
    canvas.width = rect.width * this.devicePixelRatio;
    canvas.height = rect.height * this.devicePixelRatio;
    ctx.scale(this.devicePixelRatio, this.devicePixelRatio);
    canvas.style.width = rect.width + 'px';
    canvas.style.height = rect.height + 'px';

    // Apply transformations
    const zoom = this.correlationZoom || 1;
    const pan = this.correlationPan || { x: 0, y: 0 };

    if (this.animations.correlationMatrix) {
      cancelAnimationFrame(this.animations.correlationMatrix);
    }

    const animate = () => {
      ctx.clearRect(0, 0, rect.width, rect.height);
      
      ctx.save();
      ctx.scale(zoom, zoom);
      ctx.translate(pan.x / zoom, pan.y / zoom);
      
      this.drawCorrelationNetwork(ctx, rect.width / zoom, rect.height / zoom);
      
      ctx.restore();
      
      this.animations.correlationMatrix = requestAnimationFrame(animate);
    };

    animate();
  }

  drawCorrelationNetwork(ctx, width, height) {
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) * 0.3;
    const time = Date.now() * 0.001;

    // Draw quantum correlation field
    this.drawQuantumCorrelationField(ctx, centerX, centerY, radius, time);

    // Draw connections with enhanced visualization
    this.correlationNodes.forEach((node, index) => {
      const angle = (index / this.correlationNodes.length) * 2 * Math.PI;
      const x = centerX + Math.cos(angle) * radius;
      const y = centerY + Math.sin(angle) * radius;

      Object.entries(node.correlations).forEach(([targetId, strength]) => {
        const targetIndex = this.correlationNodes.findIndex(n => n.id === targetId);
        if (targetIndex !== -1) {
          const targetAngle = (targetIndex / this.correlationNodes.length) * 2 * Math.PI;
          const targetX = centerX + Math.cos(targetAngle) * radius;
          const targetY = centerY + Math.sin(targetAngle) * radius;

          this.drawQuantumConnection(ctx, x, y, targetX, targetY, strength, time);
        }
      });
    });

    // Draw enhanced nodes
    this.correlationNodes.forEach((node, index) => {
      const angle = (index / this.correlationNodes.length) * 2 * Math.PI;
      const x = centerX + Math.cos(angle) * radius;
      const y = centerY + Math.sin(angle) * radius;
      
      this.drawQuantumNode(ctx, x, y, node, time, index);
    });
  }

  drawQuantumCorrelationField(ctx, centerX, centerY, radius, time) {
    const fieldRadius = radius * 1.5;
    const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, fieldRadius);
    
    gradient.addColorStop(0, 'rgba(31, 184, 205, 0.1)');
    gradient.addColorStop(0.5, 'rgba(59, 130, 246, 0.05)');
    gradient.addColorStop(1, 'rgba(139, 92, 246, 0.02)');
    
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(centerX, centerY, fieldRadius, 0, 2 * Math.PI);
    ctx.fill();
  }

  drawQuantumConnection(ctx, x1, y1, x2, y2, strength, time) {
    const pulseIntensity = Math.sin(time * 3) * 0.3 + 0.7;
    
    ctx.strokeStyle = `rgba(59, 130, 246, ${strength * 0.8 * pulseIntensity})`;
    ctx.lineWidth = strength * 6;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    
    // Quantum interference pattern
    if (strength > 0.8) {
      ctx.strokeStyle = `rgba(255, 193, 133, ${strength * 0.6})`;
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 10]);
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }

  drawQuantumNode(ctx, x, y, node, time, index) {
    const pulseIntensity = Math.sin(time * 2 + index) * 0.3 + 0.7;
    const nodeSize = 15 + node.momentum * 10;
    
    // Quantum field
    ctx.shadowColor = this.getCategoryColor(node.category);
    ctx.shadowBlur = 25;
    ctx.fillStyle = `${this.getCategoryColor(node.category)}${Math.floor(pulseIntensity * 255).toString(16).padStart(2, '0')}`;
    ctx.beginPath();
    ctx.arc(x, y, nodeSize, 0, 2 * Math.PI);
    ctx.fill();

    // Core
    ctx.shadowBlur = 0;
    ctx.fillStyle = this.getCategoryColor(node.category);
    ctx.beginPath();
    ctx.arc(x, y, nodeSize * 0.6, 0, 2 * Math.PI);
    ctx.fill();

    // Label
    ctx.fillStyle = '#ffffff';
    ctx.font = '12px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(node.id, x, y + nodeSize + 20);
  }

  getCategoryColor(category) {
    const colors = {
      business: '#1FB8CD',
      technical: '#FFC185',
      financial: '#B4413C',
      market: '#ECEBD5',
      geographic: '#5D878F'
    };
    return colors[category] || '#DB4545';
  }

  // Network Status Management
  checkNetworkStatus() {
    this.isOffline = !navigator.onLine;
    this.updateApiStatusBar();
  }

  handleOnline() {
    this.isOffline = false;
    this.updateApiStatusBar();
    this.syncOfflineData();
    this.showNotification('Connection restored - syncing data', 'success');
  }

  handleOffline() {
    this.isOffline = true;
    this.updateApiStatusBar();
    this.showNotification('Working offline - data will sync when online', 'warning');
  }

  updateApiStatusBar() {
    const statusElements = {
      'openai-status': this.apiConfig.providers.openai.enabled && !this.isOffline,
      'anthropic-status': this.apiConfig.providers.anthropic.enabled && !this.isOffline,
      'trading-status': this.apiConfig.trading.coinbase.enabled && !this.isOffline,
      'offline-status': this.isOffline
    };

    Object.entries(statusElements).forEach(([id, isOnline]) => {
      const element = document.getElementById(id);
      if (element) {
        element.className = `api-status-dot ${isOnline ? 'online' : 'offline'}`;
      }
    });
  }

  syncOfflineData() {
    // Sync cached data when coming back online
    if (this.dataCache.lastUpdate) {
      console.log('Syncing offline data...');
      // In real implementation, send cached data to server
    }
  }

  // Performance Monitoring
  startPerformanceMonitoring() {
    setInterval(() => {
      this.collectPerformanceMetrics();
    }, 5000);
  }

  collectPerformanceMetrics() {
    // Collect various performance metrics
    if (performance.memory) {
      this.performanceMetrics.memoryUsage.push(performance.memory.usedJSHeapSize);
      if (this.performanceMetrics.memoryUsage.length > 100) {
        this.performanceMetrics.memoryUsage.shift();
      }
    }
    
    // Measure network latency
    const start = performance.now();
    fetch('/ping', { method: 'HEAD' })
      .then(() => {
        const latency = performance.now() - start;
        this.performanceMetrics.networkLatency.push(latency);
        if (this.performanceMetrics.networkLatency.length > 100) {
          this.performanceMetrics.networkLatency.shift();
        }
      })
      .catch(() => {
        // Offline or network error
      });
  }

  renderPerformanceMetrics() {
    this.renderActivityTimeline();
    this.updateEfficiencyCircle();
    this.updateRateLimiting();
  }

  renderActivityTimeline() {
    const timeline = document.getElementById('activity-timeline');
    if (!timeline) return;

    const activities = [
      { time: '11:47', action: 'Vector Analysis', status: 'completed' },
      { time: '11:52', action: 'Trade Execution', status: 'completed' },
      { time: '11:55', action: 'Correlation Update', status: 'active' },
      { time: '12:00', action: 'System Sync', status: 'pending' }
    ];

    timeline.innerHTML = activities.map(activity => `
      <div class="activity-item">
        <div class="activity-time">${activity.time}</div>
        <div class="activity-action">${activity.action}</div>
        <div class="activity-status activity-status--${activity.status}">${activity.status}</div>
      </div>
    `).join('');
  }

  updateEfficiencyCircle() {
    const circle = document.getElementById('efficiency-circle');
    if (!circle) return;

    const efficiency = this.performanceData.efficiency;
    const degrees = efficiency * 360;
    
    circle.style.background = `conic-gradient(#1FB8CD 0deg, #1FB8CD ${degrees}deg, #333 ${degrees}deg)`;
  }

  updateRateLimiting() {
    const rateLimiting = document.getElementById('rate-limiting');
    if (!rateLimiting) return;

    const rateData = [
      { name: 'OpenAI', current: 2550, max: 3000, usage: 85 },
      { name: 'Coinbase', current: 'Real-time', max: 'Live', usage: 23 }
    ];

    rateLimiting.innerHTML = rateData.map(rate => `
      <div class="rate-item">
        <span>${rate.name}</span>
        <div class="rate-bar">
          <div class="rate-fill" style="width: ${rate.usage}%"></div>
        </div>
        <span>${rate.current}${rate.max !== 'Live' ? `/${rate.max}` : ''}</span>
      </div>
    `).join('');
  }

  // Action Handlers
  analyzeVectors() {
    this.showLoading('Analyzing quantum vectors...');
    
    setTimeout(() => {
      Object.keys(this.vectorMatrix.vectors).forEach(agent => {
        const vector = this.vectorMatrix.vectors[agent];
        vector[3] = Math.random() > 0.5 ? 'analyzing' : 'optimizing';
        vector[0] = Math.min(1.0, vector[0] + (Math.random() - 0.5) * 0.1);
        vector[2] = Math.min(1.0, vector[2] + (Math.random() - 0.5) * 0.1);
      });
      
      this.updateAgentMetrics();
      this.hideLoading();
      this.showNotification('Vector analysis complete!', 'success');
    }, 2000);
  }

  syncVectors() {
    this.showLoading('Synchronizing vectors...');
    
    setTimeout(() => {
      Object.keys(this.vectorMatrix.vectors).forEach(agent => {
        const vector = this.vectorMatrix.vectors[agent];
        vector[3] = 'synced';
      });
      
      this.updateAgentMetrics();
      this.hideLoading();
      this.showNotification('Vector synchronization complete!', 'success');
    }, 1500);
  }

  resetVectors() {
    Object.keys(this.vectorMatrix.vectors).forEach(agent => {
      const vector = this.vectorMatrix.vectors[agent];
      vector[3] = 'idle';
    });
    
    this.updateAgentMetrics();
    this.showNotification('Vectors reset to idle state', 'info');
  }

  togglePhaseMode() {
    this.phaseMode = !this.phaseMode;
    this.showNotification(`Phase mode ${this.phaseMode ? 'enabled' : 'disabled'}`, 'info');
  }

  executeTrade() {
    if (this.isOffline) {
      this.showNotification('Cannot execute trades offline', 'error');
      return;
    }

    this.showLoading('Executing trade...');
    
    setTimeout(() => {
      const profit = (Math.random() - 0.3) * 5;
      const signal = this.generateRandomSignal();
      
      this.tradingData.push({
        timestamp: Date.now(),
        balance: this.tradingData[this.tradingData.length - 1].balance + profit,
        profit: profit,
        signal: signal,
        confidence: 0.8 + Math.random() * 0.2
      });
      
      this.hideLoading();
      this.showNotification(`Trade executed: ${profit > 0 ? '+' : ''}$${profit.toFixed(2)}`, profit > 0 ? 'success' : 'error');
      
      if (this.currentSection === 'trading') {
        this.useRenderFuse(() => this.renderTradingCharts());
      }
    }, 1500);
  }

  setStopLoss() {
    this.showNotification('Stop loss configured', 'success');
  }

  showPortfolioView() {
    this.showNotification('Portfolio view activated', 'info');
  }

  analyzeCorrelations() {
    this.showLoading('Analyzing correlations...');
    
    setTimeout(() => {
      this.correlationNodes.forEach(node => {
        node.momentum = Math.min(1.0, node.momentum + (Math.random() - 0.5) * 0.1);
        Object.keys(node.correlations).forEach(key => {
          node.correlations[key] = Math.min(1.0, Math.max(-1.0, 
            node.correlations[key] + (Math.random() - 0.5) * 0.1));
        });
      });
      
      this.hideLoading();
      this.showNotification('Correlation analysis complete!', 'success');
    }, 2000);
  }

  toggleGeographicMode() {
    this.geographicMode = !this.geographicMode;
    this.showNotification(`Geographic mode ${this.geographicMode ? 'enabled' : 'disabled'}`, 'info');
  }

  emergencyStop() {
    this.showNotification('Emergency stop activated - all trading halted', 'error');
    this.openCircuitBreaker();
  }

  syncAllAPIs() {
    this.showLoading('Syncing all APIs...');
    
    setTimeout(() => {
      this.hideLoading();
      this.showNotification('All APIs synchronized', 'success');
      this.updateApiStatusBar();
    }, 2000);
  }

  exportData() {
    const data = {
      tradingData: this.tradingData,
      vectorMatrix: this.vectorMatrix,
      correlationNodes: this.correlationNodes,
      performanceData: this.performanceData,
      timestamp: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `quantum-asi-data-${Date.now()}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    this.showNotification('Data exported successfully', 'success');
  }

  saveApiKeys() {
    const keys = {
      openai: document.getElementById('openai-key')?.value,
      anthropic: document.getElementById('anthropic-key')?.value,
      coinbase: document.getElementById('coinbase-key')?.value
    };
    
    // In real implementation, encrypt and store securely
    Object.entries(keys).forEach(([provider, key]) => {
      if (key) {
        this.apiConfig.providers[provider].enabled = true;
      }
    });
    
    this.showNotification('API keys saved securely', 'success');
    this.updateApiStatusBar();
  }

  toggleNotifications() {
    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        this.showNotification('Notifications are enabled', 'info');
      } else if (Notification.permission !== 'denied') {
        Notification.requestPermission().then(permission => {
          if (permission === 'granted') {
            this.showNotification('Notifications enabled', 'success');
          }
        });
      }
    }
  }

  renderSettings() {
    // Settings are rendered in HTML, just update UI state
    document.getElementById('enable-encryption').checked = true;
    document.getElementById('enable-audit').checked = true;
    document.getElementById('enable-ddos').checked = true;
    document.getElementById('enable-offline').checked = this.isOffline;
    document.getElementById('render-limit').value = this.circuitBreaker.renderLimit;
    document.getElementById('rate-limit').value = this.tokenBucket.maxTokens;
  }

  // Utility Methods
  startRealTimeUpdates() {
    this.simulateWebSocketConnection();
    
    // Update overview metrics regularly
    setInterval(() => {
      if (this.currentSection === 'overview') {
        this.updateOverviewMetrics();
      }
    }, 5000);
  }

  handleResize() {
    const wasMobile = this.isMobile;
    this.isMobile = window.innerWidth <= 768;
    this.isTablet = window.innerWidth <= 1024;
    
    if (wasMobile !== this.isMobile) {
      const sidebar = document.getElementById('sidebar');
      sidebar?.classList.remove('open');
    }
    
    // Recreate canvases with new dimensions
    if (this.currentSection === 'vectors') {
      this.useRenderFuse(() => this.renderVectorMatrix());
    } else if (this.currentSection === 'correlations') {
      this.useRenderFuse(() => this.renderCorrelationMatrix());
    }
    
    // Resize charts
    Object.values(this.charts).forEach(chart => {
      if (chart && chart.resize) {
        chart.resize();
      }
    });
  }

  showLoading(message = 'Loading...') {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
      overlay.querySelector('p').textContent = message;
      overlay.classList.remove('hidden');
    }
  }

  hideLoading() {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) {
      overlay.classList.add('hidden');
    }
  }

  showNotification(message, type = 'info') {
    const container = document.getElementById('notification-container');
    if (!container) return;

    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.textContent = message;
    notification.style.cssText = `
      padding: 16px 20px;
      margin-bottom: 8px;
      border-radius: 8px;
      color: white;
      animation: slideIn 0.3s ease-out;
      max-width: 300px;
      word-wrap: break-word;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    `;

    const colors = {
      success: '#1FB8CD',
      error: '#B4413C',
      warning: '#FFC185',
      info: '#5D878F'
    };

    notification.style.backgroundColor = colors[type] || colors.info;
    
    container.appendChild(notification);
    
    setTimeout(() => {
      notification.remove();
    }, 4000);
  }

  switchView(view) {
    document.querySelectorAll('[data-view]').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector(`[data-view="${view}"]`)?.classList.add('active');
    
    this.showNotification(`Switched to ${view} view`, 'info');
  }

  switchTimeframe(timeframe) {
    document.querySelectorAll('[data-timeframe]').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector(`[data-timeframe="${timeframe}"]`)?.classList.add('active');
    
    this.showNotification(`Switched to ${timeframe} timeframe`, 'info');
  }

  selectVectorAtPoint(x, y) {
    // Implement vector selection logic
    this.showNotification('Vector selected', 'info');
  }

  selectCorrelationNodeAtPoint(x, y) {
    // Implement correlation node selection logic
    this.showNotification('Correlation node selected', 'info');
  }
}

// Initialize application
document.addEventListener('DOMContentLoaded', () => {
  new QuantumASIDashboard();
});

// Add required CSS animations
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
  
  @keyframes statusFlash {
    0% { transform: scale(1); background: rgba(31, 184, 205, 0.2); }
    50% { transform: scale(1.1); background: rgba(31, 184, 205, 0.4); }
    100% { transform: scale(1); background: transparent; }
  }
  
  .activity-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid var(--color-border);
  }
  
  .activity-time {
    font-family: monospace;
    color: var(--color-text-secondary);
    font-size: 12px;
  }
  
  .activity-action {
    flex: 1;
    margin: 0 12px;
    color: var(--color-text);
  }
  
  .activity-status {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 10px;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  .activity-status--completed {
    background: rgba(31, 184, 205, 0.2);
    color: #1FB8CD;
  }
  
  .activity-status--active {
    background: rgba(255, 193, 133, 0.2);
    color: #FFC185;
  }
  
  .activity-status--pending {
    background: rgba(236, 235, 213, 0.2);
    color: #ECEBD5;
  }
  
  .legend-item {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 12px;
    color: var(--color-text-secondary);
  }
  
  .legend-color {
    width: 12px;
    height: 12px;
    border-radius: 50%;
  }
`;
document.head.appendChild(style);