// Enhanced Infinity Singularity Kernel Application - Fixed Version
const InfinitySingularityKernel = {
  // Application data from JSON with enhanced features
  data: {
    projects: [
      {
        name: "Litigation Intelligence",
        database: "postgresql://neondb_owner:npg_N3Bdy4oqOfZG@ep-morning-mode-a53wgbj5.us-east-2.aws.neon.tech/neondb?sslmode=require",
        apis: ["openai", "anthropic", "perplexity", "mistral", "google", "github", "stripe", "coinbase"],
        uptime: 95.8,
        status: "active"
      },
      {
        name: "AI Singularity Studio", 
        database: "postgresql://neondb_owner:npg_MhtE5Qloiva4@ep-twilight-voice-a5877i7v.us-east-2.aws.neon.tech/neondb?sslmode=require",
        apis: ["openai", "anthropic", "perplexity", "mistral", "google", "blackbox", "stripe"],
        uptime: 91.2,
        status: "active"
      },
      {
        name: "CRYPTONEXUSTRADER",
        database: "postgresql://neondb_owner:npg_UWC3YhxNryj9@ep-winter-snowflake-a5ak9n7q.us-east-2.aws.neon.tech/neondb?sslmode=require",
        apis: ["coinbase", "binance", "alpha_vantage", "marketstack", "cex_io"],
        uptime: 89.7,
        status: "active"
      }
    ],
    freeApis: [
      {
        name: "Alpha Vantage",
        type: "financial", 
        limit: "25 calls/day",
        used: 17,
        total: 25,
        description: "Free stock, forex, crypto data"
      },
      {
        name: "Marketstack",
        type: "financial",
        limit: "1000 calls/month", 
        used: 342,
        total: 1000,
        description: "Enterprise-grade market data"
      },
      {
        name: "Binance API",
        type: "trading",
        limit: "1200 requests/minute",
        used: 540,
        total: 1200,
        description: "Free crypto trading API"
      },
      {
        name: "Together AI",
        type: "ai",
        limit: "$2,500 credits",
        used: 575,
        total: 2500,
        description: "Fast LLM inference"
      }
    ],
    rateLimits: {
      openai: {rpm: 3000, tpm: 250000, current: 1950, currentTokens: 165000},
      anthropic: {rpm: 1000, tpm: 100000, current: 420, currentTokens: 42000},
      google: {rpm: 1500, tpm: 300000, current: 890, currentTokens: 178000},
      perplexity: {rpm: 3000, tpm: 200000, current: 2100, currentTokens: 140000},
      mistral: {rpm: 1000, tpm: 150000, current: 340, currentTokens: 51000},
      huggingface: {rpm: 1000, tpm: 50000, current: 230, currentTokens: 23000},
      together: {rpm: 2000, tpm: 100000, current: 1200, currentTokens: 60000},
      groq: {rpm: 6000, tpm: 400000, current: 1680, currentTokens: 112000}
    },
    systemStatus: {
      active: true,
      uptime: "72h 31m",
      totalAgents: 42,
      activeConnections: 156,
      performanceScore: 94.2,
      costOptimization: 67.8,
      errorCount: 0,
      lastErrorTime: null
    },
    agents: [
      {
        id: "schema-agent-001",
        name: "Schema Coherence Adapter",
        type: "translator",
        status: "active",
        performance: 89.5,
        requests: 2847,
        errors: 12,
        successRate: 89.5
      },
      {
        id: "prompt-agent-002", 
        name: "Prompt Evolution Engine",
        type: "optimizer",
        status: "active",
        performance: 95.3,
        requests: 1205,
        errors: 3,
        successRate: 95.3
      },
      {
        id: "router-agent-003",
        name: "LLM Router",
        type: "router",
        status: "active", 
        performance: 91.7,
        requests: 5632,
        errors: 28,
        successRate: 91.7
      },
      {
        id: "trading-agent-004",
        name: "Trading Automation",
        type: "automation",
        status: "monitoring",
        performance: 87.2,
        requests: 892,
        errors: 7,
        successRate: 87.2
      }
    ],
    marketData: [
      {
        symbol: "BTC/USD",
        source: "Binance",
        price: 42350.00,
        change: 2.3,
        volume: 1250000
      },
      {
        symbol: "ETH/USD",
        source: "Alpha Vantage",
        price: 2847.50,
        change: -1.7,
        volume: 890000
      },
      {
        symbol: "AAPL",
        source: "Marketstack",
        price: 187.25,
        change: 0.8,
        volume: 45000000
      }
    ],
    tradingSignals: [
      {
        symbol: "BTC/USD",
        type: "BUY",
        strength: "Strong",
        timestamp: new Date(Date.now() - 2 * 60 * 1000)
      },
      {
        symbol: "ETH/USD",
        type: "SELL",
        strength: "Moderate",
        timestamp: new Date(Date.now() - 8 * 60 * 1000)
      },
      {
        symbol: "AAPL",
        type: "HOLD",
        strength: "Weak",
        timestamp: new Date(Date.now() - 15 * 60 * 1000)
      }
    ],
    apiEndpoints: [
      {
        name: "OpenAI API",
        url: "api.openai.com",
        uptime: 99.9,
        responseTime: 245,
        status: "healthy"
      },
      {
        name: "Anthropic API",
        url: "api.anthropic.com",
        uptime: 98.7,
        responseTime: 312,
        status: "healthy"
      },
      {
        name: "Binance API",
        url: "api.binance.com",
        uptime: 97.3,
        responseTime: 158,
        status: "healthy"
      }
    ],
    costAnalysis: [
      {
        api: "OpenAI",
        amount: 247.50,
        percentage: 45
      },
      {
        api: "Anthropic",
        amount: 158.25,
        percentage: 29
      },
      {
        api: "Google",
        amount: 89.75,
        percentage: 16
      },
      {
        api: "Others",
        amount: 54.50,
        percentage: 10
      }
    ]
  },

  // Chart configurations
  chartColors: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454', '#13343B'],
  charts: {},
  currentSection: 'dashboard',
  initialized: false,

  // Initialize the application
  init() {
    if (this.initialized) return;
    
    this.initialized = true;
    this.initializeNavigation();
    this.initializeCharts();
    this.initializeInteractions();
    this.initializeWebSocket();
    this.startRealTimeUpdates();
    this.initializeAdvancedFeatures();
    this.initializeAPIConfiguration();
    this.initializeTradingFeatures();
    this.initializeSystemHealthMonitoring();
    
    // Show initial success notification
    setTimeout(() => {
      this.showNotification('System initialized successfully', 'success');
    }, 1000);
  },

  // Fixed Navigation functionality
  initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.content-section');
    
    // Ensure initial state is correct
    this.showSection('dashboard');
    
    navLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        const targetSection = link.getAttribute('data-section');
        
        // Prevent duplicate navigation
        if (targetSection === this.currentSection) {
          return;
        }
        
        // Update navigation state
        this.showSection(targetSection);
        
        // Update active nav link
        navLinks.forEach(nav => nav.classList.remove('active'));
        link.classList.add('active');
        
        // Log navigation for debugging
        console.log(`Navigated to: ${targetSection}`);
      });
    });
  },

  showSection(sectionId) {
    const sections = document.querySelectorAll('.content-section');
    const targetSection = document.getElementById(sectionId);
    
    if (!targetSection) {
      console.error(`Section ${sectionId} not found`);
      return;
    }
    
    // Hide all sections
    sections.forEach(section => {
      section.classList.remove('active');
      section.style.display = 'none';
    });
    
    // Show target section
    targetSection.style.display = 'block';
    targetSection.classList.add('active');
    
    // Update current section
    this.currentSection = sectionId;
    
    // Initialize section-specific features
    this.initializeSectionFeatures(sectionId);
  },

  initializeSectionFeatures(sectionId) {
    switch(sectionId) {
      case 'dashboard':
        this.refreshDashboardCharts();
        break;
      case 'api-config':
        this.updateAPIConfiguration();
        break;
      case 'trading':
        this.updateTradingData();
        break;
      case 'system-health':
        this.updateSystemHealth();
        break;
    }
  },

  refreshDashboardCharts() {
    // Only refresh charts if they exist and we're on dashboard
    if (this.currentSection === 'dashboard') {
      setTimeout(() => {
        if (this.charts.apiUsage) this.charts.apiUsage.update();
        if (this.charts.agentPerformance) this.charts.agentPerformance.update();
      }, 100);
    }
  },

  // Chart initialization
  initializeCharts() {
    // Add delay to ensure DOM is ready
    setTimeout(() => {
      this.initializeAPIUsageChart();
      this.initializeAgentPerformanceChart();
      this.initializePortfolioChart();
      this.initializeValidationChart();
      this.initializeFitnessChart();
      this.initializeErrorRateChart();
      this.initializeArchitectureChart();
    }, 500);
  },

  initializeAPIUsageChart() {
    const ctx = document.getElementById('apiUsageChart');
    if (!ctx) return;
    
    const apiData = Object.entries(this.data.rateLimits).map(([api, limits]) => ({
      api: api.charAt(0).toUpperCase() + api.slice(1),
      usage: (limits.current / limits.rpm) * 100,
      current: limits.current,
      limit: limits.rpm
    }));
    
    this.charts.apiUsage = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: apiData.map(item => item.api),
        datasets: [{
          label: 'Usage %',
          data: apiData.map(item => item.usage),
          backgroundColor: this.chartColors.slice(0, apiData.length),
          borderColor: this.chartColors.slice(0, apiData.length),
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: { color: '#f5f5f5' }
          }
        },
        scales: {
          x: {
            ticks: { color: '#a7a9a9' },
            grid: { color: '#777c7c30' }
          },
          y: {
            beginAtZero: true,
            max: 100,
            ticks: { 
              color: '#a7a9a9',
              callback: function(value) {
                return value + '%';
              }
            },
            grid: { color: '#777c7c30' }
          }
        }
      }
    });
  },

  initializeAgentPerformanceChart() {
    const ctx = document.getElementById('agentPerformanceChart');
    if (!ctx) return;
    
    this.charts.agentPerformance = new Chart(ctx, {
      type: 'radar',
      data: {
        labels: ['Performance', 'Requests', 'Reliability', 'Efficiency', 'Speed'],
        datasets: this.data.agents.map((agent, index) => ({
          label: agent.name,
          data: [
            agent.performance,
            Math.min(agent.requests / 100, 100),
            Math.max(100 - agent.errors, 85),
            Math.random() * 20 + 80,
            Math.random() * 15 + 85
          ],
          borderColor: this.chartColors[index],
          backgroundColor: this.chartColors[index] + '30',
          pointBackgroundColor: this.chartColors[index]
        }))
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#f5f5f5' } }
        },
        scales: {
          r: {
            beginAtZero: true,
            max: 100,
            ticks: { color: '#a7a9a9' },
            grid: { color: '#777c7c30' },
            pointLabels: { color: '#f5f5f5' }
          }
        }
      }
    });
  },

  initializePortfolioChart() {
    const ctx = document.getElementById('portfolioChart');
    if (!ctx) return;
    
    const generatePortfolioData = () => {
      const data = [];
      const now = new Date();
      const baseValue = 125847.50;
      
      for (let i = 30; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
        const variation = (Math.random() - 0.5) * 2000; // Reduced variation
        const value = baseValue + variation;
        data.push({x: time, y: value});
      }
      return data;
    };
    
    this.charts.portfolio = new Chart(ctx, {
      type: 'line',
      data: {
        datasets: [{
          label: 'Portfolio Value',
          data: generatePortfolioData(),
          borderColor: this.chartColors[0],
          backgroundColor: this.chartColors[0] + '20',
          fill: true,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#f5f5f5' } }
        },
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'day',
              displayFormats: { day: 'MMM dd' }
            },
            ticks: { color: '#a7a9a9' },
            grid: { color: '#777c7c30' }
          },
          y: {
            ticks: { 
              color: '#a7a9a9',
              callback: function(value) {
                return '$' + value.toLocaleString();
              }
            },
            grid: { color: '#777c7c30' }
          }
        }
      }
    });
  },

  initializeValidationChart() {
    const ctx = document.getElementById('validationChart');
    if (!ctx) return;
    
    const validationData = [
      { mapping: 'OpenAI → Bedrock', success: 94.5 },
      { mapping: 'Gemini → HuggingFace', success: 91.2 },
      { mapping: 'Anthropic → Together', success: 87.8 },
      { mapping: 'Perplexity → Groq', success: 89.6 }
    ];
    
    this.charts.validation = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: validationData.map(item => item.mapping),
        datasets: [{
          data: validationData.map(item => item.success),
          backgroundColor: this.chartColors.slice(0, validationData.length),
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#f5f5f5', padding: 20 }
          }
        }
      }
    });
  },

  initializeFitnessChart() {
    const ctx = document.getElementById('fitnessChart');
    if (!ctx) return;
    
    const generations = Array.from({length: 20}, (_, i) => i + 1);
    const fitnessData = generations.map(gen => 
      0.4 + (gen * 0.025) + (Math.random() * 0.02) // More stable progression
    );
    
    this.charts.fitness = new Chart(ctx, {
      type: 'line',
      data: {
        labels: generations,
        datasets: [{
          label: 'Fitness Score',
          data: fitnessData,
          borderColor: this.chartColors[0],
          backgroundColor: this.chartColors[0] + '20',
          fill: true,
          tension: 0.4,
          pointRadius: 4,
          pointHoverRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#f5f5f5' } }
        },
        scales: {
          x: {
            title: { display: true, text: 'Generation', color: '#f5f5f5' },
            ticks: { color: '#a7a9a9' },
            grid: { color: '#777c7c30' }
          },
          y: {
            title: { display: true, text: 'Fitness Score', color: '#f5f5f5' },
            beginAtZero: true,
            max: 1,
            ticks: { color: '#a7a9a9' },
            grid: { color: '#777c7c30' }
          }
        }
      }
    });
  },

  initializeErrorRateChart() {
    const ctx = document.getElementById('errorRateChart');
    if (!ctx) return;
    
    const generateErrorData = () => {
      const data = [];
      const now = new Date();
      
      for (let i = 24; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 60 * 60 * 1000);
        const errorRate = Math.max(0, Math.random() * 3 + 0.5); // Lower error rates
        data.push({x: time, y: errorRate});
      }
      return data;
    };
    
    this.charts.errorRate = new Chart(ctx, {
      type: 'line',
      data: {
        datasets: [{
          label: 'Error Rate %',
          data: generateErrorData(),
          borderColor: this.chartColors[2],
          backgroundColor: this.chartColors[2] + '20',
          fill: true,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#f5f5f5' } }
        },
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'hour',
              displayFormats: { hour: 'HH:mm' }
            },
            ticks: { color: '#a7a9a9' },
            grid: { color: '#777c7c30' }
          },
          y: {
            beginAtZero: true,
            max: 10,
            ticks: { 
              color: '#a7a9a9',
              callback: function(value) {
                return value.toFixed(1) + '%';
              }
            },
            grid: { color: '#777c7c30' }
          }
        }
      }
    });
  },

  initializeArchitectureChart() {
    const ctx = document.getElementById('architectureChart');
    if (!ctx) return;
    
    const architectures = [
      { name: 'MoE', performance: 95.2 },
      { name: 'RAG', performance: 89.7 },
      { name: 'Neuro-Symbolic', performance: 87.3 },
      { name: 'Quantum-Classical', performance: 0 }
    ];
    
    this.charts.architecture = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: architectures.map(arch => arch.name),
        datasets: [{
          label: 'Performance Score',
          data: architectures.map(arch => arch.performance),
          backgroundColor: this.chartColors.slice(0, architectures.length),
          borderColor: this.chartColors.slice(0, architectures.length),
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#f5f5f5' } }
        },
        scales: {
          x: {
            ticks: { color: '#a7a9a9' },
            grid: { color: '#777c7c30' }
          },
          y: {
            beginAtZero: true,
            max: 100,
            ticks: { 
              color: '#a7a9a9',
              callback: function(value) {
                return value + '%';
              }
            },
            grid: { color: '#777c7c30' }
          }
        }
      }
    });
  },

  // API Configuration Features
  initializeAPIConfiguration() {
    // Project selection handler
    const projectSelect = document.getElementById('projectSelect');
    if (projectSelect) {
      projectSelect.addEventListener('change', (e) => {
        const selectedProject = this.data.projects.find(p => 
          p.name.toLowerCase().includes(e.target.value)
        );
        if (selectedProject) {
          this.updateProjectDetails(selectedProject);
        }
      });
    }

    // API key edit handlers
    const editButtons = document.querySelectorAll('.api-key-item .btn--outline');
    editButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        const apiName = e.target.closest('.api-key-item').querySelector('.api-key-name').textContent;
        this.editAPIKey(apiName);
      });
    });

    // API test handlers
    const testButtons = document.querySelectorAll('.api-key-item .btn--secondary');
    testButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        const apiName = e.target.closest('.api-key-item').querySelector('.api-key-name').textContent;
        this.testAPI(apiName);
      });
    });
  },

  updateProjectDetails(project) {
    const detailsContainer = document.querySelector('.project-details');
    if (detailsContainer) {
      detailsContainer.innerHTML = `
        <div class="detail-item">
          <span class="detail-label">Database:</span>
          <span class="detail-value">PostgreSQL (Neon)</span>
        </div>
        <div class="detail-item">
          <span class="detail-label">APIs:</span>
          <span class="detail-value">${project.apis.length} configured</span>
        </div>
        <div class="detail-item">
          <span class="detail-label">Status:</span>
          <span class="status status--success">${project.status}</span>
        </div>
        <div class="detail-item">
          <span class="detail-label">Uptime:</span>
          <span class="detail-value">${project.uptime}%</span>
        </div>
      `;
    }
  },

  updateAPIConfiguration() {
    // Update rate limit displays
    const rateLimitItems = document.querySelectorAll('.rate-limit-item');
    rateLimitItems.forEach((item, index) => {
      const apis = Object.keys(this.data.rateLimits);
      if (apis[index]) {
        const apiData = this.data.rateLimits[apis[index]];
        const usage = (apiData.current / apiData.rpm) * 100;
        
        const fillElement = item.querySelector('.rate-limit-fill');
        const currentElement = item.querySelector('.rate-limit-current');
        
        if (fillElement) fillElement.style.width = `${usage}%`;
        if (currentElement) currentElement.textContent = `${apiData.current}/${apiData.rpm}`;
      }
    });
  },

  updateTradingData() {
    // Update market data with more stable values
    this.data.marketData.forEach((market, index) => {
      const variation = (Math.random() - 0.5) * 0.5; // Much smaller variations
      market.change = Math.max(-5, Math.min(5, market.change + variation));
      market.price = market.price * (1 + market.change / 100);
    });
    
    this.updateMarketDataDisplay();
  },

  updateMarketDataDisplay() {
    const marketItems = document.querySelectorAll('.market-item');
    marketItems.forEach((item, index) => {
      if (this.data.marketData[index]) {
        const data = this.data.marketData[index];
        const priceElement = item.querySelector('.price-value');
        const changeElement = item.querySelector('.price-change');
        
        if (priceElement) {
          priceElement.textContent = `$${data.price.toLocaleString()}`;
        }
        
        if (changeElement) {
          changeElement.textContent = `${data.change > 0 ? '+' : ''}${data.change.toFixed(1)}%`;
          changeElement.className = `price-change ${data.change > 0 ? 'positive' : 'negative'}`;
        }
      }
    });
  },

  // Trading Features
  initializeTradingFeatures() {
    this.updateMarketDataDisplay();
    this.updateTradingSignals();
    this.initializeRiskManagement();
  },

  updateTradingSignals() {
    const signalItems = document.querySelectorAll('.signal-item');
    signalItems.forEach((item, index) => {
      if (this.data.tradingSignals[index]) {
        const signal = this.data.tradingSignals[index];
        const timeElement = item.querySelector('.signal-time');
        
        if (timeElement) {
          const timeDiff = Date.now() - signal.timestamp.getTime();
          const minutes = Math.floor(timeDiff / 60000);
          timeElement.textContent = `${minutes} min ago`;
        }
      }
    });
  },

  initializeRiskManagement() {
    const riskInputs = document.querySelectorAll('.risk-controls input');
    riskInputs.forEach(input => {
      input.addEventListener('change', () => {
        this.updateRiskScore();
      });
    });
  },

  updateRiskScore() {
    const inputs = document.querySelectorAll('.risk-controls input');
    const positionSize = parseFloat(inputs[0]?.value) || 0;
    const stopLoss = parseFloat(inputs[1]?.value) || 0;
    const dailyLimit = parseFloat(inputs[2]?.value) || 0;
    
    let riskScore = 'Low';
    let riskColor = '#1FB8CD';
    
    if (positionSize > 2000 || stopLoss < 2 || dailyLimit > 1000) {
      riskScore = 'High';
      riskColor = '#B4413C';
    } else if (positionSize > 1000 || stopLoss < 5 || dailyLimit > 500) {
      riskScore = 'Medium';
      riskColor = '#FFC185';
    }
    
    const riskValue = document.querySelector('.risk-value');
    const riskIndicator = document.querySelector('.risk-indicator');
    
    if (riskValue) riskValue.textContent = riskScore;
    if (riskIndicator) riskIndicator.style.backgroundColor = riskColor;
  },

  // System Health Monitoring
  initializeSystemHealthMonitoring() {
    this.monitorEndpoints();
    this.trackCosts();
    this.initializeAlerts();
  },

  monitorEndpoints() {
    const updateEndpointStatus = () => {
      this.data.apiEndpoints.forEach((endpoint, index) => {
        const item = document.querySelectorAll('.endpoint-item')[index];
        if (item) {
          const uptimeElement = item.querySelector('.uptime');
          const responseTimeElement = item.querySelector('.response-time');
          const statusElement = item.querySelector('.status');
          
          if (uptimeElement) uptimeElement.textContent = `${endpoint.uptime.toFixed(1)}%`;
          if (responseTimeElement) responseTimeElement.textContent = `${endpoint.responseTime}ms`;
          if (statusElement) {
            statusElement.className = `status status--${endpoint.status === 'healthy' ? 'success' : 'warning'}`;
            statusElement.textContent = endpoint.status.charAt(0).toUpperCase() + endpoint.status.slice(1);
          }
        }
      });
    };
    
    updateEndpointStatus();
    setInterval(updateEndpointStatus, 30000);
  },

  trackCosts() {
    const updateCostBreakdown = () => {
      const totalCost = this.data.costAnalysis.reduce((sum, item) => sum + item.amount, 0);
      
      const costItems = document.querySelectorAll('.cost-item');
      costItems.forEach((item, index) => {
        if (this.data.costAnalysis[index]) {
          const cost = this.data.costAnalysis[index];
          const amountElement = item.querySelector('.cost-amount');
          const percentageElement = item.querySelector('.cost-percentage');
          
          if (amountElement) amountElement.textContent = `$${cost.amount.toFixed(2)}`;
          if (percentageElement) percentageElement.textContent = `${cost.percentage}%`;
        }
      });
      
      const totalElement = document.querySelector('.cost-value');
      if (totalElement) totalElement.textContent = `$${totalCost.toFixed(2)}`;
    };
    
    updateCostBreakdown();
    setInterval(updateCostBreakdown, 60000);
  },

  initializeAlerts() {
    const alertInputs = document.querySelectorAll('.alert-setting input');
    alertInputs.forEach(input => {
      input.addEventListener('change', () => {
        this.updateAlertConfiguration();
      });
    });
  },

  updateAlertConfiguration() {
    const inputs = document.querySelectorAll('.alert-setting input');
    const errorThreshold = parseFloat(inputs[0]?.value) || 5;
    const responseThreshold = parseFloat(inputs[1]?.value) || 1000;
    const costThreshold = parseFloat(inputs[2]?.value) || 1000;
    
    this.alertConfig = {
      errorThreshold,
      responseThreshold,
      costThreshold
    };
    
    this.showNotification('Alert configuration updated', 'success');
  },

  // Interactive functionality
  initializeInteractions() {
    // Button interactions
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        if (!button.disabled && !button.classList.contains('loading')) {
          this.handleButtonClick(button, e);
        }
      });
    });

    // Form submissions
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleFormSubmission(form);
      });
    });

    // Range slider updates
    const rangeInputs = document.querySelectorAll('input[type="range"]');
    rangeInputs.forEach(input => {
      input.addEventListener('input', () => {
        const rateSpan = input.closest('.mutation-operator')?.querySelector('.operator-rate');
        if (rateSpan) {
          rateSpan.textContent = input.value + '%';
        }
      });
    });

    // Workflow node interactions
    this.initializeWorkflowNodes();
  },

  initializeWorkflowNodes() {
    const workflowNodes = document.querySelectorAll('.workflow-node');
    workflowNodes.forEach(node => {
      node.addEventListener('click', (e) => {
        e.preventDefault();
        const agentType = node.getAttribute('data-agent');
        this.showAgentDetails(agentType);
      });
    });
  },

  showAgentDetails(agentType) {
    const agent = this.data.agents.find(a => a.id.includes(agentType) || a.type === agentType);
    if (agent) {
      const modal = this.createModal('Agent Details', `
        <div class="agent-detail">
          <h4>${agent.name}</h4>
          <div class="detail-grid">
            <div class="detail-item">
              <span class="detail-label">Type:</span>
              <span class="detail-value">${agent.type}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Status:</span>
              <span class="detail-value">${agent.status}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Performance:</span>
              <span class="detail-value">${agent.performance}%</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Requests:</span>
              <span class="detail-value">${agent.requests.toLocaleString()}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Errors:</span>
              <span class="detail-value">${agent.errors}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">Success Rate:</span>
              <span class="detail-value">${agent.successRate}%</span>
            </div>
          </div>
        </div>
      `);
    }
  },

  handleButtonClick(button, event) {
    const buttonText = button.textContent.trim();
    
    // Prevent multiple clicks
    if (button.classList.contains('loading')) return;
    
    button.classList.add('loading');
    
    const processingTime = 800 + Math.random() * 400; // Shorter processing time
    
    setTimeout(() => {
      button.classList.remove('loading');
      
      // Handle specific button actions
      switch(buttonText) {
        case 'Refresh':
          this.refreshDashboard();
          break;
        case 'Export Data':
          this.exportData();
          break;
        case 'Save Configuration':
          this.saveConfiguration();
          break;
        case 'Test All APIs':
          this.testAllAPIs();
          break;
        case 'Create Agent':
          this.createAgent();
          break;
        case 'Deploy All':
          this.deployAll();
          break;
        case 'Evolve':
          this.evolvePrompt();
          break;
        case 'Start Trading':
          this.startTrading();
          break;
        case 'Manual Verification':
          this.manualVerification();
          break;
        case 'Upload Schema':
          this.uploadSchema();
          break;
        case 'Validate All':
          this.validateAllSchemas();
          break;
        case 'Create DNA':
          this.createDNA();
          break;
        case 'Generate Report':
          this.generateReport();
          break;
        case 'Run Diagnostics':
          this.runDiagnostics();
          break;
        case 'Test Endpoint':
          this.testEndpoint();
          break;
        case 'Generate Action':
          this.generateGPTAction();
          break;
        case 'Benchmark':
          this.benchmarkArchitecture();
          break;
        case 'Migrate':
          this.migrateArchitecture();
          break;
        default:
          this.showNotification(`${buttonText} executed successfully`, 'success');
      }
    }, processingTime);
  },

  // Fixed modal creation
  createModal(title, content) {
    // Remove existing modals
    const existingModals = document.querySelectorAll('.modal-overlay');
    existingModals.forEach(modal => modal.remove());
    
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal-content">
        <div class="modal-header">
          <h3>${title}</h3>
          <button class="modal-close" type="button">&times;</button>
        </div>
        <div class="modal-body">
          ${content}
        </div>
        <div class="modal-footer">
          <button class="btn btn--outline" type="button">Cancel</button>
          <button class="btn btn--primary" type="button">Confirm</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // Event listeners
    modal.querySelector('.modal-close').addEventListener('click', () => {
      modal.remove();
    });
    
    modal.querySelector('.btn--outline').addEventListener('click', () => {
      modal.remove();
    });
    
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.remove();
      }
    });
    
    return modal;
  },

  // Stable WebSocket simulation
  initializeWebSocket() {
    this.websocket = {
      connected: true,
      lastMessage: new Date(),
      messageQueue: [],
      errorsSent: 0,
      maxErrors: 2 // Limit error notifications
    };
    
    // Longer intervals for more stable behavior
    setInterval(() => {
      this.simulateWebSocketMessage();
    }, 15000); // Every 15 seconds instead of 5
  },

  simulateWebSocketMessage() {
    const messageTypes = [
      'api_usage_update',
      'market_data_update',
      'agent_status_change',
      'schema_validation_complete',
      'trading_signal_generated',
      'system_health_update'
    ];
    
    // Only send error occasionally and with limit
    if (Math.random() < 0.05 && this.websocket.errorsSent < this.websocket.maxErrors) {
      messageTypes.push('error_detected');
    }
    
    const messageType = messageTypes[Math.floor(Math.random() * messageTypes.length)];
    this.handleWebSocketMessage({ type: messageType, data: this.generateMessageData(messageType) });
  },

  generateMessageData(type) {
    switch(type) {
      case 'api_usage_update':
        return {
          api: 'openai',
          current: Math.floor(Math.random() * 500) + 1500, // More stable range
          limit: 3000
        };
      case 'market_data_update':
        return {
          symbol: 'BTC/USD',
          price: 42000 + (Math.random() - 0.5) * 200, // Smaller price changes
          change: (Math.random() - 0.5) * 1 // Smaller percentage changes
        };
      case 'agent_status_change':
        return {
          agentId: 'agent-001',
          status: 'active',
          performance: 89 + Math.random() * 6 // More stable performance
        };
      default:
        return {};
    }
  },

  handleWebSocketMessage(message) {
    // Process real-time updates based on message type
    switch(message.type) {
      case 'api_usage_update':
        this.updateAPIUsage(message.data);
        break;
      case 'market_data_update':
        if (this.currentSection === 'trading') {
          this.updateTradingData();
        }
        break;
      case 'error_detected':
        this.websocket.errorsSent++;
        this.showNotification('Minor system anomaly detected - auto-correcting', 'warning');
        break;
      case 'system_health_update':
        this.showNotification('System health check completed', 'success');
        break;
    }
  },

  updateAPIUsage(data) {
    if (this.data.rateLimits[data.api]) {
      this.data.rateLimits[data.api].current = data.current;
      
      // Update UI elements only if on the right section
      if (this.currentSection === 'api-config') {
        this.updateAPIConfiguration();
      }
    }
  },

  // Stable real-time updates
  startRealTimeUpdates() {
    // Longer intervals for more stable behavior
    setInterval(() => this.updateMetrics(), 30000); // Every 30 seconds
    setInterval(() => this.updateTradingSignals(), 60000); // Every minute
    setInterval(() => this.updateSystemHealth(), 120000); // Every 2 minutes
  },

  updateMetrics() {
    // Much smaller variations for stable metrics
    const variation = (Math.random() - 0.5) * 0.2;
    this.data.systemStatus.performanceScore = Math.max(92, Math.min(98, 
      this.data.systemStatus.performanceScore + variation));
    
    // Update UI elements only if on dashboard
    if (this.currentSection === 'dashboard') {
      const performanceElements = document.querySelectorAll('.metric-value');
      performanceElements.forEach(element => {
        if (element.textContent.includes('%') && !element.textContent.includes('h')) {
          element.textContent = this.data.systemStatus.performanceScore.toFixed(1) + '%';
        }
      });
    }
  },

  updateSystemHealth() {
    // Minimal changes to system health
    this.data.apiEndpoints.forEach(endpoint => {
      const variation = (Math.random() - 0.5) * 0.1;
      endpoint.uptime = Math.max(97, Math.min(100, endpoint.uptime + variation));
      
      const timeVariation = (Math.random() - 0.5) * 10;
      endpoint.responseTime = Math.max(100, Math.min(500, endpoint.responseTime + timeVariation));
    });
    
    // Update displays only if on system health section
    if (this.currentSection === 'system-health') {
      this.monitorEndpoints();
    }
  },

  // Specific action handlers with better error handling
  refreshDashboard() {
    this.showNotification('Dashboard refreshed', 'success');
    this.refreshDashboardCharts();
    this.updateMetrics();
  },

  exportData() {
    const dataToExport = {
      timestamp: new Date().toISOString(),
      systemStatus: this.data.systemStatus,
      agents: this.data.agents,
      projects: this.data.projects,
      apiUsage: this.data.rateLimits,
      marketData: this.data.marketData
    };
    
    const dataStr = JSON.stringify(dataToExport, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `infinity-singularity-export-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    this.showNotification('Data exported successfully', 'success');
  },

  saveConfiguration() {
    const config = {
      project: document.getElementById('projectSelect')?.value || 'litigation',
      timestamp: new Date().toISOString(),
      rateLimits: this.data.rateLimits,
      alertConfig: this.alertConfig || {}
    };
    
    localStorage.setItem('infinity_config', JSON.stringify(config));
    this.showNotification('Configuration saved successfully', 'success');
  },

  testAllAPIs() {
    const apis = Object.keys(this.data.rateLimits);
    let completed = 0;
    
    apis.forEach((api, index) => {
      setTimeout(() => {
        const success = Math.random() > 0.1; // Higher success rate
        completed++;
        
        if (success) {
          this.showNotification(`${api.toUpperCase()} API: Connected`, 'success');
        } else {
          this.showNotification(`${api.toUpperCase()} API: Connection failed`, 'error');
        }
        
        if (completed === apis.length) {
          this.showNotification('API connectivity test completed', 'info');
        }
      }, index * 300);
    });
  },

  // Advanced features
  initializeAdvancedFeatures() {
    this.initializeKeyboardShortcuts();
    this.initializeDragAndDrop();
    this.initializeAutoSave();
  },

  initializeKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
      if (e.ctrlKey || e.metaKey) {
        switch(e.key) {
          case 'r':
            e.preventDefault();
            this.refreshDashboard();
            break;
          case 'e':
            e.preventDefault();
            this.exportData();
            break;
          case 's':
            e.preventDefault();
            this.saveConfiguration();
            break;
        }
      }
    });
  },

  initializeDragAndDrop() {
    const draggableElements = document.querySelectorAll('.workflow-node');
    draggableElements.forEach(element => {
      element.draggable = true;
      element.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', element.dataset.agent);
      });
    });
  },

  initializeAutoSave() {
    setInterval(() => {
      this.autoSave();
    }, 300000); // Auto-save every 5 minutes
  },

  autoSave() {
    const config = {
      timestamp: new Date().toISOString(),
      currentSection: this.currentSection,
      data: this.data,
      version: '1.0'
    };
    
    localStorage.setItem('infinity_autosave', JSON.stringify(config));
  },

  // Simplified action methods
  createAgent() {
    const newAgent = {
      id: `agent-${Date.now()}`,
      name: `Custom Agent ${this.data.agents.length + 1}`,
      type: 'custom',
      status: 'initializing',
      performance: 95.0,
      requests: 0,
      errors: 0,
      successRate: 100
    };
    
    this.data.agents.push(newAgent);
    this.showNotification(`Agent ${newAgent.name} created successfully`, 'success');
  },

  evolvePrompt() {
    const fitnessImprovement = Math.random() * 3 + 1;
    this.showNotification(`Prompt evolved - fitness improved by ${fitnessImprovement.toFixed(1)}%`, 'success');
  },

  startTrading() {
    this.showNotification('Trading session initialized with risk management', 'success');
  },

  generateReport() {
    const reportData = {
      timestamp: new Date().toISOString(),
      systemHealth: {
        uptime: this.data.systemStatus.uptime,
        performanceScore: this.data.systemStatus.performanceScore,
        activeAgents: this.data.systemStatus.totalAgents
      },
      apiUsage: this.data.rateLimits,
      costs: this.data.costAnalysis
    };
    
    const reportStr = JSON.stringify(reportData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(reportStr);
    
    const exportFileDefaultName = `system-health-report-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    this.showNotification('System health report generated', 'success');
  },

  runDiagnostics() {
    const diagnostics = ['Memory Usage', 'CPU Performance', 'Network Latency', 'Database Connections'];
    let completed = 0;
    
    diagnostics.forEach((diagnostic, index) => {
      setTimeout(() => {
        const status = Math.random() > 0.1 ? 'PASS' : 'WARN';
        completed++;
        
        this.showNotification(`${diagnostic}: ${status}`, status === 'PASS' ? 'success' : 'warning');
        
        if (completed === diagnostics.length) {
          this.showNotification('System diagnostics completed', 'info');
        }
      }, index * 400);
    });
  },

  // Other simplified methods
  manualVerification() {
    this.showNotification('Manual verification checkpoint passed', 'success');
  },

  uploadSchema() {
    this.showNotification('Schema upload initiated', 'success');
  },

  validateAllSchemas() {
    this.showNotification('All schemas validated successfully', 'success');
  },

  createDNA() {
    this.showNotification('Prompt DNA template created', 'success');
  },

  testEndpoint() {
    this.showNotification('Endpoint test completed successfully', 'success');
  },

  generateGPTAction() {
    this.showNotification('GPT Action schema generated', 'success');
  },

  benchmarkArchitecture() {
    this.showNotification('Architecture benchmark completed', 'success');
  },

  migrateArchitecture() {
    this.showNotification('Architecture migration planned', 'success');
  },

  deployAll() {
    this.showNotification('All services deployed successfully', 'success');
  },

  // Enhanced notification system
  showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.textContent = message;
    
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 20px;
      border-radius: 8px;
      color: white;
      font-weight: 500;
      z-index: 10000;
      animation: slideIn 0.3s ease-out;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      border-left: 4px solid;
      max-width: 300px;
      word-wrap: break-word;
    `;
    
    const colors = {
      success: '#32b8c6',
      error: '#ff5459',
      warning: '#e68161',
      info: '#a7a9a9'
    };
    
    notification.style.background = `linear-gradient(135deg, ${colors[type]} 0%, ${colors[type]}cc 100%)`;
    notification.style.borderLeftColor = colors[type];
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.style.animation = 'slideOut 0.3s ease-in';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 3000);
  }
};

// Add CSS animations for notifications and modals
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(100%);
      opacity: 0;
    }
  }
  
  .modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
  }
  
  .modal-content {
    background: var(--color-surface);
    border-radius: var(--radius-lg);
    border: 1px solid rgba(50, 184, 198, 0.3);
    min-width: 400px;
    max-width: 600px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
    animation: modalSlideIn 0.3s ease-out;
  }
  
  .modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: var(--space-20);
    border-bottom: 1px solid var(--color-border);
  }
  
  .modal-body {
    padding: var(--space-20);
  }
  
  .modal-footer {
    display: flex;
    justify-content: flex-end;
    gap: var(--space-12);
    padding: var(--space-20);
    border-top: 1px solid var(--color-border);
  }
  
  .modal-close {
    background: none;
    border: none;
    font-size: var(--font-size-xl);
    color: var(--color-text-secondary);
    cursor: pointer;
    padding: 0;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .modal-close:hover {
    color: var(--color-text);
  }
  
  .detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: var(--space-16);
    margin-top: var(--space-16);
  }
  
  @keyframes modalSlideIn {
    from {
      transform: scale(0.9);
      opacity: 0;
    }
    to {
      transform: scale(1);
      opacity: 1;
    }
  }
`;
document.head.appendChild(style);

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  // Ensure single initialization
  if (!window.InfinitySingularityKernelInitialized) {
    window.InfinitySingularityKernelInitialized = true;
    InfinitySingularityKernel.init();
  }
});

// Export for global access
window.InfinitySingularityKernel = InfinitySingularityKernel;