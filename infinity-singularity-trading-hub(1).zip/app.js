// Trading Hub Application - Comprehensive Trading & AI Integration Platform
const TradingHub = {
  // Application data based on JSON requirements
  data: {
    tradingPlatforms: [
      {
        name: "Robinhood Crypto",
        apiEndpoint: "https://trading.robinhood.com/api/v1/crypto/",
        status: "active",
        features: ["crypto_trading", "market_data", "portfolio_management"],
        documentation: "https://docs.robinhood.com/crypto/trading/"
      },
      {
        name: "Coinbase Pro",
        apiEndpoint: "https://api.pro.coinbase.com",
        status: "active", 
        features: ["crypto_trading", "advanced_orders", "real_time_data"],
        documentation: "https://docs.pro.coinbase.com/"
      },
      {
        name: "Binance",
        apiEndpoint: "https://api.binance.com",
        status: "active",
        features: ["spot_trading", "futures", "margin_trading"],
        documentation: "https://binance-docs.github.io/apidocs/"
      },
      {
        name: "Alpha Vantage",
        apiEndpoint: "https://www.alphavantage.co/query",
        status: "active",
        features: ["market_data", "fundamentals", "technical_indicators"],
        documentation: "https://www.alphavantage.co/documentation/"
      }
    ],
    aiProviders: [
      {
        name: "OpenAI",
        endpoint: "https://api.openai.com/v1/",
        model: "gpt-4",
        usage: "trading_strategy_generation"
      },
      {
        name: "Anthropic",
        endpoint: "https://api.anthropic.com/v1/",
        model: "claude-3-sonnet",
        usage: "market_analysis"
      },
      {
        name: "Google Gemini",
        endpoint: "https://generativelanguage.googleapis.com/v1/",
        model: "gemini-pro",
        usage: "schema_translation"
      },
      {
        name: "Perplexity",
        endpoint: "https://api.perplexity.ai/",
        model: "mixtral-8x7b-instruct",
        usage: "market_research"
      }
    ],
    marketData: {
      cryptoPairs: ["BTC-USD", "ETH-USD", "ADA-USD", "SOL-USD", "DOGE-USD"],
      stockSymbols: ["AAPL", "GOOGL", "MSFT", "TSLA", "NVDA"],
      indicators: ["RSI", "MACD", "SMA", "EMA", "Bollinger Bands"]
    },
    tradingStrategies: [
      {
        name: "AI-Powered Momentum",
        description: "Uses multiple AI models to identify momentum signals",
        status: "active",
        performance: "+12.5%"
      },
      {
        name: "Grid Trading Bot",
        description: "Automated grid trading with AI optimization",
        status: "paused",
        performance: "+8.7%"
      },
      {
        name: "Arbitrage Scanner",
        description: "Cross-exchange arbitrage opportunities",
        status: "active",
        performance: "+3.2%"
      }
    ],
    riskManagement: {
      maxPositionSize: 1000,
      dailyLossLimit: 500,
      maxOpenPositions: 10,
      stopLossPercentage: 2.0
    },
    portfolio: {
      totalValue: 125847.50,
      todaysPnL: 2847.50,
      totalReturn: 12.3,
      positions: [
        { symbol: "BTC-USD", quantity: 0.75, value: 31763.75, change: 2.3 },
        { symbol: "ETH-USD", quantity: 12.5, value: 35593.75, change: -1.7 },
        { symbol: "AAPL", quantity: 200, value: 37450.00, change: 0.8 },
        { symbol: "SOL-USD", quantity: 500, value: 21040.00, change: 4.2 }
      ]
    },
    currentPrices: {
      "BTC-USD": { price: 42350.00, change: 2.3, source: "Coinbase Pro" },
      "ETH-USD": { price: 2847.50, change: -1.7, source: "Binance" },
      "AAPL": { price: 187.25, change: 0.8, source: "Alpha Vantage" },
      "SOL-USD": { price: 42.08, change: 4.2, source: "Binance" },
      "DOGE-USD": { price: 0.078, change: -0.5, source: "Robinhood" }
    },
    tradingSignals: [
      { symbol: "BTC-USD", type: "BUY", strength: "Strong", confidence: 95, timestamp: new Date() },
      { symbol: "ETH-USD", type: "SELL", strength: "Moderate", confidence: 78, timestamp: new Date() },
      { symbol: "SOL-USD", type: "HOLD", strength: "Weak", confidence: 62, timestamp: new Date() }
    ],
    recentTrades: [
      { symbol: "BTC-USD", type: "BUY", quantity: 0.025, price: 42100.00, timestamp: new Date(Date.now() - 120000) },
      { symbol: "ETH-USD", type: "SELL", quantity: 0.5, price: 2850.00, timestamp: new Date(Date.now() - 300000) }
    ],
    openOrders: [
      { symbol: "BTC-USD", type: "BUY LIMIT", quantity: 0.05, price: 42000.00, timestamp: new Date() },
      { symbol: "ETH-USD", type: "SELL LIMIT", quantity: 0.25, price: 2900.00, timestamp: new Date() }
    ]
  },

  // Application state
  chartColors: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454', '#13343B'],
  charts: {},
  currentSection: 'dashboard',
  initialized: false,
  realTimeUpdates: null,
  currentPlatform: 'robinhood',

  // Initialize the application
  init() {
    if (this.initialized) return;
    
    this.initialized = true;
    this.initializeNavigation();
    this.initializeCharts();
    this.initializeInteractions();
    this.initializeTradingInterface();
    this.initializeAPIConfiguration();
    this.initializeAIStrategies();
    this.initializeBrowserInterface();
    this.initializeAnalytics();
    this.initializeRiskManagement();
    this.initializeSecurity();
    this.startRealTimeUpdates();
    
    // Show initial notification
    setTimeout(() => {
      this.showNotification('Trading Hub initialized successfully', 'success');
    }, 1000);
  },

  // Navigation functionality
  initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.content-section');
    
    // Ensure initial state
    this.showSection('dashboard');
    
    navLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetSection = link.getAttribute('data-section');
        
        if (targetSection === this.currentSection) return;
        
        this.showSection(targetSection);
        
        // Update navigation state
        navLinks.forEach(nav => nav.classList.remove('active'));
        link.classList.add('active');
        
        console.log(`Navigated to: ${targetSection}`);
      });
    });
  },

  showSection(sectionId) {
    const sections = document.querySelectorAll('.content-section');
    const targetSection = document.getElementById(sectionId);
    
    if (!targetSection) {
      console.error(`Section ${sectionId} not found`);
      return;
    }
    
    // Hide all sections
    sections.forEach(section => {
      section.classList.remove('active');
      section.style.display = 'none';
    });
    
    // Show target section
    targetSection.style.display = 'block';
    targetSection.classList.add('active');
    
    this.currentSection = sectionId;
    this.initializeSectionFeatures(sectionId);
  },

  initializeSectionFeatures(sectionId) {
    switch(sectionId) {
      case 'dashboard':
        this.refreshDashboard();
        break;
      case 'trading':
        this.updateTradingInterface();
        break;
      case 'ai-strategies':
        this.updateAIStrategies();
        break;
      case 'analytics':
        this.updateAnalytics();
        break;
      case 'risk':
        this.updateRiskManagement();
        break;
    }
  },

  // Chart initialization
  initializeCharts() {
    setTimeout(() => {
      this.initializePortfolioChart();
      this.initializePriceChart();
      this.initializeStrategyChart();
      this.initializeIndicatorsChart();
      this.initializeAllocationChart();
    }, 500);
  },

  initializePortfolioChart() {
    const ctx = document.getElementById('portfolioChart');
    if (!ctx) return;
    
    const generatePortfolioData = () => {
      const data = [];
      const now = new Date();
      let baseValue = 123000;
      
      for (let i = 30; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
        const variation = (Math.random() - 0.5) * 3000;
        baseValue += variation;
        data.push({x: time, y: Math.max(baseValue, 100000)});
      }
      return data;
    };
    
    this.charts.portfolio = new Chart(ctx, {
      type: 'line',
      data: {
        datasets: [{
          label: 'Portfolio Value',
          data: generatePortfolioData(),
          borderColor: this.chartColors[0],
          backgroundColor: this.chartColors[0] + '20',
          fill: true,
          tension: 0.4,
          pointRadius: 2,
          pointHoverRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#f5f5f5' } },
          tooltip: {
            callbacks: {
              label: function(context) {
                return 'Portfolio: $' + context.parsed.y.toLocaleString();
              }
            }
          }
        },
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'day',
              displayFormats: { day: 'MMM dd' }
            },
            ticks: { color: '#a7a9a9' },
            grid: { color: '#777c7c30' }
          },
          y: {
            ticks: { 
              color: '#a7a9a9',
              callback: function(value) {
                return '$' + value.toLocaleString();
              }
            },
            grid: { color: '#777c7c30' }
          }
        }
      }
    });
  },

  initializePriceChart() {
    const ctx = document.getElementById('priceChart');
    if (!ctx) return;
    
    const generatePriceData = () => {
      const data = [];
      const now = new Date();
      let basePrice = 42000;
      
      for (let i = 24; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 60 * 60 * 1000);
        const variation = (Math.random() - 0.5) * 1000;
        basePrice += variation;
        data.push({x: time, y: Math.max(basePrice, 35000)});
      }
      return data;
    };
    
    this.charts.price = new Chart(ctx, {
      type: 'line',
      data: {
        datasets: [{
          label: 'BTC-USD Price',
          data: generatePriceData(),
          borderColor: this.chartColors[1],
          backgroundColor: this.chartColors[1] + '20',
          fill: true,
          tension: 0.4,
          pointRadius: 1,
          pointHoverRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#f5f5f5' } }
        },
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'hour',
              displayFormats: { hour: 'HH:mm' }
            },
            ticks: { color: '#a7a9a9' },
            grid: { color: '#777c7c30' }
          },
          y: {
            ticks: { 
              color: '#a7a9a9',
              callback: function(value) {
                return '$' + value.toLocaleString();
              }
            },
            grid: { color: '#777c7c30' }
          }
        }
      }
    });
  },

  initializeStrategyChart() {
    const ctx = document.getElementById('strategyChart');
    if (!ctx) return;
    
    const strategies = this.data.tradingStrategies;
    const performanceData = strategies.map(s => parseFloat(s.performance.replace('%', '')));
    
    this.charts.strategy = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: strategies.map(s => s.name),
        datasets: [{
          label: 'Performance %',
          data: performanceData,
          backgroundColor: this.chartColors.slice(0, strategies.length),
          borderColor: this.chartColors.slice(0, strategies.length),
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#f5f5f5' } }
        },
        scales: {
          x: {
            ticks: { color: '#a7a9a9' },
            grid: { color: '#777c7c30' }
          },
          y: {
            beginAtZero: true,
            ticks: { 
              color: '#a7a9a9',
              callback: function(value) {
                return value + '%';
              }
            },
            grid: { color: '#777c7c30' }
          }
        }
      }
    });
  },

  initializeIndicatorsChart() {
    const ctx = document.getElementById('indicatorsChart');
    if (!ctx) return;
    
    const indicators = this.data.marketData.indicators;
    const indicatorData = indicators.map(() => Math.random() * 100);
    
    this.charts.indicators = new Chart(ctx, {
      type: 'radar',
      data: {
        labels: indicators,
        datasets: [{
          label: 'Technical Indicators',
          data: indicatorData,
          borderColor: this.chartColors[2],
          backgroundColor: this.chartColors[2] + '30',
          pointBackgroundColor: this.chartColors[2],
          pointBorderColor: '#fff',
          pointHoverBackgroundColor: '#fff',
          pointHoverBorderColor: this.chartColors[2]
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#f5f5f5' } }
        },
        scales: {
          r: {
            beginAtZero: true,
            max: 100,
            ticks: { color: '#a7a9a9' },
            grid: { color: '#777c7c30' },
            pointLabels: { color: '#f5f5f5' }
          }
        }
      }
    });
  },

  initializeAllocationChart() {
    const ctx = document.getElementById('allocationChart');
    if (!ctx) return;
    
    const positions = this.data.portfolio.positions;
    const labels = positions.map(p => p.symbol);
    const values = positions.map(p => p.value);
    
    this.charts.allocation = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [{
          data: values,
          backgroundColor: this.chartColors.slice(0, positions.length),
          borderWidth: 2,
          borderColor: '#1f2121'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#f5f5f5', padding: 20 }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const value = context.parsed;
                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                const percentage = ((value / total) * 100).toFixed(1);
                return context.label + ': $' + value.toLocaleString() + ' (' + percentage + '%)';
              }
            }
          }
        }
      }
    });
  },

  // Interactive functionality
  initializeInteractions() {
    // Button interactions
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        if (!button.disabled && !button.classList.contains('loading')) {
          this.handleButtonClick(button, e);
        }
      });
    });

    // Form submissions
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleFormSubmission(form);
      });
    });
  },

  handleButtonClick(button, event) {
    const buttonText = button.textContent.trim();
    
    // Add loading state
    button.classList.add('loading');
    
    setTimeout(() => {
      button.classList.remove('loading');
      
      // Handle specific button actions
      switch(buttonText) {
        case 'Refresh Markets':
          this.refreshMarketData();
          break;
        case 'Quick Trade':
          this.showQuickTradeModal();
          break;
        case 'Place Order':
          this.placeOrder();
          break;
        case 'Cancel':
          this.cancelOrder(button);
          break;
        case 'Test':
          this.testAPI(button);
          break;
        case 'Save Configuration':
          this.saveConfiguration();
          break;
        case 'Integrate':
          this.integrateLablabResource(button);
          break;
        case 'Create Strategy':
          this.createStrategy();
          break;
        case 'Deploy Strategy':
          this.deployStrategy();
          break;
        case 'Configure':
          this.configureAIModel(button);
          break;
        case 'Sign In':
        case 'Log In':
          this.handlePlatformLogin(button);
          break;
        case 'New Session':
          this.createNewSession();
          break;
        case 'End Session':
          this.endSession(button);
          break;
        case 'Start Session':
          this.startSession(button);
          break;
        case 'Generate Insights':
          this.generateInsights();
          break;
        case 'Update Limits':
          this.updateRiskLimits();
          break;
        case 'Enable 2FA':
          this.enable2FA();
          break;
        case 'Backup Now':
          this.backupConfiguration();
          break;
        default:
          this.showNotification(`${buttonText} executed successfully`, 'success');
      }
    }, 800);
  },

  // Trading Interface
  initializeTradingInterface() {
    this.updateMarketData();
    this.updateOpenOrders();
    this.updateRecentTrades();
    this.initializeOrderForm();
  },

  updateMarketData() {
    const marketItems = document.querySelectorAll('.market-item');
    const prices = Object.entries(this.data.currentPrices);
    
    marketItems.forEach((item, index) => {
      if (prices[index]) {
        const [symbol, data] = prices[index];
        const priceElement = item.querySelector('.price-value');
        const changeElement = item.querySelector('.price-change');
        
        if (priceElement) {
          priceElement.textContent = `$${data.price.toLocaleString()}`;
        }
        
        if (changeElement) {
          changeElement.textContent = `${data.change > 0 ? '+' : ''}${data.change.toFixed(1)}%`;
          changeElement.className = `price-change ${data.change > 0 ? 'positive' : 'negative'}`;
        }
      }
    });
  },

  updateOpenOrders() {
    const openOrdersContainer = document.querySelector('.open-orders');
    if (!openOrdersContainer) return;
    
    const ordersHTML = this.data.openOrders.map(order => `
      <div class="order-item">
        <div class="order-info">
          <span class="order-symbol">${order.symbol}</span>
          <span class="order-type ${order.type.toLowerCase().includes('buy') ? 'buy' : 'sell'}">${order.type}</span>
        </div>
        <div class="order-details">
          <span class="order-quantity">${order.quantity} ${order.symbol.split('-')[0]}</span>
          <span class="order-price">$${order.price.toLocaleString()}</span>
          <button class="btn btn--sm btn--error">Cancel</button>
        </div>
      </div>
    `).join('');
    
    openOrdersContainer.innerHTML = ordersHTML;
  },

  updateRecentTrades() {
    const tradeHistoryContainer = document.querySelector('.trade-history');
    if (!tradeHistoryContainer) return;
    
    const tradesHTML = this.data.recentTrades.map(trade => {
      const timeAgo = Math.floor((Date.now() - trade.timestamp.getTime()) / 60000);
      return `
        <div class="trade-item">
          <div class="trade-info">
            <span class="trade-symbol">${trade.symbol}</span>
            <span class="trade-type ${trade.type.toLowerCase()}">${trade.type}</span>
          </div>
          <div class="trade-details">
            <span class="trade-amount">${trade.quantity} ${trade.symbol.split('-')[0]}</span>
            <span class="trade-price">$${trade.price.toLocaleString()}</span>
            <span class="trade-time">${timeAgo} min ago</span>
          </div>
        </div>
      `;
    }).join('');
    
    tradeHistoryContainer.innerHTML = tradesHTML;
  },

  initializeOrderForm() {
    const orderForm = document.querySelector('.order-form');
    if (!orderForm) return;
    
    const sideButtons = orderForm.querySelectorAll('.order-side-buttons .btn');
    sideButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        sideButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
      });
    });
  },

  placeOrder() {
    const orderForm = document.querySelector('.order-form');
    if (!orderForm) return;
    
    const formData = new FormData(orderForm);
    const platform = orderForm.querySelector('select').value;
    const symbol = orderForm.querySelector('input[placeholder="BTC-USD"]').value;
    const orderType = orderForm.querySelector('select:nth-of-type(2)').value;
    const quantity = orderForm.querySelector('input[placeholder="0.01"]').value;
    const price = orderForm.querySelector('input[placeholder="42,350.00"]').value;
    
    // Simulate order placement
    const newOrder = {
      symbol: symbol,
      type: orderType.toUpperCase(),
      quantity: parseFloat(quantity),
      price: parseFloat(price.replace(',', '')),
      timestamp: new Date()
    };
    
    this.data.openOrders.unshift(newOrder);
    this.updateOpenOrders();
    this.showNotification(`Order placed: ${orderType} ${quantity} ${symbol} at $${price}`, 'success');
  },

  cancelOrder(button) {
    const orderItem = button.closest('.order-item');
    if (orderItem) {
      const symbol = orderItem.querySelector('.order-symbol').textContent;
      orderItem.remove();
      this.showNotification(`Order cancelled: ${symbol}`, 'info');
    }
  },

  refreshMarketData() {
    // Simulate market data refresh
    Object.keys(this.data.currentPrices).forEach(symbol => {
      const currentData = this.data.currentPrices[symbol];
      const variation = (Math.random() - 0.5) * 0.1;
      currentData.change = Math.max(-10, Math.min(10, currentData.change + variation));
      currentData.price = currentData.price * (1 + currentData.change / 100);
    });
    
    this.updateMarketData();
    this.showNotification('Market data refreshed', 'success');
  },

  showQuickTradeModal() {
    const modal = this.createModal('Quick Trade', `
      <div class="quick-trade-form">
        <div class="form-group">
          <label class="form-label">Symbol</label>
          <select class="form-control">
            <option>BTC-USD</option>
            <option>ETH-USD</option>
            <option>SOL-USD</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Action</label>
          <div class="order-side-buttons">
            <button class="btn btn--sm btn--success">BUY</button>
            <button class="btn btn--sm btn--error">SELL</button>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Amount (USD)</label>
          <input type="number" class="form-control" placeholder="1000" value="1000">
        </div>
      </div>
    `);
    
    const confirmButton = modal.querySelector('.btn--primary');
    confirmButton.textContent = 'Execute Trade';
    confirmButton.addEventListener('click', () => {
      this.showNotification('Trade executed successfully', 'success');
      modal.remove();
    });
  },

  // API Configuration
  initializeAPIConfiguration() {
    const apiTestButtons = document.querySelectorAll('.api-controls .btn--secondary');
    apiTestButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        this.testAPI(button);
      });
    });
  },

  testAPI(button) {
    const apiItem = button.closest('.api-config-item');
    const apiName = apiItem.querySelector('.api-name').textContent;
    
    // Simulate API test
    const success = Math.random() > 0.1;
    
    if (success) {
      this.showNotification(`${apiName} API: Connection successful`, 'success');
    } else {
      this.showNotification(`${apiName} API: Connection failed`, 'error');
    }
  },

  saveConfiguration() {
    const config = {
      timestamp: new Date().toISOString(),
      tradingPlatforms: this.data.tradingPlatforms,
      aiProviders: this.data.aiProviders,
      riskManagement: this.data.riskManagement
    };
    
    localStorage.setItem('trading_hub_config', JSON.stringify(config));
    this.showNotification('Configuration saved successfully', 'success');
  },

  integrateLablabResource(button) {
    const resourceItem = button.closest('.resource-item');
    const resourceName = resourceItem.querySelector('.resource-name').textContent;
    
    this.showNotification(`Integrating ${resourceName}...`, 'info');
    
    setTimeout(() => {
      this.showNotification(`${resourceName} integrated successfully`, 'success');
      button.textContent = 'Integrated';
      button.disabled = true;
    }, 2000);
  },

  // AI Strategies
  initializeAIStrategies() {
    this.updateAIStrategies();
    this.updateTradingSignals();
  },

  updateAIStrategies() {
    const strategyList = document.querySelector('.strategy-list');
    if (!strategyList) return;
    
    const strategiesHTML = this.data.tradingStrategies.map(strategy => `
      <div class="strategy-item">
        <div class="strategy-info">
          <span class="strategy-name">${strategy.name}</span>
          <span class="strategy-description">${strategy.description}</span>
        </div>
        <div class="strategy-metrics">
          <span class="strategy-performance positive">${strategy.performance}</span>
          <span class="status status--${strategy.status === 'active' ? 'success' : 'warning'}">${strategy.status}</span>
        </div>
      </div>
    `).join('');
    
    strategyList.innerHTML = strategiesHTML;
  },

  updateTradingSignals() {
    const signalMonitor = document.querySelector('.signal-monitor');
    if (!signalMonitor) return;
    
    const signalsHTML = this.data.tradingSignals.map(signal => {
      const timeAgo = Math.floor((Date.now() - signal.timestamp.getTime()) / 60000);
      return `
        <div class="signal-item">
          <div class="signal-info">
            <span class="signal-symbol">${signal.symbol}</span>
            <span class="signal-type ${signal.type.toLowerCase()}">${signal.type} SIGNAL</span>
          </div>
          <div class="signal-details">
            <span class="signal-strength ${signal.strength.toLowerCase()}">${signal.strength}</span>
            <span class="signal-confidence">${signal.confidence}%</span>
            <span class="signal-time">${timeAgo} min ago</span>
          </div>
        </div>
      `;
    }).join('');
    
    signalMonitor.innerHTML = signalsHTML;
  },

  createStrategy() {
    const modal = this.createModal('Create New Strategy', `
      <div class="strategy-form">
        <div class="form-group">
          <label class="form-label">Strategy Name</label>
          <input type="text" class="form-control" placeholder="Enter strategy name">
        </div>
        <div class="form-group">
          <label class="form-label">AI Model</label>
          <select class="form-control">
            <option>OpenAI GPT-4</option>
            <option>Anthropic Claude</option>
            <option>Google Gemini</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Strategy Type</label>
          <select class="form-control">
            <option>Momentum Trading</option>
            <option>Mean Reversion</option>
            <option>Arbitrage</option>
            <option>Grid Trading</option>
          </select>
        </div>
      </div>
    `);
    
    const confirmButton = modal.querySelector('.btn--primary');
    confirmButton.textContent = 'Create Strategy';
    confirmButton.addEventListener('click', () => {
      this.showNotification('Strategy created successfully', 'success');
      modal.remove();
    });
  },

  deployStrategy() {
    this.showNotification('Deploying strategy...', 'info');
    
    setTimeout(() => {
      this.showNotification('Strategy deployed successfully', 'success');
    }, 2000);
  },

  configureAIModel(button) {
    const modelItem = button.closest('.model-item');
    const modelName = modelItem.querySelector('.model-name').textContent;
    
    const modal = this.createModal(`Configure ${modelName}`, `
      <div class="model-config-form">
        <div class="form-group">
          <label class="form-label">Temperature</label>
          <input type="range" class="form-control" min="0" max="1" step="0.1" value="0.7">
        </div>
        <div class="form-group">
          <label class="form-label">Max Tokens</label>
          <input type="number" class="form-control" value="1000">
        </div>
        <div class="form-group">
          <label class="form-label">System Prompt</label>
          <textarea class="form-control" rows="3" placeholder="Enter system prompt..."></textarea>
        </div>
      </div>
    `);
    
    const confirmButton = modal.querySelector('.btn--primary');
    confirmButton.textContent = 'Save Configuration';
    confirmButton.addEventListener('click', () => {
      this.showNotification(`${modelName} configuration saved`, 'success');
      modal.remove();
    });
  },

  // Browser Interface
  initializeBrowserInterface() {
    const platformButtons = document.querySelectorAll('.platform-btn');
    platformButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        const platform = button.getAttribute('data-platform');
        this.switchPlatform(platform);
      });
    });
  },

  switchPlatform(platform) {
    const platformButtons = document.querySelectorAll('.platform-btn');
    const platformFrames = document.querySelectorAll('.platform-frame');
    
    // Update button states
    platformButtons.forEach(btn => btn.classList.remove('active'));
    document.querySelector(`[data-platform="${platform}"]`).classList.add('active');
    
    // Update frame display
    platformFrames.forEach(frame => frame.classList.remove('active'));
    document.querySelector(`.platform-frame.${platform}`).classList.add('active');
    
    // Update address bar
    const addressBar = document.querySelector('.browser-address input');
    const urls = {
      robinhood: 'https://robinhood.com/crypto',
      coinbase: 'https://pro.coinbase.com',
      binance: 'https://www.binance.com'
    };
    
    if (addressBar) {
      addressBar.value = urls[platform];
    }
    
    this.currentPlatform = platform;
  },

  handlePlatformLogin(button) {
    const platformFrame = button.closest('.platform-frame');
    const platform = platformFrame.classList[1]; // Get platform class name
    
    this.showNotification(`Logging into ${platform}...`, 'info');
    
    setTimeout(() => {
      this.showNotification(`Successfully logged into ${platform}`, 'success');
      // Update session status
      this.updateSessionStatus(platform, 'active');
    }, 2000);
  },

  updateSessionStatus(platform, status) {
    const sessionItems = document.querySelectorAll('.session-item');
    sessionItems.forEach(item => {
      const sessionPlatform = item.querySelector('.session-platform').textContent.toLowerCase();
      if (sessionPlatform.includes(platform)) {
        const statusElement = item.querySelector('.session-status');
        const timeElement = item.querySelector('.session-time');
        const buttonElement = item.querySelector('.btn');
        
        if (status === 'active') {
          statusElement.textContent = 'Active';
          statusElement.className = 'session-status active';
          timeElement.textContent = '0h 0m';
          buttonElement.textContent = 'End Session';
          buttonElement.className = 'btn btn--sm btn--error';
        } else {
          statusElement.textContent = 'Inactive';
          statusElement.className = 'session-status inactive';
          timeElement.textContent = '--';
          buttonElement.textContent = 'Start Session';
          buttonElement.className = 'btn btn--sm btn--primary';
        }
      }
    });
  },

  createNewSession() {
    this.showNotification('Creating new session...', 'info');
    
    setTimeout(() => {
      this.showNotification('New session created successfully', 'success');
    }, 1000);
  },

  endSession(button) {
    const sessionItem = button.closest('.session-item');
    const platform = sessionItem.querySelector('.session-platform').textContent.toLowerCase();
    
    this.updateSessionStatus(platform, 'inactive');
    this.showNotification(`Session ended for ${platform}`, 'info');
  },

  startSession(button) {
    const sessionItem = button.closest('.session-item');
    const platform = sessionItem.querySelector('.session-platform').textContent.toLowerCase();
    
    this.updateSessionStatus(platform, 'active');
    this.showNotification(`Session started for ${platform}`, 'success');
  },

  // Analytics
  initializeAnalytics() {
    this.updateAnalytics();
  },

  updateAnalytics() {
    // Update performance metrics
    const metricsElements = document.querySelectorAll('.metrics-card .metric-value');
    if (metricsElements.length >= 4) {
      metricsElements[0].textContent = '+23.5%';
      metricsElements[1].textContent = '1.42';
      metricsElements[2].textContent = '12.8%';
      metricsElements[3].textContent = '68.5%';
    }
    
    // Update sentiment analysis
    this.updateSentimentAnalysis();
  },

  updateSentimentAnalysis() {
    const sentimentItems = document.querySelectorAll('.sentiment-item');
    const sentiments = [
      { symbol: 'BTC', score: 'Bullish', value: '+0.72', percentage: 72 },
      { symbol: 'ETH', score: 'Bearish', value: '-0.35', percentage: 35 },
      { symbol: 'SOL', score: 'Neutral', value: '+0.12', percentage: 12 }
    ];
    
    sentimentItems.forEach((item, index) => {
      if (sentiments[index]) {
        const sentiment = sentiments[index];
        const scoreElement = item.querySelector('.sentiment-score');
        const valueElement = item.querySelector('.sentiment-value');
        const fillElement = item.querySelector('.sentiment-fill');
        
        if (scoreElement) {
          scoreElement.textContent = sentiment.score;
          scoreElement.className = `sentiment-score ${sentiment.score.toLowerCase()}`;
        }
        
        if (valueElement) {
          valueElement.textContent = sentiment.value;
        }
        
        if (fillElement) {
          fillElement.style.width = `${sentiment.percentage}%`;
          fillElement.className = `sentiment-fill ${sentiment.score.toLowerCase()}`;
        }
      }
    });
  },

  generateInsights() {
    this.showNotification('Generating AI insights...', 'info');
    
    setTimeout(() => {
      const insights = [
        'BTC showing strong momentum with RSI indicating overbought conditions',
        'ETH volume declining, suggesting potential reversal',
        'Portfolio diversification could be improved with more defensive assets'
      ];
      
      const randomInsight = insights[Math.floor(Math.random() * insights.length)];
      this.showNotification(`Insight: ${randomInsight}`, 'success');
    }, 2000);
  },

  // Risk Management
  initializeRiskManagement() {
    this.updateRiskManagement();
    this.initializeRiskControls();
  },

  updateRiskManagement() {
    const riskItems = document.querySelectorAll('.risk-item');
    const riskData = [
      { label: 'Current Risk Level', value: 'Moderate', type: 'status' },
      { label: 'Portfolio at Risk', value: '$12,584.75', type: 'amount' },
      { label: 'Daily P&L', value: '+$2,847.50', type: 'amount' }
    ];
    
    riskItems.forEach((item, index) => {
      if (riskData[index]) {
        const data = riskData[index];
        const valueElement = item.querySelector('.risk-value');
        
        if (data.type === 'status') {
          const statusElement = item.querySelector('.risk-status');
          if (statusElement) {
            statusElement.textContent = data.value;
          }
        } else if (data.type === 'amount') {
          const amountElement = item.querySelector('.risk-amount');
          if (amountElement) {
            amountElement.textContent = data.value;
            amountElement.className = `risk-amount ${data.value.includes('+') ? 'positive' : ''}`;
          }
        }
      }
    });
  },

  initializeRiskControls() {
    const riskInputs = document.querySelectorAll('.risk-controls input');
    riskInputs.forEach(input => {
      input.addEventListener('change', () => {
        this.updateRiskLevel();
      });
    });
  },

  updateRiskLevel() {
    const inputs = document.querySelectorAll('.risk-controls input');
    const maxPosition = parseFloat(inputs[0]?.value) || 0;
    const dailyLimit = parseFloat(inputs[1]?.value) || 0;
    const maxPositions = parseFloat(inputs[2]?.value) || 0;
    const stopLoss = parseFloat(inputs[3]?.value) || 0;
    
    let riskLevel = 'Low';
    let riskPercentage = 30;
    
    if (maxPosition > 2000 || dailyLimit > 1000 || stopLoss < 1) {
      riskLevel = 'High';
      riskPercentage = 80;
    } else if (maxPosition > 1000 || dailyLimit > 500 || stopLoss < 2) {
      riskLevel = 'Moderate';
      riskPercentage = 60;
    }
    
    const riskStatus = document.querySelector('.risk-status');
    const riskFill = document.querySelector('.risk-fill');
    
    if (riskStatus) {
      riskStatus.textContent = riskLevel;
      riskStatus.className = `risk-status ${riskLevel.toLowerCase()}`;
    }
    
    if (riskFill) {
      riskFill.style.width = `${riskPercentage}%`;
    }
  },

  updateRiskLimits() {
    const inputs = document.querySelectorAll('.risk-controls input');
    
    this.data.riskManagement.maxPositionSize = parseFloat(inputs[0]?.value) || 1000;
    this.data.riskManagement.dailyLossLimit = parseFloat(inputs[1]?.value) || 500;
    this.data.riskManagement.maxOpenPositions = parseInt(inputs[2]?.value) || 10;
    this.data.riskManagement.stopLossPercentage = parseFloat(inputs[3]?.value) || 2.0;
    
    this.showNotification('Risk limits updated successfully', 'success');
  },

  // Security
  initializeSecurity() {
    this.updateSecurityStatus();
  },

  updateSecurityStatus() {
    const securityItems = document.querySelectorAll('.security-item');
    const securityFeatures = [
      { name: 'API Key Encryption', status: 'Enabled' },
      { name: 'Two-Factor Authentication', status: 'Enabled' },
      { name: 'Rate Limiting', status: 'Active' },
      { name: 'Session Protection', status: 'Active' }
    ];
    
    securityItems.forEach((item, index) => {
      if (securityFeatures[index]) {
        const feature = securityFeatures[index];
        const statusElement = item.querySelector('.status');
        
        if (statusElement) {
          statusElement.textContent = feature.status;
          statusElement.className = 'status status--success';
        }
      }
    });
  },

  enable2FA() {
    const modal = this.createModal('Enable Two-Factor Authentication', `
      <div class="tfa-setup">
        <div class="form-group">
          <label class="form-label">Authentication App</label>
          <select class="form-control">
            <option>Google Authenticator</option>
            <option>Authy</option>
            <option>Microsoft Authenticator</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Backup Codes</label>
          <textarea class="form-control" rows="3" placeholder="Enter backup codes..." readonly></textarea>
        </div>
        <div class="form-group">
          <label class="form-label">Verification Code</label>
          <input type="text" class="form-control" placeholder="Enter 6-digit code">
        </div>
      </div>
    `);
    
    const confirmButton = modal.querySelector('.btn--primary');
    confirmButton.textContent = 'Enable 2FA';
    confirmButton.addEventListener('click', () => {
      this.showNotification('Two-factor authentication enabled', 'success');
      modal.remove();
    });
  },

  backupConfiguration() {
    const config = {
      timestamp: new Date().toISOString(),
      portfolio: this.data.portfolio,
      strategies: this.data.tradingStrategies,
      riskManagement: this.data.riskManagement,
      platforms: this.data.tradingPlatforms
    };
    
    const dataStr = JSON.stringify(config, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `trading-hub-backup-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    this.showNotification('Configuration backed up successfully', 'success');
  },

  // Real-time Updates
  startRealTimeUpdates() {
    this.realTimeUpdates = setInterval(() => {
      this.updateRealTimeData();
    }, 30000); // Update every 30 seconds
  },

  updateRealTimeData() {
    // Update market prices
    Object.keys(this.data.currentPrices).forEach(symbol => {
      const data = this.data.currentPrices[symbol];
      const variation = (Math.random() - 0.5) * 0.2;
      data.change = Math.max(-5, Math.min(5, data.change + variation));
      data.price = data.price * (1 + data.change / 100);
    });
    
    // Update portfolio value
    this.data.portfolio.totalValue = this.data.portfolio.positions.reduce((total, position) => {
      return total + position.value;
    }, 0);
    
    // Update displays if on relevant sections
    if (this.currentSection === 'dashboard' || this.currentSection === 'trading') {
      this.updateMarketData();
    }
    
    // Update charts
    this.updateCharts();
  },

  updateCharts() {
    // Update portfolio chart with new data point
    if (this.charts.portfolio && this.currentSection === 'dashboard') {
      const chart = this.charts.portfolio;
      const newDataPoint = {
        x: new Date(),
        y: this.data.portfolio.totalValue
      };
      
      chart.data.datasets[0].data.push(newDataPoint);
      
      // Keep only last 30 data points
      if (chart.data.datasets[0].data.length > 30) {
        chart.data.datasets[0].data.shift();
      }
      
      chart.update('none');
    }
  },

  refreshDashboard() {
    this.updateMarketData();
    this.updateRecentTrades();
    this.updateCharts();
    this.showNotification('Dashboard refreshed', 'success');
  },

  // Utility functions
  createModal(title, content) {
    // Remove existing modals
    const existingModals = document.querySelectorAll('.modal-overlay');
    existingModals.forEach(modal => modal.remove());
    
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal-content">
        <div class="modal-header">
          <h3>${title}</h3>
          <button class="modal-close" type="button">&times;</button>
        </div>
        <div class="modal-body">
          ${content}
        </div>
        <div class="modal-footer">
          <button class="btn btn--outline" type="button">Cancel</button>
          <button class="btn btn--primary" type="button">Confirm</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // Event listeners
    modal.querySelector('.modal-close').addEventListener('click', () => {
      modal.remove();
    });
    
    modal.querySelector('.btn--outline').addEventListener('click', () => {
      modal.remove();
    });
    
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.remove();
      }
    });
    
    return modal;
  },

  showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.textContent = message;
    
    const colors = {
      success: '#32b8c6',
      error: '#ff5459',
      warning: '#e68161',
      info: '#a7a9a9'
    };
    
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 20px;
      border-radius: 8px;
      color: white;
      font-weight: 500;
      z-index: 10000;
      animation: slideIn 0.3s ease-out;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      border-left: 4px solid ${colors[type]};
      background: linear-gradient(135deg, ${colors[type]} 0%, ${colors[type]}cc 100%);
      max-width: 350px;
      word-wrap: break-word;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.style.animation = 'slideOut 0.3s ease-in';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 4000);
  }
};

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(100%);
      opacity: 0;
    }
  }
  
  .modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
  }
  
  .modal-content {
    background: var(--color-surface);
    border-radius: var(--radius-lg);
    border: 1px solid rgba(50, 184, 198, 0.3);
    min-width: 400px;
    max-width: 600px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
    animation: modalSlideIn 0.3s ease-out;
  }
  
  .modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: var(--space-20);
    border-bottom: 1px solid var(--color-border);
  }
  
  .modal-body {
    padding: var(--space-20);
  }
  
  .modal-footer {
    display: flex;
    justify-content: flex-end;
    gap: var(--space-12);
    padding: var(--space-20);
    border-top: 1px solid var(--color-border);
  }
  
  .modal-close {
    background: none;
    border: none;
    font-size: var(--font-size-xl);
    color: var(--color-text-secondary);
    cursor: pointer;
    padding: 0;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .modal-close:hover {
    color: var(--color-text);
  }
  
  @keyframes modalSlideIn {
    from {
      transform: scale(0.9);
      opacity: 0;
    }
    to {
      transform: scale(1);
      opacity: 1;
    }
  }
`;
document.head.appendChild(style);

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  if (!window.TradingHubInitialized) {
    window.TradingHubInitialized = true;
    TradingHub.init();
  }
});

// Export for global access
window.TradingHub = TradingHub;